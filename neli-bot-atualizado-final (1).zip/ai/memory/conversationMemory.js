// ═══════════════════════════════════════════════════════════════
//  CONVERSATION MEMORY — Memória de Curto e Longo Prazo
//  Nel-Aviso-Bot-Moz 🇲🇿 — Cérebro de IA Elite
//
//  Funcionalidades:
//  • Memória de curto prazo: últimas N mensagens por utilizador
//  • Memória de longo prazo: perfil persistente em SQLite
//  • Resumo automático quando o histórico fica longo
//  • Contexto de vendas: estado do funil por utilizador
// ═══════════════════════════════════════════════════════════════
import DB from '#db';

// Todas as funções de atendimento usam a ligação única configurada por
// BOT_DB_PATH. Não abrir outra base fixa em data.db.
const db = DB.db;

// ── Criar tabelas de memória de IA ───────────────────────────
db.exec(`
  CREATE TABLE IF NOT EXISTS ai_conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_jid TEXT NOT NULL,
    chat_jid TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    timestamp INTEGER DEFAULT (strftime('%s','now')),
    tokens_estimate INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS ai_user_profiles (
    user_jid TEXT PRIMARY KEY,
    name TEXT DEFAULT '',
    interests TEXT DEFAULT '[]',
    pain_points TEXT DEFAULT '[]',
    purchase_stage TEXT DEFAULT 'awareness',
    last_intent TEXT DEFAULT '',
    total_interactions INTEGER DEFAULT 0,
    first_seen INTEGER DEFAULT (strftime('%s','now')),
    last_seen INTEGER DEFAULT (strftime('%s','now')),
    custom_data TEXT DEFAULT '{}'
  );

  CREATE TABLE IF NOT EXISTS ai_sessions (
    user_jid TEXT PRIMARY KEY,
    ai_mode INTEGER DEFAULT 0,
    ai_mode_since INTEGER DEFAULT 0,
    session_context TEXT DEFAULT '{}',
    handoff_to_human INTEGER DEFAULT 0
  );

  CREATE INDEX IF NOT EXISTS idx_ai_conv_user ON ai_conversations(user_jid, timestamp);
  CREATE INDEX IF NOT EXISTS idx_ai_conv_user_chat_time
    ON ai_conversations(user_jid, chat_jid, timestamp);
`);

// Migração segura
function addColumnIfMissing(table, column, definition) {
  try {
    db.prepare(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`).run();
  } catch { /* já existe */ }
}
addColumnIfMissing('ai_sessions', 'handoff_to_human', 'INTEGER DEFAULT 0');

// ── Configurações ────────────────────────────────────────────
const MAX_SHORT_TERM   = 20;   // máx mensagens no contexto imediato
const MAX_TOKENS_EST   = 3000; // estimativa de tokens antes de resumir
const SESSION_TIMEOUT  = 30 * 60; // 30 minutos de inactividade = nova sessão

// ── API de Memória ───────────────────────────────────────────
const Memory = {

  /**
   * Adicionar mensagem ao histórico
   */
  addMessage(userJid, chatJid, role, content) {
    const tokens = Math.ceil((content || '').length / 4);
    db.prepare(`
      INSERT INTO ai_conversations (user_jid, chat_jid, role, content, tokens_estimate)
      VALUES (?, ?, ?, ?, ?)
    `).run(userJid, chatJid, role, content, tokens);

    // Actualizar perfil
    this._updateLastSeen(userJid);

    // Limpar histórico antigo se necessário
    this._pruneHistory(userJid, chatJid);
  },

  /**
   * Obter histórico de conversa formatado para o LLM
   */
  getHistory(userJid, chatJid, limit = MAX_SHORT_TERM) {
    const rows = db.prepare(`
      SELECT role, content, timestamp
      FROM ai_conversations
      WHERE user_jid = ? AND chat_jid = ?
      ORDER BY timestamp DESC
      LIMIT ?
    `).all(userJid, chatJid, limit);

    // Inverter para ordem cronológica
    return rows.reverse().map(r => ({
      role: r.role,
      content: r.content,
    }));
  },

  /**
   * Obter perfil persistente sem criar um registo vazio.
   */
  getExistingUserProfile(userJid) {
    const profile = db.prepare(
      'SELECT * FROM ai_user_profiles WHERE user_jid = ?'
    ).get(userJid);
    if (!profile) return null;

    try { profile.interests = JSON.parse(profile.interests || '[]'); } catch { profile.interests = []; }
    try { profile.pain_points = JSON.parse(profile.pain_points || '[]'); } catch { profile.pain_points = []; }
    try { profile.custom_data = JSON.parse(profile.custom_data || '{}'); } catch { profile.custom_data = {}; }
    return profile;
  },

  /**
   * Obter perfil do utilizador (memória de longo prazo)
   */
  getUserProfile(userJid) {
    let profile = this.getExistingUserProfile(userJid);

    if (!profile) {
      db.prepare(`
        INSERT OR IGNORE INTO ai_user_profiles (user_jid) VALUES (?)
      `).run(userJid);
      profile = this.getExistingUserProfile(userJid);
    }
    return profile;
  },

  /**
   * Actualizar perfil do utilizador
   */
  updateUserProfile(userJid, updates) {
    this.getUserProfile(userJid); // garantir que existe

    for (const [key, value] of Object.entries(updates)) {
      const v = (typeof value === 'object' && value !== null)
        ? JSON.stringify(value)
        : value;
      try {
        db.prepare(`UPDATE ai_user_profiles SET ${key} = ? WHERE user_jid = ?`).run(v, userJid);
      } catch (e) {
        console.error(`[Memory] updateUserProfile error (${key}):`, e.message);
      }
    }
  },

  /**
   * Incrementar contador de interacções
   */
  incrementInteractions(userJid) {
    db.prepare(`
      UPDATE ai_user_profiles
      SET total_interactions = total_interactions + 1,
          last_seen = strftime('%s','now')
      WHERE user_jid = ?
    `).run(userJid);
  },

  /**
   * Verificar se o utilizador está em modo IA
   */
  isInAIMode(userJid) {
    let session = db.prepare(
      'SELECT * FROM ai_sessions WHERE user_jid = ?'
    ).get(userJid);

    if (!session) return false;

    // Verificar timeout de sessão
    const now = Math.floor(Date.now() / 1000);
    if (session.ai_mode && (now - session.ai_mode_since) > SESSION_TIMEOUT) {
      // Sessão expirou
      this.setAIMode(userJid, false);
      return false;
    }

    return session.ai_mode === 1;
  },

  /**
   * Activar/desactivar modo IA para um utilizador
   */
  setAIMode(userJid, enabled, context = {}) {
    const now = Math.floor(Date.now() / 1000);
    db.prepare(`
      INSERT OR REPLACE INTO ai_sessions (user_jid, ai_mode, ai_mode_since, session_context)
      VALUES (?, ?, ?, ?)
    `).run(userJid, enabled ? 1 : 0, enabled ? now : 0, JSON.stringify(context));
  },

  /**
   * Obter contexto da sessão actual
   */
  getSessionContext(userJid) {
    const session = db.prepare(
      'SELECT session_context FROM ai_sessions WHERE user_jid = ?'
    ).get(userJid);
    if (!session) return {};
    try { return JSON.parse(session.session_context || '{}'); } catch { return {}; }
  },

  /**
   * Actualizar contexto da sessão
   */
  updateSessionContext(userJid, updates) {
    const current = this.getSessionContext(userJid);
    const merged  = { ...current, ...updates };
    db.prepare(`
      UPDATE ai_sessions SET session_context = ? WHERE user_jid = ?
    `).run(JSON.stringify(merged), userJid);
  },

  /**
   * Verificar se deve transferir para humano
   */
  isHandoffRequested(userJid) {
    const session = db.prepare(
      'SELECT handoff_to_human FROM ai_sessions WHERE user_jid = ?'
    ).get(userJid);
    return session?.handoff_to_human === 1;
  },

  /**
   * Solicitar transferência para humano
   */
  requestHandoff(userJid, reason = '') {
    db.prepare(`
      INSERT OR REPLACE INTO ai_sessions (user_jid, ai_mode, handoff_to_human, session_context)
      VALUES (?, 1, 1, ?)
    `).run(userJid, JSON.stringify({ handoff_reason: reason, handoff_at: Date.now() }));
  },

  /**
   * Limpar sessão e histórico de um utilizador
   */
  clearSession(userJid, chatJid) {
    db.prepare(
      'DELETE FROM ai_conversations WHERE user_jid = ? AND chat_jid = ?'
    ).run(userJid, chatJid);
    db.prepare(
      'DELETE FROM ai_sessions WHERE user_jid = ?'
    ).run(userJid);
  },

  /**
   * Apagar conversas, perfil e sessão do utilizador desta base SQLite.
   * Chamado dentro da transacção de eliminação do registo comercial.
   */
  clearUserData(userJid) {
    if (!userJid) return { conversations: 0, profile: 0, session: 0 };
    return {
      conversations: db.prepare('DELETE FROM ai_conversations WHERE user_jid = ?').run(userJid).changes,
      profile: db.prepare('DELETE FROM ai_user_profiles WHERE user_jid = ?').run(userJid).changes,
      session: db.prepare('DELETE FROM ai_sessions WHERE user_jid = ?').run(userJid).changes,
    };
  },

  /**
   * Resumo do perfil para incluir no prompt do sistema
   */
  buildProfileSummary(userJid) {
    const profile = this.getUserProfile(userJid);
    const parts   = [];

    if (profile.name)
      parts.push(`Nome: ${profile.name}`);
    if (profile.interests?.length)
      parts.push(`Interesses: ${profile.interests.join(', ')}`);
    if (profile.pain_points?.length)
      parts.push(`Dores/Problemas: ${profile.pain_points.join(', ')}`);
    if (profile.purchase_stage)
      parts.push(`Etapa no funil: ${profile.purchase_stage}`);
    if (profile.last_intent)
      parts.push(`Última intenção detectada: ${profile.last_intent}`);
    if (profile.total_interactions > 0)
      parts.push(`Total de interacções: ${profile.total_interactions}`);

    return parts.length > 0
      ? `\n[PERFIL DO CLIENTE]\n${parts.join('\n')}\n`
      : '';
  },

  // ── Métodos privados ────────────────────────────────────────

  _updateLastSeen(userJid) {
    db.prepare(`
      INSERT OR IGNORE INTO ai_user_profiles (user_jid) VALUES (?);
    `).run(userJid);
    db.prepare(`
      UPDATE ai_user_profiles SET last_seen = strftime('%s','now') WHERE user_jid = ?
    `).run(userJid);
  },

  _pruneHistory(userJid, chatJid) {
    // Manter apenas as últimas MAX_SHORT_TERM*2 mensagens
    const count = db.prepare(`
      SELECT COUNT(*) as c FROM ai_conversations
      WHERE user_jid = ? AND chat_jid = ?
    `).get(userJid, chatJid)?.c || 0;

    if (count > MAX_SHORT_TERM * 2) {
      // Apagar as mais antigas
      db.prepare(`
        DELETE FROM ai_conversations
        WHERE user_jid = ? AND chat_jid = ?
        AND id NOT IN (
          SELECT id FROM ai_conversations
          WHERE user_jid = ? AND chat_jid = ?
          ORDER BY timestamp DESC
          LIMIT ?
        )
      `).run(userJid, chatJid, userJid, chatJid, MAX_SHORT_TERM * 2);
    }
  },

  /**
   * Estatísticas gerais de uso da IA
   */
  getStats() {
    const totalUsers = db.prepare(
      'SELECT COUNT(DISTINCT user_jid) as c FROM ai_conversations'
    ).get()?.c || 0;
    const totalMsgs  = db.prepare(
      'SELECT COUNT(*) as c FROM ai_conversations'
    ).get()?.c || 0;
    const activeSessions = db.prepare(
      'SELECT COUNT(*) as c FROM ai_sessions WHERE ai_mode = 1'
    ).get()?.c || 0;

    return { totalUsers, totalMsgs, activeSessions };
  },
};

export default Memory;
