/**
 * Ferramentas base do cérebro NEXUS OMEGA.
 *
 * Estas ferramentas são locais e auditáveis: actualizam apenas a memória
 * SQLite ou devolvem informação de contexto. Acções externas continuam a
 * exigir uma integração e aprovação humana explícita.
 */
import Memory from '../memory/conversationMemory.js';
import { getPackageCatalog } from '../../core/businessCatalog.js';

const tool = (name, description, properties = {}, required = []) => ({
  type: 'function',
  function: {
    name,
    description,
    parameters: { type: 'object', properties, required },
  },
});

export const TOOL_DEFINITIONS = [
  tool(
    'update_customer_profile',
    'Actualizar dados persistentes do perfil do cliente detectados na conversa.',
    {
      name: { type: 'string', description: 'Nome do cliente' },
      interests: { type: 'array', items: { type: 'string' }, description: 'Interesses' },
      pain_points: { type: 'array', items: { type: 'string' }, description: 'Necessidades ou problemas' },
      custom_data: { type: 'object', description: 'Outros dados não sensíveis' },
    },
  ),
  tool(
    'check_product_catalog',
    'Consultar o catálogo local configurado para responder sobre produtos e preços.',
    {
      query: { type: 'string', description: 'Produto ou serviço procurado' },
      category: { type: 'string', description: 'Categoria opcional' },
    },
    ['query'],
  ),
  tool(
    'register_lead',
    'Registar localmente um potencial cliente sem efectuar contacto externo.',
    {
      name: { type: 'string', description: 'Nome do potencial cliente' },
      interest: { type: 'string', description: 'Produto ou serviço de interesse' },
      notes: { type: 'string', description: 'Notas e contexto' },
    },
    ['interest'],
  ),
  tool(
    'request_human_handoff',
    'Solicitar transferência da conversa para uma pessoa responsável.',
    { reason: { type: 'string', description: 'Motivo da transferência' } },
    ['reason'],
  ),
];

function clean(value, max = 500) {
  return String(value ?? '').trim().slice(0, max);
}

function uniqueStrings(values, max = 20) {
  return [...new Set((Array.isArray(values) ? values : []).map(v => clean(v, 120)).filter(Boolean))].slice(0, max);
}

export const ToolExecutor = {
  async execute(toolName, args = {}, context = {}) {
    const userJid = clean(context.userJid || 'unknown-user', 180);

    switch (toolName) {
      case 'update_customer_profile': {
        const updates = {};
        if (args.name) updates.name = clean(args.name, 160);
        if (args.interests) updates.interests = uniqueStrings(args.interests);
        if (args.pain_points) updates.pain_points = uniqueStrings(args.pain_points);
        if (args.custom_data && typeof args.custom_data === 'object') {
          updates.custom_data = Object.fromEntries(
            Object.entries(args.custom_data).slice(0, 20).map(([key, value]) => [clean(key, 80), clean(value, 300)]),
          );
        }
        if (Object.keys(updates).length) Memory.updateUserProfile(userJid, updates);
        return { success: true, updated: Object.keys(updates), message: 'Perfil actualizado na memória local.' };
      }

      case 'check_product_catalog': {
        const query = clean(args.query, 160);
        const catalog = getPackageCatalog();
        const products = Object.entries(catalog).flatMap(([period, items]) =>
          (Array.isArray(items) ? items : []).map(item => ({ ...item, period })),
        );
        const needle = query.toLowerCase();
        const matches = products.filter(product => {
          const haystack = `${product.period} ${product.price} ${product.megabytes} ${product.label || ''}`.toLowerCase();
          return !needle || haystack.includes(needle);
        }).slice(0, 10);
        return {
          success: true,
          results: matches,
          message: matches.length
            ? `Encontrei ${matches.length} item(ns) no catálogo local.`
            : 'Não há itens correspondentes no catálogo local configurado.',
        };
      }

      case 'register_lead': {
        const interest = clean(args.interest, 200);
        Memory.updateUserProfile(userJid, {
          last_intent: `lead:${interest}`,
          purchase_stage: 'lead',
          custom_data: {
            ...Memory.getUserProfile(userJid).custom_data,
            lead_interest: interest,
            lead_notes: clean(args.notes, 500),
            lead_name: clean(args.name, 160),
          },
        });
        return {
          success: true,
          approval_required: true,
          message: 'Lead registado localmente. Qualquer contacto externo requer aprovação humana.',
        };
      }

      case 'request_human_handoff': {
        const reason = clean(args.reason, 500);
        Memory.requestHandoff(userJid, reason);
        const owners = (context.settings?.ownerNumbers || [])
          .map(value => String(value).trim())
          .filter(Boolean)
          .map(value => value.includes('@') ? value : `${value.replace(/\D/g, '')}@s.whatsapp.net`)
          .filter(jid => jid !== '@s.whatsapp.net' && jid !== userJid);
        const notified = [];
        for (const ownerJid of owners) {
          try {
            await context.sock.sendMessage(ownerJid, {
              text: `📩 Pedido de atendimento humano\nCliente: ${userJid}\nMotivo: ${reason || 'não especificado'}\nAbra a conversa privada para responder.`,
            });
            notified.push(ownerJid);
          } catch (error) {
            console.error(`[AI handoff] Não foi possível avisar ${ownerJid}:`, error.message);
          }
        }
        return {
          success: notified.length > 0,
          handoff: notified.length > 0,
          notified: notified.length,
          reason,
          message: notified.length
            ? 'O responsável recebeu uma notificação para rever o pedido.'
            : 'O pedido foi registado, mas não foi possível notificar o responsável. Verifique OWNER_NUMBER(S) e a ligação.',
        };
      }

      default:
        return { success: false, message: `Ferramenta desconhecida: ${toolName}` };
    }
  },
};

export default { TOOL_DEFINITIONS, ToolExecutor };