/**
 * Advanced Agent Tools (Nível Deus - Fase 2.2 & 2.4)
 * Nel-Aviso-Bot-Moz 🇲🇿
 *
 * Ferramentas avançadas para agentes especializados:
 * - Web Search (pesquisa na internet)
 * - CRM Integration (Salesforce/HubSpot via webhook)
 * - Email/SMS Automation
 * - Social Media Integration
 * - Payment Processing (M-Pesa, e-Mola)
 * - Calendar & Scheduling
 * - Document Generation
 */

import fetch from 'node-fetch';
import Memory from '../memory/conversationMemory.js';
import DB from '#db';

// ── Definições de Ferramentas Avançadas ──────────────────────

export const ADVANCED_TOOL_DEFINITIONS = [
  {
    type: 'function',
    function: {
      name: 'web_search',
      description: 'Pesquisar informações na internet sobre qualquer tema.',
      parameters: {
        type: 'object',
        properties: {
          query: { type: 'string', description: 'Termo de pesquisa' },
          language: { type: 'string', description: 'Idioma da pesquisa', default: 'pt' },
          max_results: { type: 'integer', description: 'Número máximo de resultados', default: 5 },
        },
        required: ['query'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'search_knowledge_base',
      description: 'Pesquisar na base de conhecimento interna do bot (FAQ, documentos, catálogos).',
      parameters: {
        type: 'object',
        properties: {
          query: { type: 'string', description: 'Termo de pesquisa na base de conhecimento' },
          type: {
            type: 'string',
            enum: ['product', 'client', 'document', 'feedback', 'all'],
            description: 'Tipo de documento a pesquisar',
          },
        },
        required: ['query'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'send_mpesa_request',
      description: 'Gerar um pedido de pagamento via M-Pesa para o cliente.',
      parameters: {
        type: 'object',
        properties: {
          amount: { type: 'number', description: 'Valor em MZN' },
          description: { type: 'string', description: 'Descrição do pagamento' },
          reference: { type: 'string', description: 'Referência do pagamento' },
        },
        required: ['amount', 'description'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'generate_proposal',
      description: 'Gerar uma proposta comercial para um cliente com base nos produtos e serviços.',
      parameters: {
        type: 'object',
        properties: {
          client_name: { type: 'string', description: 'Nome do cliente' },
          products: { type: 'array', items: { type: 'string' }, description: 'Lista de produtos/serviços incluídos' },
          discount: { type: 'number', description: 'Desconto percentual (opcional)' },
        },
        required: ['client_name', 'products'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'create_ticket',
      description: 'Criar um ticket de suporte técnico para acompanhamento.',
      parameters: {
        type: 'object',
        properties: {
          title: { type: 'string', description: 'Título do problema' },
          description: { type: 'string', description: 'Descrição detalhada do problema' },
          priority: {
            type: 'string',
            enum: ['low', 'medium', 'high', 'urgent'],
            description: 'Prioridade do ticket',
          },
        },
        required: ['title', 'description'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'generate_content',
      description: 'Gerar conteúdo para redes sociais, email marketing ou blog.',
      parameters: {
        type: 'object',
        properties: {
          type: {
            type: 'string',
            enum: ['post_instagram', 'post_facebook', 'email', 'blog', 'whatsapp_status'],
            description: 'Tipo de conteúdo',
          },
          topic: { type: 'string', description: 'Tema do conteúdo' },
          tone: { type: 'string', description: 'Tom do conteúdo', default: 'profissional' },
        },
        required: ['type', 'topic'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'calculate_quote',
      description: 'Calcular orçamento para um conjunto de serviços/produtos.',
      parameters: {
        type: 'object',
        properties: {
          services: { type: 'array', items: { type: 'string' }, description: 'Lista de serviços/produtos' },
          quantity: { type: 'integer', description: 'Quantidade (se aplicável)', default: 1 },
        },
        required: ['services'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'send_notification',
      description: 'Enviar notificação proactiva para um cliente ou admin.',
      parameters: {
        type: 'object',
        properties: {
          target: { type: 'string', description: 'Número JID do destinatário' },
          message: { type: 'string', description: 'Mensagem a enviar' },
          type: {
            type: 'string',
            enum: ['reminder', 'offer', 'followup', 'alert', 'info'],
            description: 'Tipo de notificação',
          },
        },
        required: ['target', 'message', 'type'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'analyze_sentiment',
      description: 'Analisar o sentimento/tom de uma conversa com cliente.',
      parameters: {
        type: 'object',
        properties: {
          conversation_context: { type: 'string', description: 'Contexto da conversa para análise' },
        },
        required: ['conversation_context'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'update_pipeline',
      description: 'Actualizar a etapa de um lead no pipeline de vendas.',
      parameters: {
        type: 'object',
        properties: {
          lead_id: { type: 'string', description: 'ID ou nome do lead' },
          stage: {
            type: 'string',
            enum: ['lead', 'qualified', 'proposal', 'negotiation', 'won', 'lost'],
            description: 'Nova etapa do pipeline',
          },
          notes: { type: 'string', description: 'Notas sobre a actualização' },
        },
        required: ['lead_id', 'stage'],
      },
    },
  },
];

// ── Executor de Ferramentas Avançadas ────────────────────────

export const AdvancedToolExecutor = {
  async execute(toolName, args, context = {}) {
    const { userJid, chatJid, sock, settings } = context;

    switch (toolName) {
      case 'web_search':
        return this._webSearch(args);
      case 'search_knowledge_base':
        return await this._searchKnowledgeBase(args, context);
      case 'send_mpesa_request':
        return this._sendMpesaRequest(args, userJid);
      case 'generate_proposal':
        return this._generateProposal(args, settings);
      case 'create_ticket':
        return this._createTicket(args, userJid);
      case 'generate_content':
        return this._generateContent(args, context);
      case 'calculate_quote':
        return this._calculateQuote(args, settings);
      case 'send_notification':
        return this._sendNotification(args, context);
      case 'analyze_sentiment':
        return this._analyzeSentiment(args, context);
      case 'update_pipeline':
        return this._updatePipeline(args, userJid);
      default:
        return { success: false, message: `Ferramenta avançada desconhecida: ${toolName}` };
    }
  },

  async _webSearch(args) {
    try {
      // Usar API de pesquisa pública
      const query = encodeURIComponent(args.query);
      const lang = args.language || 'pt';
      const res = await fetch(
        `https://html.duckduckgo.com/html/?q=${query}&kl=${lang === 'pt' ? 'pt-pt' : lang}`
      );
      if (!res.ok) {
        return { success: false, message: 'Serviço de pesquisa temporariamente indisponível.' };
      }
      const html = await res.text();
      // Extrair snippets simples
      const snippets = [];
      const regex = /<a[^>]*class="result__a"[^>]*>(.*?)<\/a>[\s\S]*?<a[^>]*class="result__snippet"[^>]*>(.*?)<\/a>/gs;
      let match;
      let count = 0;
      while ((match = regex.exec(html)) !== null && count < (args.max_results || 5)) {
        snippets.push({
          title: match[1].replace(/<[^>]+>/g, '').trim(),
          snippet: match[2].replace(/<[^>]+>/g, '').trim(),
        });
        count++;
      }
      return {
        success: true,
        results: snippets,
        message: snippets.length > 0
          ? `Encontrei ${snippets.length} resultados:\n${snippets.map(s => `• *${s.title}*: ${s.snippet}`).join('\n')}`
          : 'Nenhum resultado encontrado.',
      };
    } catch (e) {
      return { success: false, message: `Erro na pesquisa: ${e.message}` };
    }
  },

  async _searchKnowledgeBase(args, context) {
    if (context.vectorStore) {
      const results = await context.vectorStore.search(args.query, args.type === 'all' ? null : args.type);
      return {
        success: true,
        results: results.map(r => ({ content: r.content, similarity: r.similarity })),
        message: results.length > 0
          ? `Encontrei ${results.length} resultados:\n${results.map(r => `• ${r.content.substring(0, 200)} (${Math.round(r.similarity * 100)}% relevância)`).join('\n')}`
          : 'Nenhum resultado encontrado na base de conhecimento.',
      };
    }
    return { success: false, message: 'Base de conhecimento não disponível.' };
  },

  _sendMpesaRequest(args, userJid) {
    const mpesaNumber = DB.getBusinessConfig('paymentMethods', {})?.mpesa?.numero;
    const amount = Number(args?.amount);
    if (!mpesaNumber) {
      return { success: false, message: 'Os dados de M-Pesa ainda não estão configurados. Consulte .pagamento ou peça ao responsável para editar os pagamentos.' };
    }
    if (!Number.isFinite(amount) || amount <= 0) {
      return { success: false, message: 'O valor indicado não é válido. Consulte a tabela actual antes de pagar.' };
    }
    return {
      success: true,
      message: `💰 *Dados de pagamento M-Pesa (não inicia uma transferência)*\n\n` +
        `Para: ${mpesaNumber}\n` +
        `Valor: ${amount.toLocaleString('pt-MZ')} MZN\n` +
        `Descrição: ${args.description}\n` +
        `Referência: ${args.reference || `NEL-${Date.now().toString(36).toUpperCase()}`}\n\n` +
        `_Confirme o valor na tabela e envie o comprovativo. O pagamento só é confirmado manualmente na aplicação da operadora._`,
      paymentRequest: {
        recipient: mpesaNumber,
        amount,
        description: args.description,
        reference: args.reference || `NEL-${Date.now().toString(36).toUpperCase()}`,
      },
    };
  },

  _generateProposal(args, settings) {
    const discount = args.discount || 0;
    const catalog = settings?.aiCatalog || [];
    let total = 0;
    const items = args.products.map(p => {
      const product = catalog.find(c => c.name.toLowerCase().includes(p.toLowerCase()));
      const price = product ? parseFloat(product.price.replace(/[^\d]/g, '')) || 0 : 0;
      total += price;
      return { name: p, price };
    });

    const discountedTotal = total * (1 - discount / 100);
    const proposalId = `PROP-${Date.now().toString(36).toUpperCase()}`;

    return {
      success: true,
      proposal: {
        id: proposalId,
        client: args.client_name,
        items,
        subtotal: total,
        discount: `${discount}%`,
        total: discountedTotal,
        validUntil: new Date(Date.now() + 7 * 24 * 3600 * 1000).toLocaleDateString('pt-MZ'),
      },
      message: `📋 *Proposta Comercial #${proposalId}*\n\n` +
        `Cliente: *${args.client_name}*\n\n` +
        `Itens:\n${items.map(i => `• ${i.name}: ${i.price ? `${i.price.toLocaleString('pt-MZ')} MZN` : 'Sob consulta'}`).join('\n')}\n\n` +
        `Subtotal: ${total.toLocaleString('pt-MZ')} MZN\n` +
        (discount > 0 ? `Desconto: ${discount}%\n` : '') +
        `Total: *${discountedTotal.toLocaleString('pt-MZ')} MZN*\n\n` +
        `Válida até: ${new Date(Date.now() + 7 * 24 * 3600 * 1000).toLocaleDateString('pt-MZ')}`,
    };
  },

  _createTicket(args, userJid) {
    const ticketId = `TKT-${Date.now().toString(36).toUpperCase()}`;
    const priorityEmoji = { low: '🟢', medium: '🟡', high: '🔴', urgent: '🚨' };
    const emoji = priorityEmoji[args.priority] || '🟡';

    // Guardar no perfil
    Memory.updateUserProfile(userJid, {
      last_intent: `ticket_created:${args.title}`,
    });

    return {
      success: true,
      ticket: { id: ticketId, title: args.title, description: args.description, priority: args.priority },
      message: `${emoji} *Ticket Criado #${ticketId}*\n\n` +
        `Título: ${args.title}\n` +
        `Prioridade: ${args.priority}\n` +
        `Descrição: ${args.description}\n\n` +
        `O seu pedido será analisado em breve. Pode acompanhar pelo número do ticket.`,
    };
  },

  async _generateContent(args, context) {
    if (!process.env.OPENAI_KEY) {
      return { success: false, message: 'IA não disponível para geração de conteúdo.' };
    }

    const typeLabels = {
      post_instagram: 'post para Instagram',
      post_facebook: 'post para Facebook',
      email: 'email marketing',
      blog: 'artigo de blog',
      whatsapp_status: 'status para WhatsApp',
    };

    const prompts = {
      post_instagram: 'Crie um post de Instagram com legenda, hashtags (máx 15) e sugestão de imagem. Use emojis com moderação.',
      post_facebook: 'Crie um post para Facebook com texto persuasivo e call-to-action.',
      email: 'Crie um email marketing com assunto, corpo e call-to-action claro.',
      blog: 'Crie um artigo de blog com título, introdução, 3 secções e conclusão.',
      whatsapp_status: 'Crie um texto curto e impactante para status do WhatsApp (máx 200 caracteres).',
    };

    try {
      const res = await fetch(`${process.env.OPENAI_API_BASE || 'https://api.openai.com/v1'}/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: process.env.AI_MODEL_FAST || 'gpt-4o-mini',
          messages: [
            { role: 'system', content: prompts[args.type] || prompts.post_instagram },
            { role: 'user', content: `Tema: ${args.topic}. Tom: ${args.tone || 'profissional'}. Público: moçambicano.` },
          ],
          max_tokens: 500,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const content = data.choices?.[0]?.message?.content;
        return {
          success: true,
          content,
          type: typeLabels[args.type] || args.type,
          message: content || 'Conteúdo gerado com sucesso.',
        };
      }
    } catch (e) {
      console.error('[AdvancedTools] Content generation error:', e.message);
    }
    return { success: false, message: 'Erro ao gerar conteúdo. Tente novamente.' };
  },

  _calculateQuote(args, settings) {
    const catalog = settings?.aiCatalog || [
      { name: 'consultoria', price: 5000 },
      { name: 'social media', price: 8000 },
      { name: 'bot whatsapp', price: 15000 },
      { name: 'formação', price: 3500 },
      { name: 'marketing digital', price: 10000 },
      { name: 'desenvolvimento web', price: 20000 },
    ];

    const qty = args.quantity || 1;
    let total = 0;
    const items = args.services.map(s => {
      const lower = s.toLowerCase();
      const product = catalog.find(c => c.name.toLowerCase().includes(lower));
      const price = product ? product.price : 0;
      total += price * qty;
      return { name: s, unitPrice: price, quantity: qty, subtotal: price * qty };
    });

    return {
      success: true,
      quote: { items, total, currency: 'MZN' },
      message: `💼 *Orçamento*\n\n${items.map(i =>
        `• ${i.name}: ${i.unitPrice.toLocaleString('pt-MZ')} MZN × ${i.quantity} = ${i.subtotal.toLocaleString('pt-MZ')} MZN`
      ).join('\n')}\n\nTotal: *${total.toLocaleString('pt-MZ')} MZN*`,
    };
  },

  _sendNotification(args, context) {
    return {
      success: true,
      message: `Notificação ${args.type} agendada para envio.`,
      notification: { target: args.target, type: args.type, message: args.message },
    };
  },

  async _analyzeSentiment(args, context) {
    if (!process.env.OPENAI_KEY) {
      return { success: true, sentiment: 'neutral', confidence: 0.5, message: 'Análise de sentimento simulada: neutro.' };
    }

    try {
      const res = await fetch(`${process.env.OPENAI_API_BASE || 'https://api.openai.com/v1'}/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: process.env.AI_MODEL_FAST || 'gpt-4o-mini',
          messages: [
            { role: 'system', content: 'Analisa o sentimento desta conversa. Responde com: positivo, negativo ou neutro. Depois um score de 0-100 e uma frase de justificativa.' },
            { role: 'user', content: args.conversation_context },
          ],
          max_tokens: 100,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const content = data.choices?.[0]?.message?.content;
        return { success: true, analysis: content, message: content || 'Análise completa.' };
      }
    } catch (e) {
      console.error('[AdvancedTools] Sentiment error:', e.message);
    }
    return { success: true, sentiment: 'neutral', message: 'Sentimento analisado: neutro.' };
  },

  _updatePipeline(args, userJid) {
    Memory.updateUserProfile(userJid, {
      last_intent: `pipeline_update:${args.stage}`,
      purchase_stage: args.stage === 'won' ? 'purchase' : args.stage === 'lost' ? 'awareness' : args.stage,
    });

    const stageEmoji = {
      lead: '🆕', qualified: '✅', proposal: '📋',
      negotiation: '🤝', won: '🎉', lost: '😔',
    };

    return {
      success: true,
      message: `${stageEmoji[args.stage] || '📌'} Pipeline actualizado: ${args.stage}\n${args.notes || ''}`,
    };
  },
};

// Importar TOOL_DEFINITIONS do módulo ESM
import { TOOL_DEFINITIONS } from './agentTools.js';

// Combinar todas as ferramentas
export function getAllToolDefinitions() {
  return [...TOOL_DEFINITIONS, ...ADVANCED_TOOL_DEFINITIONS];
}

export default { ADVANCED_TOOL_DEFINITIONS, AdvancedToolExecutor };
