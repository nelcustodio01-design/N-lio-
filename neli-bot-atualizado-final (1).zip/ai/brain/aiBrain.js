// ═══════════════════════════════════════════════════════════════
//  AI BRAIN — Cérebro de IA de Nível Elite
//  Nel-Aviso-Bot-Moz 🇲🇿 — Raciocínio Autónomo
//
//  Arquitectura:
//  • LLM: GPT-4o (com fallback para gpt-4o-mini)
//  • Memória: Curto prazo (histórico) + Longo prazo (perfil)
//  • Tools: Execução autónoma de tarefas
//  • Multimodal: Áudio, Imagem, Documento
//  • Vendas: Funil consultivo adaptativo
// ═══════════════════════════════════════════════════════════════
import fetch from 'node-fetch';
import Memory from '../memory/conversationMemory.js';
import MediaProcessor from '../multimodal/mediaProcessor.js';
import { TOOL_DEFINITIONS, ToolExecutor } from '../tools/agentTools.js';

// ── Configuração ─────────────────────────────────────────────
const OPENAI_BASE = process.env.OPENAI_API_BASE || 'https://api.openai.com/v1';
const OPENAI_KEY  = process.env.OPENAI_API_KEY  || '';
const MODEL_MAIN  = process.env.AI_MODEL        || 'gpt-4o';
const MODEL_FAST  = process.env.AI_MODEL_FAST   || 'gpt-4o-mini';

// ── Prompt de Sistema (Identidade do Agente) ─────────────────
function buildSystemPrompt(settings, profileSummary = '') {
  const botName = settings?.botName || 'assistente automático do Nel';
  const ownerName = settings?.ownerName || 'Nel';
  const customInstructions = settings?.aiCustomInstructions || '';

  return `És o ${botName}, assistente automático do Nel, da Nel Net Express.

## Identidade e privacidade
- Nunca digas que és uma pessoa, o Nel, ou que estás online, disponível 24 horas ou que responderás dentro de um prazo.
- Se perguntarem, explica com naturalidade que és o assistente automático do Nel.
- Fala em português de Moçambique, de forma calorosa, clara e respeitosa.
- Não inventes preços, formas de pagamento, disponibilidade, confirmação de pagamentos ou prazos.
- Só usa preços e pacotes que estejam no catálogo configurado. Se não tiver acesso à informação, diz isso e encaminha para o Nel sem fingir que já o avisaste.
- Pagamentos e comprovativos aguardam confirmação manual na aplicação da operadora. Nunca declares um comprovativo autêntico.
- Para uma situação que só o Nel possa resolver, explica que precisa da intervenção dele e não prometas resposta imediata.
- Em grupos, não reveles valores, pedidos, histórico ou dados pessoais de um cliente. Encaminha pedidos privados para a conversa directa com o bot.
- Não guardes nem repitas conteúdo do grupo que não seja necessário ao atendimento.
- O tom é humano e natural, mas a identidade deve continuar claramente automática.
- O nome configurado do responsável é ${ownerName}.
${customInstructions ? `\n## INSTRUÇÕES ADICIONAIS\n${customInstructions}` : ''}
${profileSummary}

Data/hora actual: ${new Date().toLocaleString('pt-MZ', { timeZone: 'Africa/Maputo' })}`;
}

// ── Motor Principal ──────────────────────────────────────────
const AIBrain = {

  /**
   * Processar uma mensagem e gerar resposta inteligente
   * @param {object} m        - Mensagem serializada
   * @param {object} context  - { sock, settings, DB }
   * @returns {string|null}   - Resposta ou null se não deve responder
   */
  async process(m, context = {}) {
    const { sock, settings, DB } = context;
    const userJid = m.sender;
    const chatJid = m.chat;

    try {
      // 1. Processar media se necessário
      const processed = await MediaProcessor.processMessage(m);
      const userText  = processed.text;

      if (!userText || userText.trim() === '') return null;

      // Em grupos, só processamos mensagens dirigidas ao bot; o histórico
      // integral de grupo não é persistido nem reutilizado.
      const persistConversation = !m.isGroup;

      // 2. Construir contexto do perfil
      const profileSummary = persistConversation ? Memory.buildProfileSummary(userJid) : '';
      const systemPrompt   = buildSystemPrompt(settings, profileSummary);

      // 3. Obter histórico de conversa
      const history = persistConversation ? Memory.getHistory(userJid, chatJid, 15) : [];

      // 4. Adicionar mensagem actual ao histórico
      if (persistConversation) {
        Memory.addMessage(userJid, chatJid, 'user', userText);
        Memory.incrementInteractions(userJid);
      }

      // 5. Construir payload para o LLM
      const messages = [
        { role: 'system', content: systemPrompt },
        ...history,
        { role: 'user', content: userText },
      ];

      // 6. Primeira chamada ao LLM (com tools)
      let response = await _callLLM(messages, persistConversation ? TOOL_DEFINITIONS : [], MODEL_MAIN);

      // 7. Processar tool calls se existirem
      let finalContent = null;
      let iterations   = 0;
      const MAX_ITER   = 5; // máx 5 ciclos de tool use

      while (response.finish_reason === 'tool_calls' && iterations < MAX_ITER) {
        iterations++;
        const toolCalls = response.message.tool_calls || [];
        const toolResults = [];

        for (const toolCall of toolCalls) {
          const toolName = toolCall.function.name;
          let toolArgs   = {};
          try {
            toolArgs = JSON.parse(toolCall.function.arguments || '{}');
          } catch {}

          console.log(`[AIBrain] 🔧 Tool: ${toolName}`, toolArgs);

          const result = await ToolExecutor.execute(toolName, toolArgs, {
            userJid, chatJid, sock, settings,
          });

          toolResults.push({
            tool_call_id: toolCall.id,
            role: 'tool',
            content: JSON.stringify(result),
          });

          // Acção especial: handoff para humano
          if (toolName === 'request_human_handoff') {
            finalContent = result.handoff
              ? 'O seu caso precisa do Nel. Já lhe enviei uma notificação para rever a situação; não consigo garantir quando ele responderá.'
              : 'O seu caso precisa do Nel, mas não consegui enviar-lhe o aviso agora. Por favor, tente novamente mais tarde ou contacte-o directamente.';
          }
        }

        if (finalContent) break;

        // Continuar conversa com resultados das tools
        messages.push(response.message);
        messages.push(...toolResults);

        response = await _callLLM(messages, persistConversation ? TOOL_DEFINITIONS : [], MODEL_MAIN);
      }

      // 8. Extrair conteúdo final
      if (!finalContent) {
        finalContent = response.message?.content || null;
      }

      if (!finalContent) return null;

      // 9. Guardar resposta no histórico
      if (persistConversation) Memory.addMessage(userJid, chatJid, 'assistant', finalContent);

      return finalContent;

    } catch (e) {
      console.error('[AIBrain] Erro ao processar:', e.message);
      return '⚠️ Ocorreu um erro temporário. Por favor tenta novamente em alguns segundos.';
    }
  },

  /**
   * Gerar resposta rápida (sem tools, modelo mais rápido)
   * Útil para respostas simples como saudações
   */
  async quickReply(prompt, systemContext = '') {
    try {
      const messages = [
        { role: 'system', content: systemContext || 'Responde de forma breve e amigável em Português.' },
        { role: 'user',   content: prompt },
      ];
      const response = await _callLLM(messages, [], MODEL_FAST);
      return response.message?.content || null;
    } catch (e) {
      console.error('[AIBrain] quickReply error:', e.message);
      return null;
    }
  },

  /**
   * Verificar se uma mensagem deve activar o modo IA
   * (detectar intenção de conversa natural vs comando)
   */
  async shouldActivateAI(text, settings) {
    // Palavras-chave que activam a IA
    const triggers = settings?.aiTriggers || [
      'olá', 'ola', 'bom dia', 'boa tarde', 'boa noite',
      'preciso', 'quero', 'quanto', 'como', 'ajuda',
      'informação', 'informacao', 'produto', 'serviço', 'servico',
      'preço', 'preco', 'comprar', 'contratar',
    ];

    const lower = (text || '').toLowerCase().trim();

    // Se começar com prefixo de comando, não activar IA
    const prefixes = settings?.prefixes || ['.', '!', '/'];
    if (prefixes.some(p => lower.startsWith(p))) return false;

    // Verificar triggers
    return triggers.some(t => lower.includes(t));
  },

  /**
   * Obter estatísticas do sistema de IA
   */
  getStats() {
    return Memory.getStats();
  },
};

// ── Chamada ao LLM ───────────────────────────────────────────
async function _callLLM(messages, tools = [], model = MODEL_MAIN) {
  const payload = {
    model,
    messages,
    temperature: 0.7,
    max_tokens: 800,
  };

  if (tools && tools.length > 0) {
    payload.tools       = tools;
    payload.tool_choice = 'auto';
  }

  const res = await fetch(`${OPENAI_BASE}/chat/completions`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${OPENAI_KEY}`,
      'Content-Type':  'application/json',
    },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`LLM API error (${res.status}): ${err}`);
  }

  const data   = await res.json();
  const choice = data.choices?.[0];

  if (!choice) throw new Error('LLM returned no choices');

  return {
    message:       choice.message,
    finish_reason: choice.finish_reason,
    usage:         data.usage,
  };
}

export default AIBrain;
