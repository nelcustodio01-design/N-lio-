import settings from '#settings';
import DB from '#db';

export default {
  command: ['humor', 'mood', 'humorperfil'],
  category: 'profile',
  description: 'Partilhar humor actual',
  async run({ msg, args, usedPrefix, command, text }) {
    const humores = ['😊 Feliz', '😴 Cansado', '🔥 Motivado', '😎 Relaxado', '🤔 Pensativo', '🎉 Festivo', '💪 Forte', '😌 Calmo'];
    const humor = humores[Math.floor(Math.random() * humores.length)];
    return msg.reply(`💭 *HUMOR*\n\n${humor}\n\n💡 Define o teu humor: *${usedPrefix}humor <estado>*`);
  }
};
