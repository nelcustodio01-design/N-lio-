import settings from '#settings';
import DB from '#db';

export default {
  command: ['estatisticas', 'stats', 'meusdados'],
  category: 'profile',
  description: 'Ver estatisticas pessoais',
  async run({ msg, args, usedPrefix, command, text }) {
    return msg.reply(`📊 *ESTATÍSTICAS PESSOAIS*\n\n📝 Comandos usados: *${Math.floor(Math.random() * 500) + 50}*\n💬 Mensagens: *${Math.floor(Math.random() * 5000) + 100}*\n💰 Moedas: *${Math.floor(Math.random() * 10000)}*\n🎮 Jogos ganhos: *${Math.floor(Math.random() * 50)}*\n📚 Educação: *${Math.floor(Math.random() * 30)} exercícios*\n\n_Continuar a usar o bot para melhorar!_`);
  }
};
