import DB from '#db';
export default {
  command:['registro','registrar','register','reg','entrar'],
  category:'perfil',
  description:'Registar no sistema do bot.',
  run: async ({ msg, sock }) => {
    const user = DB.getUser(msg.sender);
    const nome = msg.pushName||msg.sender.split('@')[0];
    if (!user.name) {
      DB.setUser(msg.sender,'name',nome);
    }
    const chat = DB.getChatUser(msg.chat,msg.sender);
    return msg.reply(
`✅ *REGISTO COMPLETO!*

👤 *Nome:* ${user.name||nome}
⭐ *Nível:* ${user.level||0}
🏆 *XP:* ${user.exp||0}
💰 *Coins:* ${chat.coins||0}

🎮 *Comandos disponíveis:*
▸ *perfil* — Ver o teu perfil
▸ *lvl* — Ver nível e XP
▸ *afk* — Modo ausente

_Bem-vindo(a) ao Nel-Aviso-Bot-Moz! 🇲🇿_`
    );
  },
};
