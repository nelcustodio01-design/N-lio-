import settings from '#settings';
import DB from '#db';
export default {
  command: ['jardim', 'garden', 'planta'],
  category: 'profile',
  description: 'Jardim virtual',
  async run({ msg, sock, args, text, sender }) {
    await msg.reply(`⚙️ A processar: _jardim_\n\n✅ Feito!`);
  },
};
