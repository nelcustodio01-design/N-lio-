import settings from '#settings';
import DB from '#db';
export default {
  command: ['gym', 'academia', 'treino'],
  category: 'profile',
  description: 'Treino na academia',
  async run({ msg, sock, args, text, sender }) {
    await msg.reply(`⚙️ A processar: _gym_\n\n✅ Feito!`);
  },
};
