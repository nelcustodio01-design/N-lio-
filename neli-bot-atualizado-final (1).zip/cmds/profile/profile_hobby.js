import settings from '#settings';
import DB from '#db';

export default {
  command: ['hobby', 'passatempo', 'interesse'],
  category: 'profile',
  description: 'Gerir hobbies',
  async run({ msg, args, usedPrefix, command, text }) {
    const hobbies = ['🎮 Gaming', '📚 Leitura', '🎵 Música', '⚽ Desporto', '🎨 Arte', '💻 Programação', '📷 Fotografia', '🍳 Culinária'];
    const hobby = hobbies[Math.floor(Math.random() * hobbies.length)];
    return msg.reply(`🎯 *HOBBY ALEATÓRIO*\n\nExperimenta: *${hobby}*\n\n💡 Quem sabe não te apaixonas?`);
  }
};
