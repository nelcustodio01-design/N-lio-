/**
 * Comando de Agentes Especializados (Nível Deus - Fase 2)
 * Nel-Aviso-Bot-Moz 🇲🇿
 */
import db from '#db';

export default {
  command: ['agentes', 'agents', 'multiagent', 'multiagente'],
  category: 'nível deus',
  description: 'Gerir agentes especializados do sistema Nível Deus. 🤖',
  ownerOnly: true,
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    try {
      const sub = args[0]?.toLowerCase();

      if (!sub || sub === 'lista' || sub === 'list') {
        return msg.reply(
          `🤖 *AGENTES ESPECIALIZADOS — NÍVEL DEUS*\n\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `🔵 *Nel Vendas*\n` +
          `   Vendas consultivas, funil de conversão, negociação\n` +
          `   Keywords: preço, comprar, desconto, orçamento\n\n` +
          `🟢 *Nel Suporte*\n` +
          `   Suporte técnico, troubleshooting, FAQ\n` +
          `   Keywords: problema, erro, ajuda, configuração\n\n` +
          `🟡 *Nel Marketing*\n` +
          `   Marketing digital, conteúdo, redes sociais, growth\n` +
          `   Keywords: marketing, campanha, instagram, estratégia\n\n` +
          `🟠 *Nel Pesquisa*\n` +
          `   Pesquisa de mercado, análise competitiva, tendências\n` +
          `   Keywords: pesquisa, mercado, concorrência, análise\n\n` +
          `🟣 *Nel Analytics*\n` +
          `   Dados, métricas, KPIs, relatórios, ROI\n` +
          `   Keywords: dados, métricas, KPI, relatório, números\n\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `💡 *Uso:*\n` +
          `• *${usedPrefix + command} stats* — Estatísticas\n` +
          `• *${usedPrefix + command} activar <agente>* — Activar modo agente\n` +
          `• *${usedPrefix + command} info <agente>* — Detalhes do agente`
        );
      }

      if (sub === 'stats' || sub === 'estatísticas' || sub === 'estatisticas') {
        return msg.reply(
          `📊 *ESTATÍSTICAS DOS AGENTES*\n\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `Total de agentes: *5*\n` +
          `Ferramentas disponíveis: *16+*\n` +
          `Modo de roteamento: *Automático (Keyword + LLM)*\n` +
          `Transferência entre agentes: *Activa*\n` +
          `Memória compartilhada: *Activa*\n\n` +
          `Estado: *SISTEMA OPERACIONAL* ✅`
        );
      }

      if (sub === 'activar' || sub === 'ativar') {
        const agentName = args[1]?.toLowerCase();
        const agentMap = {
          vendas: 'sales', suporte: 'support', marketing: 'marketing',
          pesquisa: 'research', analytics: 'analytics',
        };
        const agentId = agentMap[agentName];
        if (!agentId) {
          return msg.reply(
            `❧ Agente não encontrado. Opções:\n` +
            `• vendas, suporte, marketing, pesquisa, analytics`
          );
        }
        // Guardar preferência do agente
        db.setChat(msg.chat, 'preferredAgent', agentId);
        const names = { sales: 'Nel Vendas', support: 'Nel Suporte', marketing: 'Nel Marketing', research: 'Nel Pesquisa', analytics: 'Nel Analytics' };
        return msg.reply(`✅ Agente *${names[agentId]}* activado para este chat.`);
      }

      if (sub === 'info') {
        const agentName = args[1]?.toLowerCase();
        const agentMap = {
          vendas: 'sales', suporte: 'support', marketing: 'marketing',
          pesquisa: 'research', analytics: 'analytics',
        };
        const agentId = agentMap[agentName];
        if (!agentId) {
          return msg.reply(`❧ Agente não encontrado.`);
        }
        const details = {
          sales: 'Especialista em vendas consultivas. Usa técnicas SPIN, BANT e Sandler. Gerencia pipeline de vendas e faz qualificação de leads.',
          support: 'Especialista em suporte técnico. Segue metodologia de 6 passos. Gerencia tickets e escalonamento inteligente.',
          marketing: 'Especialista em marketing digital. Cria conteúdo, campanhas e estratégias de growth para o mercado moçambicano.',
          research: 'Especialista em pesquisa de mercado. Faz análise competitiva, pesquisa de preços e relatórios de tendências.',
          analytics: 'Especialista em análise de dados. Monitora KPIs, gera relatórios, faz previsões e análise de ROI.',
        };
        return msg.reply(`🤖 *${agentName.toUpperCase()}*\n\n${details[agentId]}`);
      }

      return msg.reply(
        `🤖 *AGENTES*\n\n` +
        `▸ *${usedPrefix + command} lista* — Ver todos os agentes\n` +
        `▸ *${usedPrefix + command} stats* — Estatísticas\n` +
        `▸ *${usedPrefix + command} activar <nome>* — Activar agente\n` +
        `▸ *${usedPrefix + command} info <nome>* — Detalhes`
      );
    } catch (e) {
      return msg.reply(`❧ Erro: ${e.message}`);
    }
  }
};
