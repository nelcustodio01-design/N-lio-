/**
 * Comando de Proatividade e Predição (Nível Deus - Fase 3)
 * Nel-Aviso-Bot-Moz 🇲🇿
 */
import db from '#db';

export default {
  command: ['proativo', 'proactive', 'predição', 'predicao', 'feedback'],
  category: 'nível deus',
  description: 'Gerir proatividade, predição e aprendizagem contínua. 🎯',
  ownerOnly: true,
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    try {
      const sub = args[0]?.toLowerCase();

      if (!sub || sub === 'status' || sub === 'resumo') {
        const actions = db.prepare('SELECT COUNT(*) as c FROM proactive_actions').get()?.c || 0;
        const predictions = db.prepare('SELECT COUNT(*) as c FROM prediction_log').get()?.c || 0;
        const abTests = db.prepare("SELECT COUNT(*) as c FROM ab_tests WHERE status = 'active'").get()?.c || 0;
        const feedback = db.prepare('SELECT COUNT(*) as c FROM feedback_log').get()?.c || 0;
        const patterns = db.prepare('SELECT COUNT(*) as c FROM learning_patterns').get()?.c || 0;

        return msg.reply(
          `🎯 *PROATIVIDADE & PREDIÇÃO — NÍVEL DEUS*\n\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `📊 *Estatísticas:*\n` +
          `• Acções proactivas: ${actions}\n` +
          `• Predições feitas: ${predictions}\n` +
          `• Testes A/B activos: ${abTests}\n` +
          `• Feedback registado: ${feedback}\n` +
          `• Padrões aprendidos: ${patterns}\n\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `💡 *Uso:*\n` +
          `• *${usedPrefix + command} predicao <jid>* — Predizer intenção\n` +
          `• *${usedPrefix + command} feedback <tipo> <nota>* — Registar feedback\n` +
          `• *${usedPrefix + command} aprendi* — Ver padrões aprendidos\n` +
          `• *${usedPrefix + command} ab* — Testes A/B`
        );
      }

      if (sub === 'feedback') {
        const type = args[1] || 'general';
        const rating = parseInt(args[2]) || 0;
        const text = args.slice(3).join(' ') || '';
        db.prepare(`
          INSERT INTO feedback_log (user_jid, feedback_type, feedback_text, rating)
          VALUES (?, ?, ?, ?)
        `).run(msg.sender, type, text, rating);
        return msg.reply(`✅ *Feedback registado*\n\nTipo: ${type}\nNota: ${rating}/5\nComentário: ${text || 'Nenhum'}`);
      }

      if (sub === 'aprendi' || sub === 'learned' || sub === 'patterns') {
        const patterns = db.prepare('SELECT * FROM learning_patterns ORDER BY confidence DESC LIMIT 10').all();
        if (patterns.length === 0) {
          return msg.reply('🧠 *PADRÕES APRENDIDOS*\n\nNenhum padrão registado ainda.');
        }
        let text = `🧠 *PADRÕES APRENDIDOS*\n\n`;
        for (const p of patterns) {
          const data = JSON.parse(p.pattern_data);
          text += `▸ ${p.pattern_type} (confiança: ${Math.round(p.confidence * 100)}%)\n`;
          text += `  Occorrências: ${p.occurrences} • Última nota: ${data.lastRating || 'N/A'}\n\n`;
        }
        return msg.reply(text);
      }

      if (sub === 'ab' || sub === 'test') {
        const tests = db.prepare("SELECT * FROM ab_tests WHERE status = 'active'").all();
        if (tests.length === 0) {
          return msg.reply('🧪 *TESTES A/B*\n\nNenhum teste activo.');
        }
        let text = `🧪 *TESTES A/B ACTIVOS*\n\n`;
        for (const t of tests) {
          const rateA = t.group_a_count > 0 ? Math.round(t.group_a_conversions / t.group_a_count * 100) : 0;
          const rateB = t.group_b_count > 0 ? Math.round(t.group_b_conversions / t.group_b_count * 100) : 0;
          text += `▸ *${t.test_name}*\n`;
          text += `  Variante A: ${t.group_a_count} envios, ${rateA}% conversão\n`;
          text += `  Variante B: ${t.group_b_count} envios, ${rateB}% conversão\n\n`;
        }
        return msg.reply(text);
      }

      if (sub === 'predicao' || sub === 'predição' || sub === 'predict') {
        const userJid = args[1] || msg.sender;
        const profile = db.prepare('SELECT * FROM ai_user_profiles WHERE user_jid = ?').get(userJid);
        if (!profile) return msg.reply(`❧ Utilizador não encontrado.`);
        return msg.reply(
          `🔮 *PREDIÇÃO DE INTENÇÃO*\n\n` +
          `Utilizador: ${userJid.split('@')[0]}\n` +
          `Nome: ${profile.name || 'Desconhecido'}\n` +
          `Etapa no funil: ${profile.purchase_stage}\n` +
          `Interacções: ${profile.total_interactions}\n` +
          `Última intenção: ${profile.last_intent || 'N/A'}\n\n` +
          `_A predição automática é activada durante conversas._`
        );
      }

      return msg.reply(
        `🎯 *PROATIVIDADE*\n\n` +
        `▸ *${usedPrefix + command} status* — Resumo\n` +
        `▸ *${usedPrefix + command} predicao <jid>* — Predizer\n` +
        `▸ *${usedPrefix + command} feedback <tipo> <nota>* — Feedback\n` +
        `▸ *${usedPrefix + command} aprendi* — Padrões\n` +
        `▸ *${usedPrefix + command} ab* — Testes A/B`
      );
    } catch (e) {
      return msg.reply(`❧ Erro: ${e.message}`);
    }
  }
};
