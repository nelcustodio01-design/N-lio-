/**
 * Comando: .seguranca — Gestão de Segurança
 * Nel-Aviso-Bot-Moz 🇲🇿 — Nível Deus Edition
 */
export default {
  name: 'seguranca',
  aliases: ['security', 'seg', 'bloq'],
  category: 'niveldeus',
  desc: 'Gestão de segurança, rate limiting e bloqueios',
  usage: '.seguranca [status|bloquear <jid>|desbloquear <jid>|eventos|rate]',
  ownerOnly: true,
};

export async function execute(sock, msg, store, args) {
  const chatJid = msg.key.remoteJid;
  const senderJid = msg.key.participant || msg.key.remoteJid;

  if (!args[0]) {
    // Status geral
    const stats = global.securityEngine?.getStats() || {};
    const rate = global.securityEngine?.checkRateLimit(senderJid, 'message');

    return sock.sendMessage(chatJid, {
      text: `🔐 *Painel de Segurança — Nel-Bot*\n\n` +
        `🚫 Utilizadores Bloqueados: ${stats.blockedUsers || 0}\n` +
        `⚡ Violações Rate Limit: ${stats.rateLimitViolations || 0}\n` +
        `🛡️ Injeções de Prompt: ${stats.promptInjections || 0}\n` +
        `📋 Eventos Totais: ${stats.totalEvents || 0}\n\n` +
        `📡 Teu Rate Limit: ${rate?.remaining || 0} restantes\n\n` +
        `*Comandos:*\n` +
        `.seguranca bloquear <jid> <motivo> <horas>\n` +
        `.seguranca desbloquear <jid>\n` +
        `.seguranca eventos\n` +
        `.seguranca rate`,
    });
  }

  switch (args[0].toLowerCase()) {
    case 'bloquear':
    case 'block': {
      const jid = args[1];
      const reason = args.slice(2).join(' ') || 'Bloqueio manual';
      if (!jid) return sock.sendMessage(chatJid, { text: '❌ Usa: .seguranca bloquear <jid> <motivo> <horas>' });

      const hours = parseInt(args[args.length - 1]);
      const duration = isNaN(hours) ? null : hours;
      const actualReason = isNaN(hours) ? reason : args.slice(2, -1).join(' ');

      global.securityEngine?.blockUser(jid.includes('@') ? jid : `${jid}@s.whatsapp.net`, actualReason, duration);
      return sock.sendMessage(chatJid, {
        text: `🚫 Utilizador bloqueado!\nJID: ${jid}\nMotivo: ${actualReason}\nDuração: ${duration ? `${duration}h` : 'Permanente'}`,
      });
    }

    case 'desbloquear':
    case 'unblock': {
      const jid = args[1];
      if (!jid) return sock.sendMessage(chatJid, { text: '❌ Usa: .seguranca desbloquear <jid>' });

      global.securityEngine?.unblockUser(jid.includes('@') ? jid : `${jid}@s.whatsapp.net`);
      return sock.sendMessage(chatJid, { text: `✅ Utilizador desbloqueado: ${jid}` });
    }

    case 'eventos':
    case 'events': {
      const events = global.securityEngine?.getRecentEvents(10) || [];
      const text = events.length > 0
        ? `📋 *Últimos 10 Eventos de Segurança:*\n\n${events.map(e => `• [${e.severity}] ${e.event_type}: ${e.details?.substring(0, 60)} (${new Date(e.created_at).toLocaleString('pt-MZ')})`).join('\n')}`
        : '📋 Nenhum evento recente.';
      return sock.sendMessage(chatJid, { text });
    }

    case 'rate': {
      const rate = global.securityEngine?.checkRateLimit(senderJid, 'message');
      return sock.sendMessage(chatJid, {
        text: `📊 *Rate Limit:*\nRestantes: ${rate?.remaining || 0}\nLimite: 30 msg/min\nJanela: 60s`,
      });
    }

    default:
      return sock.sendMessage(chatJid, { text: '❌ Comando não reconhecido. Usa .seguranca para ver opções.' });
  }
}
