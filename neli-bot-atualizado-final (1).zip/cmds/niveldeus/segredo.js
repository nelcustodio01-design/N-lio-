// ═══════════════════════════════════════════════════════════════
//  COMANDO .segredo — Comunicação encriptada bot-dono
//  Nel-Aviso-Bot-Moz 🇲🇿 — Nível Deus Edition
//
//  Permite ao dono enviar comandos secretos encriptados
//  que ninguém consegue ler na tela do WhatsApp
// ═══════════════════════════════════════════════════════════════
import crypto from 'crypto';

const SECRET_KEY = 'nel-bot-moz-2025-super-secret-key';

function encrypt(text) {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(SECRET_KEY, 'utf8').slice(0, 32), iv);
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  return iv.toString('hex') + ':' + encrypted;
}

function decrypt(encrypted) {
  try {
    const parts = encrypted.split(':');
    const iv = Buffer.from(parts[0], 'hex');
    const encryptedText = parts[1];
    const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(SECRET_KEY, 'utf8').slice(0, 32), iv);
    let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch {
    return null;
  }
}

export default {
  name: 'segredo',
  alias: ['secreto', 'secret', 'encriptado'],
  desc: 'Comunicação encriptada entre bot e dono',
  category: 'Nível Deus',
  ownerOnly: true,
  async run({ msg, sock, args }) {
    const subcmd = args[0]?.toLowerCase();
    const text = args.slice(1).join(' ');

    if (subcmd === 'enviar' || subcmd === 'send') {
      if (!text) return msg.reply('Uso: .segredo enviar <mensagem>');
      const encrypted = encrypt(text);
      await msg.reply(
        `🔒 *Mensagem Encriptada*\n\n` +
        encrypted +
        `\n\n_Decifra com: .segredo ler <código>_`
      );
      return;
    }

    if (subcmd === 'ler' || subcmd === 'read') {
      if (!text) return msg.reply('Uso: .segredo ler <código>');
      const decrypted = decrypt(text);
      if (decrypted) {
        await msg.reply(`🔓 *Decifrado:*\n\n${decrypted}`);
      } else {
        await msg.reply('❌ Código inválido ou corrompido.');
      }
      return;
    }

    if (subcmd === 'status') {
      await msg.reply(
        '🔒 *Segredo — Status*\n\n' +
        'Encriptação: AES-256-CBC\n' +
        'Chave: [PROTEGIDA]\n' +
        'Funcionalidade: Comunicação segura bot-dono'
      );
      return;
    }

    await msg.reply(
      '🔒 *Modo Segredo*\n\n' +
      'Encripta mensagens que ninguém consegue ler.\n\n' +
      `*Comandos:*\n` +
      `▸ \`.segredo enviar <msg>\` — Encriptar\n` +
      `▸ \`.segredo ler <código>\` — Decifrar\n` +
      `▸ \`.segredo status\` — Estado`
    );
  },
};
