// ═══════════════════════════════════════════════════════════════
//  COMANDO .ativar / .desativar — Permissão por chat
//  Nel-Aviso-Bot-Moz 🇲🇿 — Nível Deus SUPREMO
//
//  Resolve o problema do bot responder em qualquer grupo/chat.
//  Só responde onde o dono activou explicitamente.
// ═══════════════════════════════════════════════════════════════
import DB from '#db';
import {
  activateChat,
  deactivateChat,
  enablePrefixless,
  disablePrefixless,
  listActivatedChats,
  isChatActivated,
  isPrefixlessEnabled,
} from '../../core/chatManager.js';
import { formatActivatedList } from '../../core/chatManager.js';

export default {
  name: 'ativar',
  alias: ['ativar', 'ativacao', 'ativacao-bot', 'enable', 'enablebot'],
  desc: 'Activar o bot neste chat (só responde aqui quando activado)',
  category: 'Nível Deus',
  ownerOnly: true,
  async run({ msg, sock, args, chatId, isGroup }) {
    const subcmd = args[0]?.toLowerCase();

    // ── Activar ──────────────────────────────────────────────
    if (subcmd === 'on' || subcmd === 'sim' || subcmd === 'activar') {
      activateChat(chatId, DB);
      await msg.reply(
        `✅ *Bot ACTIVADO neste chat!*\n\n` +
        `O bot vai responder aqui agora.\n` +
        `Para comandos sem prefixo, usa: \`.ativar sem-prefixo\`\n\n` +
        `💡 *Como funciona:*\n` +
        `O bot só responde em chats onde o dono activou.\n` +
        `Em todos os outros chats, o bot fica silencioso.\n\n` +
        `Chat: ${chatId.split('@')[0]}`
      );
      return;
    }

    // ── Desactivar ───────────────────────────────────────────
    if (subcmd === 'off' || subcmd === 'nao' || subcmd === 'desactivar') {
      deactivateChat(chatId, DB);
      await msg.reply(
        `❌ *Bot DESACTIVADO neste chat!*\n\n` +
        `O bot vai ficar silencioso aqui.\n` +
        `Ninguém (excepto o dono) vai conseguir usar comandos.\n\n` +
        `Chat: ${chatId.split('@')[0]}`
      );
      return;
    }

    // ── Activar sem prefixo ──────────────────────────────────
    if (subcmd === 'sem-prefixo' || subcmd === 'sem-prefix') {
      enablePrefixless(chatId, DB);
      await msg.reply(
        `🔓 *Comandos SEM PREFIXO activados!*\n\n` +
        `Agora pode-se usar comandos sem o "." (ex: "menu" em vez de ".menu")\n\n` +
        `⚠️ Cuidado: isto faz o bot responder a mais mensagens.\n` +
        `Chat: ${chatId.split('@')[0]}`
      );
      return;
    }

    // ── Desactivar sem prefixo ───────────────────────────────
    if (subcmd === 'com-prefixo' || subcmd === 'com-prefix') {
      disablePrefixless(chatId, DB);
      await msg.reply(
        `🔒 *Comandos SEM PREFIXO desactivados!*\n\n` +
        `Agora só responde com prefixo (ex: ".menu")\n` +
        `Chat: ${chatId.split('@')[0]}`
      );
      return;
    }

    // ── Ver estado ───────────────────────────────────────────
    if (subcmd === 'status' || subcmd === 'estado') {
      const activated = isChatActivated(chatId);
      const prefixless = isPrefixlessEnabled(chatId);
      await msg.reply(
        `📊 *Estado deste chat*\n\n` +
        `Bot activado: ${activated ? '✅ SIM' : '❌ NÃO'}\n` +
        `Sem prefixo: ${prefixless ? '✅ SIM' : '❌ NÃO'}\n` +
        `Chat: ${chatId.split('@')[0]}\n\n` +
        `💡 Para activar: \`.ativar on\`\n` +
        `💡 Para desactivar: \`.ativar off\`\n` +
        `💡 Para sem prefixo: \`.ativar sem-prefixo\`\n` +
        `💡 Para ver todos: \`.ativar lista\``
      );
      return;
    }

    // ── Listar todos activados ───────────────────────────────
    if (subcmd === 'lista' || subcmd === 'list') {
      const list = listActivatedChats();
      const formatted = formatActivatedList(list);
      await msg.reply(
        `📋 *Chats Activados*\n\n` +
        `${formatted}\n\n` +
        `Total: ${list.length} chat(s)\n` +
        `🔓 = sem prefixo | 🔒 = com prefixo`
      );
      return;
    }

    // ── Ajuda ────────────────────────────────────────────────
    await msg.reply(
      `🔐 *Gestão de Permissão por Chat*\n\n` +
      `O bot só responde em chats onde foi activado.\n` +
      `Isso impede que responda em qualquer grupo/chato.\n\n` +
      `*Comandos:*\n` +
      `▸ \`.ativar on\` — Activar neste chat\n` +
      `▸ \`.ativar off\` — Desactivar neste chat\n` +
      `▸ \`.ativar status\` — Ver estado\n` +
      `▸ \`.ativar lista\` — Ver todos activados\n` +
      `▸ \`.ativar sem-prefixo\` — Permitir sem "."\n` +
      `▸ \`.ativar com-prefixo\` — Só com "."\n\n` +
      `⚠️ O dono pode sempre usar comandos em qualquer chat.`
    );
  },
};
