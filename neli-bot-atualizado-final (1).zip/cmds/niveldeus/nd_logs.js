import settings from '#settings';
import DB from '#db';
export default {
  command: ['logs', 'registos', 'verlogs'],
  category: 'niveldeus',
  description: 'Ver logs do bot em tempo real',
  ownerOnly: true,
  async run({ msg, sock, args, text }) {
    await msg.reply(`⚙️ A processar: _logs_\n\n✅ Feito!`);
  },
};
