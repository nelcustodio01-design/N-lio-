/**
 * .omega30 — Operações do runtime Omega 30
 */
export default {
  command: ['omega30', 'omega', 'swarm30'],
  category: 'nível deus',
  description: 'Executar o enxame multiagente e consultar ações sombra.',
  ownerOnly: true,
  run: async ({ msg, args }) => {
    const sub = (args[0] || 'ajuda').toLowerCase();
    const omega = global.omega30;
    if (!omega) return msg.reply('❌ Runtime Omega 30 indisponível.');

    if (sub === 'stats' || sub === 'estado') {
      const s = omega.getStats();
      return msg.reply(
        `🧬 *OMEGA 30 — ESTADO*\n\n` +
        `Versão: *${s.version}*\n` +
        `Planos executados: *${s.runs}*\n` +
        `Ações pendentes: *${s.pendingActions}*\n` +
        `Ações executadas: *${s.executedActions}*\n` +
        `Contextos omnicanal: *${s.contextRecords}*\n` +
        `Perfis de estilo: *${s.styleProfiles}*`
      );
    }

    if (sub === 'pendentes' || sub === 'acoes') {
      const actions = omega.listShadowActions('pending');
      if (!actions.length) return msg.reply('✅ Não existem ações sombra pendentes.');
      return msg.reply(
        `⏳ *AÇÕES À ESPERA DE APROVAÇÃO*\n\n` +
        actions.slice(0, 10).map(a =>
          `#${a.id} → ${a.target_jid}\n${a.message.slice(0, 120)}\nMotivo: ${a.reason || 'não indicado'}`
        ).join('\n\n') +
        `\n\nA aprovação é feita no dashboard.`
      );
    }

    const task = args.join(' ').trim();
    if (!task) {
      return msg.reply(
        `🧬 *OMEGA 30*\n\n` +
        `• .omega30 <tarefa> — criar plano paralelo\n` +
        `• .omega30 stats — estado do runtime\n` +
        `• .omega30 pendentes — ações à espera de aprovação`
      );
    }

    await msg.reply('🧬 A dividir a tarefa entre agentes especializados...');
    const result = await omega.runSwarm(task, {
      userJid: msg.sender || msg.key?.participant || msg.key?.remoteJid || '',
      chatJid: msg.chat || msg.key?.remoteJid || '',
    });
    return msg.reply(
      `✅ *PLANO OMEGA 30 CONCLUÍDO*\n\n` +
      `Run: #${result.runId}\n` +
      `Agentes: ${result.agents.join(', ')}\n` +
      `Tempo: ${result.durationMs}ms\n\n` +
      result.outputs.map(output => `• ${output}`).join('\n')
    );
  },
};