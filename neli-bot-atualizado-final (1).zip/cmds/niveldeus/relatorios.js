/**
 * Comando: .relatorios — Relatórios Automatizados
 * Nel-Aviso-Bot-Moz 🇲🇿 — Nível Deus Edition
 */
export default {
  name: 'relatorios',
  aliases: ['relatorio', 'report', 'reportes'],
  category: 'niveldeus',
  desc: 'Ver e gerar relatórios automáticos',
  usage: '.relatorios [diario|semanal|mensal|tendências]',
  ownerOnly: true,
};

export async function execute(sock, msg, store, args) {
  const chatJid = msg.key.remoteJid;

  if (!global.sentimentAnalyzer) {
    return sock.sendMessage(chatJid, { text: '❌ Módulo de relatórios não disponível.' });
  }

  const type = args[0]?.toLowerCase() || 'diario';

  let report;
  switch (type) {
    case 'diario':
    case 'daily':
      report = global.reportsEngine?.generateDailyReport();
      break;
    case 'semanal':
    case 'weekly':
      report = global.reportsEngine?.generateWeeklyReport();
      break;
    case 'mensal':
    case 'monthly':
      report = global.reportsEngine?.generateMonthlyReport();
      break;
    default:
      return sock.sendMessage(chatJid, {
        text: `📊 *Relatórios Disponíveis:*\n\n` +
          `.relatorios diario — Resumo do dia\n` +
          `.relatorios semanal — Tendências semanais\n` +
          `.relatorios mensal — Performance completa\n\n` +
          `Relatórios são enviados automaticamente para o dono.`,
      });
  }

  if (!report) {
    return sock.sendMessage(chatJid, { text: '❌ Erro ao gerar relatório.' });
  }

  const formatted = global.reportsEngine?.formatForWhatsApp(report) || JSON.stringify(report);
  return sock.sendMessage(chatJid, { text: formatted });
}
