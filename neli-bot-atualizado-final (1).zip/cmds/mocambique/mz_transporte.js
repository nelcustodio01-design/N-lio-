import settings from '#settings';
import DB from '#db';
export default {
  command: ['transporte', 'chapa', 'autocarro'],
  category: 'mocambique',
  description: 'Informacoes de transporte',
  async run({ msg, sock, args, text }) {
    await msg.reply(`🇲🇿 A buscar: _transporte_\n\n⏳ Aguarde...`);
  },
};
