// Detector de operador de rede moçambicana — Nel-Aviso-Bot-Moz 🇲🇿
const OPERADORES = {
  // Vodacom Moçambique (82, 84)
  '82': { nome: 'Vodacom', cor: '🔴', servicos: ['M-Pesa', 'MyVoda', 'VodaBiz'] },
  '84': { nome: 'Vodacom', cor: '🔴', servicos: ['M-Pesa', 'MyVoda'] },
  // Tmcel (82 começa por 820-829, mas principalmente 82 vs 84)
  '86': { nome: 'Tmcel', cor: '🟡', servicos: ['mKesh', 'Tmcel Data'] },
  '87': { nome: 'Tmcel', cor: '🟡', servicos: ['mKesh'] },
  // Movitel (83, 85)
  '83': { nome: 'Movitel', cor: '🟢', servicos: ['e-Mola', 'MoviNet'] },
  '85': { nome: 'Movitel', cor: '🟢', servicos: ['e-Mola', 'MoviNet'] },
};

const PROVINCIAS = {
  '1': 'Maputo Cidade', '2': 'Maputo Província', '3': 'Gaza', '4': 'Inhambane',
  '5': 'Sofala', '6': 'Manica', '7': 'Tete', '8': 'Zambézia',
  '9': 'Nampula', '10': 'Niassa', '11': 'Cabo Delgado'
};

function detectarOperador(numero) {
  // Limpar e normalizar
  let num = numero.replace(/\D/g, '');
  if (num.startsWith('258')) num = num.slice(3);
  if (num.startsWith('0')) num = num.slice(1);
  if (num.length !== 9) return null;

  const prefixo2 = num.slice(0, 2);
  const op = OPERADORES[prefixo2];
  if (!op) return null;

  // Tentar detectar prefixo de cidade (4º dígito)
  const digitoCidade = num[2];

  return {
    operador: op.nome,
    cor: op.cor,
    servicos: op.servicos,
    prefixo: prefixo2,
    numero: num,
    formatado: `+258 ${prefixo2} ${num.slice(2, 5)} ${num.slice(5, 7)} ${num.slice(7)}`,
    whatsapp: `258${num}@s.whatsapp.net`,
  };
}

export default {
  command: ['telefone', 'numero', 'operador', 'rede', 'simcard', 'numinfo'],
  category: 'mocambique',
  description: 'Identificar operador de um número moçambicano. 📱',
  run: async ({ msg, args, text, usedPrefix, command }) => {
    try {
      // Aceitar número mencionado, no texto, ou do utilizador actual
      const input = args[0] || text?.match(/\d[\d\s\-+]{7,}/)?.[0] || msg.sender.split('@')[0];

      if (!input || input === command) {
        return msg.reply(
          `📱 *IDENTIFICADOR DE NÚMERO MOÇAMBICANO*\n\n` +
          `✎ Uso: *${usedPrefix + command} 843 456 789*\n` +
          `✎ Também aceita: *258843456789* ou *+258 84 345 6789*\n\n` +
          `Detecta: Vodacom, Movitel, Tmcel e serviços disponíveis`
        );
      }

      const info = detectarOperador(input);
      if (!info) {
        return msg.reply(
          `❧ Número *${input}* não reconhecido como moçambicano.\n\n` +
          `▸ Prefixos válidos: 82, 84 (Vodacom) | 83, 85 (Movitel) | 86, 87 (Tmcel)\n` +
          `▸ Formato: 9 dígitos após +258`
        );
      }

      await msg.react('📱');

      const reply =
        `📱 *INFORMAÇÃO DO NÚMERO*\n\n` +
        `📞 *Número:* ${info.formatado}\n` +
        `${info.cor} *Operador:* ${info.operador}\n` +
        `📶 *Prefixo:* ${info.prefixo}x\n` +
        `💳 *Serviços disponíveis:*\n${info.servicos.map(s => `   ▸ ${s}`).join('\n')}\n\n` +
        `🌐 *WhatsApp ID:* \`${info.whatsapp}\`\n\n` +
        `📌 *Operadores em Moçambique:*\n` +
        `🔴 Vodacom: 82x, 84x — M-Pesa\n` +
        `🟢 Movitel: 83x, 85x — e-Mola\n` +
        `🟡 Tmcel:   86x, 87x — mKesh\n\n` +
        `_Nel-Aviso-Bot-Moz 🇲🇿_`;

      return msg.reply(reply);
    } catch (e) {
      return msg.reply(`❧ Erro: ${e.message}`);
    }
  }
};
