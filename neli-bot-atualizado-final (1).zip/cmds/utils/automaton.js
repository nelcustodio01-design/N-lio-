import moment from 'moment-timezone';

export default {
  command: ['aviso', 'automaton', 'schedule'],
  category: 'utils',
  description: 'Agenda um aviso automático para o grupo.',
  isAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    if (!args[0] || !args[1]) return msg.reply(`🤖 **NEXUS AUTOMATON**\n\nUso: *${usedPrefix + command} [HH:mm] [mensagem]*\nExemplo: *${usedPrefix + command} 09:00 Bom dia, equipe! Reunião em 10 min.*`);

    const timeStr = args[0];
    const message = args.slice(1).join(' ');
    
    const [hours, minutes] = timeStr.split(':').map(Number);
    if (isNaN(hours) || isNaN(minutes)) return msg.reply('❌ Formato de hora inválido. Use HH:mm (ex: 14:30).');

    await msg.react('🤖');
    await msg.reply(`✅ **AGENDAMENTO NEXUS:** O aviso será enviado às ${timeStr} para este grupo.`);

    // Lógica de verificação em loop para o agendamento
    const checkInterval = setInterval(async () => {
        const now = moment().tz('Africa/Maputo');
        if (now.hour() === hours && now.minute() === minutes) {
            const announcement = `
📢 **AVISO AUTOMÁTICO NEXUS**
━━━━━━━━━━━━━━━━━━━━━━

${message}

🚀 *Enviado via Nexus Automaton Singularity.*
            `;
            await sock.sendMessage(msg.chat, { text: announcement });
            clearInterval(checkInterval); // Executa uma vez e para
        }
    }, 30000); // Verifica a cada 30 segundos
  }
};
