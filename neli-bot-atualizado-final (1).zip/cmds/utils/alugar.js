import settings from '#settings';

export default {
  command: ['alugar', 'aluguer', 'aluguel'],
  category: 'alugar',
  description: 'Informações sobre aluguer do bot.',
  async run({ msg }) {
    try {
      const contact = settings.rentalContactNumber;
      const contactLine = contact
        ? `Condições e disponibilidade: https://wa.me/${contact}`
        : 'Para condições e disponibilidade, peça os dados de contacto ao responsável que partilhou este menu.';
      return await msg.reply(
        `💼 *ALUGA-SE O NEL-AVISO BOT*\n\n` +
        `Bot WhatsApp para atendimento, venda de megabytes e administração de grupos.\n\n` +
        `Cada aluguer deve ter uma instalação, sessão WhatsApp, armazenamento e base SQLite próprios. Nessa instalação, o número configurado como *OWNER_NUMBER* fica com acesso para gerir a tabela, os pagamentos, os pedidos e os grupos, sem misturar os dados de outros clientes.\n\n` +
        `${contactLine}\n\n` +
        `O emparelhamento é feito pelo próprio cliente no painel da sua hospedagem. O código de ligação não é enviado por WhatsApp. O preço não está publicado neste menu; confirme as condições com o responsável.`,
      );
    } catch (error) {
      console.error('[Aluguer] Erro ao mostrar informações:', error);
      return msg.reply('Não consegui carregar as informações de aluguer agora. Tente novamente mais tarde.');
    }
  },
};
