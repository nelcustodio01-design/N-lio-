import { getCustomerProfile, normalizeMozPhone } from '../../core/salesService.js';
import DB from '#db';
import Memory from '../../ai/memory/conversationMemory.js';

function targetJid(msg, args) {
  const mentioned = msg.mentionedJid?.[0];
  if (mentioned) return mentioned;
  const number = normalizeMozPhone(args.join(' '));
  return number ? `${number}@s.whatsapp.net` : null;
}

export default {
  command: ['cliente'],
  category: 'pagamentos',
  description: 'Consultar a memória de atendimento de um cliente.',
  ownerOnly: true,
  privateOnly: true,
  async run({ msg, args }) {
    try {
      const jid = targetJid(msg, args);
      if (!jid) return msg.reply('Uso: *.cliente <número internacional>*');
      const profile = getCustomerProfile(jid);
      const aiProfile = Memory.getExistingUserProfile(jid);
      const orders = DB.db.prepare(`
        SELECT public_id, package_mb, package_price, status, created_at
        FROM sales_orders WHERE customer_jid = ? ORDER BY created_at DESC LIMIT 5
      `).all(jid);
      if (!profile && !aiProfile && !orders.length) return msg.reply('Não encontrei memória nem pedidos para esse número.');
      const history = orders.length
        ? orders.map(order => `• ${order.public_id}: ${order.package_mb} MB — ${order.package_price} MT (${order.status})`).join('\n')
        : 'Sem pedidos registados.';
      const aiMemory = [
        aiProfile?.last_intent && `Última intenção: ${aiProfile.last_intent}`,
        aiProfile?.interests?.length && `Interesses: ${aiProfile.interests.join(', ')}`,
        aiProfile?.total_interactions > 0 && `Interacções: ${aiProfile.total_interactions}`,
      ].filter(Boolean).join('\n') || 'Sem perfil adicional de IA.';
      return msg.reply(`*Cliente*\nNome: ${profile?.customer_name || aiProfile?.name || 'não registado'}\nNúmero: ${profile?.customer_phone || jid.split('@')[0]}\nÚltima interação: ${profile?.last_interaction_at || 'não registada'}\nResumo: ${profile?.context_summary || 'sem resumo'}\n${aiMemory}\n\n*Pedidos recentes*\n${history}`);
    } catch (error) {
      console.error('[Cliente] Erro:', error);
      return msg.reply('Não consegui consultar a memória agora.');
    }
  },
};
