/**
 * 🗣️ FALAR — Converte texto em nota de voz realista
 * Corrigido: comandos únicos, APIs robustas
 */
import fetch from 'node-fetch';
import fs from 'fs';
import generateMaleSpeech from '../../core/maleTts.js';

export default {
  command: ['notar', 'notavoz', 'voznota'],
  category: 'voz',
  description: 'Grava nota de voz a partir de texto 🗣️',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    let text = args.join(' ').trim();
    if (!text && msg.quoted) {
      text = msg.quoted.text || msg.quoted.body || msg.quoted.caption || '';
    }
    if (!text) return msg.reply(
      `🗣️ *GRAVAR NOTA DE VOZ*\n\n` +
      `▸ Uso: *${usedPrefix}${command} <texto>*\n` +
      `▸ Ou responde a uma mensagem com *${usedPrefix}${command}*\n\n` +
      `💡 Converte qualquer texto em nota de voz!`
    );

    if (text.length > 600) text = text.substring(0, 600);
    await msg.react('🎙️');

    try {
      if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp', { recursive: true });
      const tmpFile = `./tmp/falar_${Date.now()}.mp3`;
      let audioBuffer = null;

      // Motor principal: voz masculina explícita em português.
      audioBuffer = await generateMaleSpeech(text);

      // API 1: Vreden TTS
      if (!audioBuffer) try {
        const res = await fetch(`https://api.vreden.web.id/api/tts?text=${encodeURIComponent(text)}&lang=pt`, { timeout: 12000 });
        if (res.ok) {
          const buf = Buffer.from(await res.arrayBuffer());
          if (buf.length > 500) audioBuffer = buf;
        }
      } catch {}

      // API 2: Google TTS
      if (!audioBuffer) {
        try {
          const res = await fetch(
            `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=pt&q=${encodeURIComponent(text)}`,
            { headers: { 'User-Agent': 'Mozilla/5.0' }, timeout: 12000 }
          );
          if (res.ok) {
            const buf = Buffer.from(await res.arrayBuffer());
            if (buf.length > 500) audioBuffer = buf;
          }
        } catch {}
      }

      // API 3: StreamElements (preferência por voz masculina)
      if (!audioBuffer) {
        try {
          const res = await fetch(
            `https://api.streamelements.com/kappa/v2/speech?voice=Ricardo&text=${encodeURIComponent(text)}`,
            { timeout: 12000 }
          );
          if (res.ok) {
            const buf = Buffer.from(await res.arrayBuffer());
            if (buf.length > 500) audioBuffer = buf;
          }
        } catch {}
      }

      if (!audioBuffer) return msg.reply('❌ Não foi possível gerar a nota de voz. Tenta novamente.');

      fs.writeFileSync(tmpFile, audioBuffer);
      await sock.sendMessage(msg.chat, {
        audio: { url: tmpFile },
        mimetype: 'audio/ogg; codecs=opus',
        ptt: true
      }, { quoted: msg });
      await msg.react('✅');
      setTimeout(() => { try { if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile); } catch {} }, 10000);
    } catch (e) {
      await msg.react('❌');
      await msg.reply(`❌ Erro: ${e.message}`);
    }
  }
};
