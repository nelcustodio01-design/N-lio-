/**
 * .calc-inv - Calculadora de Investimentos
 * Calcula juros compostos, ROI e simulações
 * Uso: .calc-inv [capital] [taxa] [período]
 */

export default {
  command: ['calc-inv', 'calcinv', 'investimento', 'juros'],
  category: 'utils',
  description: 'Calcula juros compostos e ROI de investimentos',
  usage: '.calc-inv [capital] [taxa%] [meses]',
  run: async function (msg, sock, args, text, usedPrefix, command) {
    try {
      if (!args.length) {
        return msg.reply(
          '💰 *Calculadora de Investimentos*\n\n' +
          'Uso: `.calc-inv [capital] [taxa%] [meses]`\n\n' +
          'Exemplos:\n' +
          '• `.calc-inv 10000 5 12` (10.000 MZN, 5% a.m., 12 meses)\n' +
          '• `.calc-inv 50000 3 24` (50.000 MZN, 3% a.m., 24 meses)\n' +
          '• `.calc-inv 100000 2.5 36` (100.000 MZN, 2.5% a.m., 36 meses)'
        );
      }

      const capital = parseFloat(args[0]);
      const taxa = parseFloat(args[1]);
      const periodo = parseInt(args[2]);

      if (isNaN(capital) || capital <= 0) {
        return msg.reply('❌ Capital inválido!');
      }

      if (isNaN(taxa) || taxa < 0 || taxa > 100) {
        return msg.reply('❌ Taxa de juros deve estar entre 0 e 100!');
      }

      if (isNaN(periodo) || periodo <= 0) {
        return msg.reply('❌ Período deve ser um número positivo!');
      }

      const processing = await msg.reply(
        `💰 Calculando investimento...\n` +
        `Capital: ${capital} MZN\n` +
        `Taxa: ${taxa}% a.m.\n` +
        `Período: ${periodo} meses\n\n` +
        'Por favor, aguarde...'
      );

      try {
        const resultado = calcularInvestimento(capital, taxa, periodo);

        if (!resultado) {
          return msg.reply('❌ Erro ao calcular!');
        }

        const lucro = resultado.montante - capital;
        const roi = ((lucro / capital) * 100).toFixed(2);

        let mensagem = `✅ *Resultado do Investimento*\n\n`;
        mensagem += `💵 *Valores:*\n`;
        mensagem += `• Capital Inicial: ${capital.toFixed(2)} MZN\n`;
        mensagem += `• Montante Final: ${resultado.montante.toFixed(2)} MZN\n`;
        mensagem += `• Lucro Total: ${lucro.toFixed(2)} MZN\n`;
        mensagem += `• ROI: ${roi}%\n\n`;

        mensagem += `📊 *Detalhes:*\n`;
        mensagem += `• Taxa Mensal: ${taxa}%\n`;
        mensagem += `• Período: ${periodo} meses\n`;
        mensagem += `• Juros Compostos: ${resultado.jurosCompostos.toFixed(2)} MZN\n`;
        mensagem += `• Juros Simples: ${resultado.jurosSimples.toFixed(2)} MZN\n\n`;

        mensagem += `📈 *Crescimento Mês a Mês:*\n`;

        for (let i = 3; i <= periodo; i += 3) {
          const montanteMes = capital * Math.pow(1 + taxa / 100, i);
          mensagem += `• Mês ${i}: ${montanteMes.toFixed(2)} MZN\n`;
        }

        mensagem += `\n⏰ ${new Date().toLocaleTimeString('pt-MZ')}`;

        await sock.sendMessage(msg.chat, { text: mensagem }, { quoted: msg });
        await sock.sendMessage(msg.chat, { delete: processing.key });

      } catch (error) {
        console.error('Erro ao calcular:', error);
        return msg.reply('❌ Erro ao processar cálculo!');
      }

    } catch (error) {
      console.error('Erro em calc_investimentos:', error);
      msg.reply('❌ Erro ao processar comando calc-inv!');
    }
  }
};

function calcularInvestimento(capital, taxa, periodo) {
  try {
    const montante = capital * Math.pow(1 + taxa / 100, periodo);
    const jurosCompostos = montante - capital;
    const jurosSimples = capital * (taxa / 100) * periodo;

    return {
      capital,
      taxa,
      periodo,
      montante,
      jurosCompostos,
      jurosSimples
    };

  } catch (error) {
    console.error('Erro ao calcular investimento:', error);
    return null;
  }
}
