import { forgetCustomerMemory, normalizeMozPhone } from '../../core/salesService.js';

export default {
  command: ['esquecer'],
  category: 'pagamentos',
  description: 'Apagar a memória de atendimento do próprio cliente ou de um cliente.',
  async run({ msg, args, isOwner }) {
    try {
      let target = msg.sender;
      if (isOwner && msg.mentionedJid?.[0]) target = msg.mentionedJid[0];
      else if (isOwner && args[0]) {
        const number = normalizeMozPhone(args.join(' '));
        if (number) target = `${number}@s.whatsapp.net`;
      }
      if (!target) return msg.reply('Não consegui identificar a conta a esquecer.');
      const deleted = forgetCustomerMemory(target);
      if (!deleted) return msg.reply('Não consegui identificar a conta a esquecer.');
      return msg.reply(
        isOwner && target !== msg.sender
          ? 'Apaguei a memória de atendimento e os dados locais de vendas deste cliente, incluindo pedidos em aberto e recibos. Cópias guardadas fora do bot não são removidas por este comando.'
          : 'Apaguei a sua memória de atendimento e os dados locais de vendas, incluindo pedidos em aberto e recibos. Cópias guardadas fora do bot não são removidas por este comando.',
      );
    } catch (error) {
      console.error('[Esquecer] Erro:', error);
      return msg.reply('Não consegui apagar a memória agora. Tente novamente.');
    }
  },
};
