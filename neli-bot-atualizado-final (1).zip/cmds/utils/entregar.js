import { markSalesOrderDelivered } from '../../core/salesService.js';

export default {
  command: ['entregar', 'marcarentregue'],
  category: 'pagamentos',
  description: 'Marcar um pedido pago como entregue.',
  ownerOnly: true,
  async run({ msg, sock, args }) {
    try {
      const id = args[0];
      if (!id) return msg.reply('Uso: *.entregar <ID-do-pedido>*');
      const order = markSalesOrderDelivered(id);
      if (!order) return msg.reply('Pedido não encontrado ou o pagamento ainda não foi confirmado manualmente.');
      await sock.sendMessage(order.customer_jid, {
        text: `Os megas do pedido *${order.public_id}* foram marcados como entregues. Obrigado por comprar na Nel Net Express.`,
      });
      return msg.reply(`Pedido *${order.public_id}* marcado como entregue e o cliente foi avisado.`);
    } catch (error) {
      console.error('[Entregar] Erro:', error);
      return msg.reply('Não consegui actualizar o pedido. Tente novamente.');
    }
  },
};
