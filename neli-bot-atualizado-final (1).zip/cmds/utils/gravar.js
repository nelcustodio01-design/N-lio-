/**
 * gravar.js — compatibilidade histórica.
 *
 * O alias `gravar` é registado pelo comando TDS, que garante o pipeline
 * de áudio da nota de voz masculina. Este módulo mantém um nome interno
 * para não criar dois donos para o mesmo alias no carregador.
 */
export default {
  command: ['_gravar_old'],
  category: 'utilidades',
  description: 'Compatibilidade interna',
  run: async ({ msg }) => {}
};
