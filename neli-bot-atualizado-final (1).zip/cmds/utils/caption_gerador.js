/**
 * .caption-gerador - Gerador de Captions para Redes Sociais
 * Cria captions em diferentes tons
 * Uso: .caption [tema] [tom]
 */

const captionTemplates = {
  'produto': {
    'profissional': [
      '✨ Apresentamos nosso novo produto! Qualidade premium, preço acessível. Descubra a diferença! 🎯',
      '🚀 Inovação que transforma! Conheça a solução que você procurava. Disponível agora! 💎',
      '💼 Excelência em cada detalhe. Nosso produto foi desenvolvido com precisão e cuidado. Confira! ⭐'
    ],
    'humor': [
      '😂 Se você não tem isto, o que está fazendo com a sua vida? Brincadeira... mas é sério! 🔥',
      '🤣 Aviso: Este produto pode causar vício. Já foi testado e aprovado! 👌',
      '😎 Somos tão bons que até nós mesmos ficamos impressionados! Vem conferir! 🎉'
    ],
    'inspirador': [
      '🌟 Cada grande jornada começa com um pequeno passo. Dê o seu hoje! 💪',
      '✨ Você merece o melhor. Escolha qualidade, escolha-nos! 🙌',
      '🚀 Transforme seus sonhos em realidade com nossa ajuda! 💫'
    ]
  },
  'serviço': {
    'profissional': [
      '📞 Precisando de um serviço de qualidade? Estamos aqui para ajudar! Contacte-nos agora! 💼',
      '🎯 Soluções personalizadas para suas necessidades. Vamos conversar? 📧',
      '✅ Experiência, qualidade e dedicação em cada projeto! Confie em nós! 🤝'
    ],
    'humor': [
      '😄 Nosso serviço é tão bom que você vai querer nos contratar novamente! 🎊',
      '🤖 Somos quase humanos! Mas com muito mais eficiência! 💪',
      '🎯 Se não ficar satisfeito, devolvemos seu dinheiro... e um abraço! 🤗'
    ],
    'inspirador': [
      '🌈 Transformamos desafios em oportunidades! Vamos juntos? 🚀',
      '💡 Sua visão + nossa expertise = sucesso garantido! ✨',
      '🎨 Criatividade sem limites para seus projetos! 🌟'
    ]
  },
  'evento': {
    'profissional': [
      '📅 Marque a data! Evento imperdível chegando em breve! Inscrições abertas! 🎟️',
      '🎪 Prepare-se para a melhor experiência! Detalhes em breve! 🌟',
      '✨ Um evento que vai mudar sua perspectiva! Não perca! 📢'
    ],
    'humor': [
      '🎉 Vai ser tão bom que você vai querer vir duas vezes! 😂',
      '🎊 Aviso: Diversão garantida! Prepare-se para se divertir! 🎈',
      '🎭 O evento que todos estão esperando! Você não pode perder! 🔥'
    ],
    'inspirador': [
      '🌟 Juntos criamos história! Seja parte desta jornada! 🚀',
      '💫 Um evento para transformar vidas! Você merece estar lá! ✨',
      '🎯 Conectar, inspirar, crescer! Nos vemos lá! 🙌'
    ]
  },
  'promoção': {
    'profissional': [
      '🎁 Promoção imperdível! Descontos de até 50% em produtos selecionados! ⏰',
      '💰 Aproveite! Oferta válida por tempo limitado! Não perca! 🛍️',
      '✨ Qualidade com preço justo! Promoção exclusiva para você! 🎯'
    ],
    'humor': [
      '🤑 Tão barato que parece roubo! Mas é totalmente legal! 😄',
      '💸 Seus bolsos vão agradecer! Promoção que você não pode recusar! 🎊',
      '🏃 Corre! Estoque limitado e promoção ainda melhor! ⚡'
    ],
    'inspirador': [
      '🌟 Qualidade acessível para todos! Essa é nossa missão! 💪',
      '✨ Você merece o melhor pelo melhor preço! Aproveite! 🎉',
      '🚀 Transforme seus sonhos em realidade com nossas promoções! 💫'
    ]
  }
};

export default {
  command: ['caption', 'caption-gerador', 'legenda', 'post'],
  category: 'utils',
  description: 'Gera captions para redes sociais',
  usage: '.caption [tema] [tom]',
  run: async function (msg, sock, args, text, usedPrefix, command) {
    try {
      if (!args.length) {
        const temas = Object.keys(captionTemplates).join(', ');
        const tons = ['profissional', 'humor', 'inspirador'];
        return msg.reply(
          '📝 *Gerador de Captions*\n\n' +
          'Uso: `.caption [tema] [tom]`\n\n' +
          `Temas: ${temas}\n` +
          `Tons: ${tons.join(', ')}\n\n` +
          'Exemplo: `.caption produto humor`'
        );
      }

      const tema = args[0].toLowerCase();
      const tom = args[1]?.toLowerCase() || 'profissional';

      if (!captionTemplates[tema]) {
        return msg.reply(`❌ Tema "${tema}" não encontrado!`);
      }

      if (!captionTemplates[tema][tom]) {
        return msg.reply(`❌ Tom "${tom}" não encontrado para este tema!`);
      }

      const captions = captionTemplates[tema][tom];
      const caption = captions[Math.floor(Math.random() * captions.length)];

      await sock.sendMessage(msg.chat, {
        text:
          `✅ *Caption Gerado!*\n\n` +
          `📝 *${tema.toUpperCase()} - ${tom.toUpperCase()}*\n\n` +
          `${caption}\n\n` +
          `📊 Caracteres: ${caption.length}\n` +
          `⏰ ${new Date().toLocaleTimeString('pt-MZ')}\n\n` +
          `💡 Dica: Copie e personalize conforme necessário!`
      }, { quoted: msg });

    } catch (error) {
      console.error('Erro em caption_gerador:', error);
      msg.reply('❌ Erro ao processar comando caption!');
    }
  }
};
