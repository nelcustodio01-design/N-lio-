import { manuallyConfirmPayment } from '../../core/salesService.js';

export default {
  command: ['confirmarpagamento', 'confirmarpedido'],
  category: 'pagamentos',
  description: 'Confirmar manualmente um pagamento verificado na operadora.',
  ownerOnly: true,
  async run({ msg, sock, args }) {
    try {
      const id = args[0];
      if (!id) return msg.reply('Uso: *.confirmarpagamento <ID-do-pedido>*');
      const order = manuallyConfirmPayment(id);
      if (!order) return msg.reply('Pedido não encontrado ou já não está à espera de confirmação.');
      const firstPurchase = order.first_purchase
        ? '\nEsta foi a primeira compra deste cliente.'
        : '';
      await sock.sendMessage(order.customer_jid, {
        text: `O pagamento do pedido *${order.public_id}* foi confirmado pelo Nel. A entrega dos megas está pendente.${firstPurchase}`,
      });
      return msg.reply(`Pagamento do pedido *${order.public_id}* marcado como confirmado. Use *.entregar ${order.public_id}* quando enviar os megas.`);
    } catch (error) {
      console.error('[ConfirmarPagamento] Erro:', error);
      return msg.reply('Não consegui actualizar o pedido. Tente novamente.');
    }
  },
};
