import { getCustomerSalesHistory } from '../../core/salesService.js';

const STATUS = {
  pending_payment: 'à espera do pagamento',
  pending_review: 'em revisão manual',
  paid: 'pago; falta entregar',
  delivered: 'entregue',
};

function formatDate(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value || 'data não indicada');
  return date.toLocaleString('pt-MZ', {
    timeZone: 'Africa/Maputo',
    dateStyle: 'short',
    timeStyle: 'short',
  });
}

export default {
  command: ['historico', 'minhascompras', 'meuhistorico'],
  category: 'pagamentos',
  description: 'Consultar apenas o próprio histórico de pedidos.',
  privateOnly: true,
  async run({ msg, sender }) {
    try {
      const orders = getCustomerSalesHistory(sender, 10);
      if (!orders.length) {
        return msg.reply('Ainda não encontrei pedidos associados a este número. Para começar, consulte *tabela* e depois use *.pedido* no privado.');
      }
      const lines = orders.map(order => {
        const volume = order.package_mb >= 1024
          ? `${(order.package_mb / 1024).toFixed(1)} GB`
          : `${order.package_mb} MB`;
        return `• *${order.public_id}* — ${volume}, ${order.package_price} MT — ${STATUS[order.status] || order.status}\n  ${formatDate(order.created_at)}`;
      });
      return msg.reply(`*O seu histórico recente* (máximo 10 pedidos)\n\n${lines.join('\n')}\n\nEstes dados são visíveis apenas nesta conversa privada.`);
    } catch (error) {
      console.error('[Histórico do cliente] Erro:', error);
      return msg.reply('Não consegui carregar o seu histórico agora. Tente novamente mais tarde.');
    }
  },
};
