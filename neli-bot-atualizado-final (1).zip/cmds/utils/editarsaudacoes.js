import {
  DEFAULT_SALES_GREETINGS,
  getSalesGreetings,
  saveSalesGreetings,
} from '../../core/salesService.js';

export default {
  command: ['editarsaudacoes', 'mensagensatendimento'],
  category: 'pagamentos',
  description: 'Editar as mensagens aleatórias de atendimento.',
  ownerOnly: true,
  async run({ msg, args, usedPrefix, command }) {
    try {
      const [action = 'listar', rawIndex, ...rest] = args;
      const list = getSalesGreetings();
      const index = Number(rawIndex);
      if (['listar', 'ver', 'list'].includes(action.toLowerCase())) {
        return msg.reply(`*Mensagens de atendimento (${list.length})*\n${list.map((text, i) => `${i + 1}. ${text}`).join('\n')}\n\nUse ${usedPrefix}${command} adicionar <texto>, definir <número> <texto>, remover <número> ou repor.`);
      }
      if (['repor', 'reset'].includes(action.toLowerCase())) {
        saveSalesGreetings([...DEFAULT_SALES_GREETINGS]);
        return msg.reply(`Lista reposta com ${DEFAULT_SALES_GREETINGS.length} mensagens.`);
      }
      if (['adicionar', 'add'].includes(action.toLowerCase())) {
        const text = [rawIndex, ...rest].filter(Boolean).join(' ').trim();
        if (!text || list.length >= 100) return msg.reply('Envie uma mensagem curta. O limite é 100 mensagens.');
        saveSalesGreetings([...list, text]);
        return msg.reply(`Mensagem adicionada. Total: ${list.length + 1}.`);
      }
      if (['definir', 'set', 'editar'].includes(action.toLowerCase())) {
        const text = rest.join(' ').trim();
        if (!Number.isInteger(index) || index < 1 || index > list.length || !text) {
          return msg.reply(`Uso: ${usedPrefix}${command} definir <número> <texto>`);
        }
        list[index - 1] = text;
        saveSalesGreetings(list);
        return msg.reply(`Mensagem ${index} actualizada.`);
      }
      if (['remover', 'remove', 'del'].includes(action.toLowerCase())) {
        if (!Number.isInteger(index) || index < 1 || index > list.length) return msg.reply('Indique um número válido da lista.');
        list.splice(index - 1, 1);
        saveSalesGreetings(list);
        return msg.reply(`Mensagem removida. Restam ${list.length}.`);
      }
      return msg.reply(`Uso: ${usedPrefix}${command} listar|adicionar|definir|remover|repor`);
    } catch (error) {
      console.error('[EditarSaudacoes] Erro:', error);
      return msg.reply('Não consegui actualizar as mensagens de atendimento.');
    }
  },
};
