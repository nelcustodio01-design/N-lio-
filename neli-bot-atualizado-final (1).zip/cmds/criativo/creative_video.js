import settings from '#settings';
import DB from '#db';
export default {
  command: ['videogen', 'gerarvideo', 'criarvideo'],
  category: 'criativo',
  description: 'Gerar video com IA',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query) return msg.reply('⚠️ Usa: .videogen <descricao>\n\n📌 Exemplo: .videogen um gato astronauta');
    await msg.reply(`🎨 A criar: _videogen_\n\n📝 Descricao: _${query}_\n⏳ Aguarde...`);
  },
};
