import settings from '#settings';
import DB from '#db';

export default {
  command: ['gradient', 'gradiente', 'degradê'],
  category: 'criativo',
  description: 'Gerar gradiente de cores',
  async run({ msg, args, usedPrefix, command, text }) {
    const cor1 = args[0] || '000000';
    const cor2 = args[1] || 'FFFFFF';
    const steps = parseInt(args[2]) || 10;
    let gradiente = '';
    for (let i = 0; i < steps; i++) {
      const ratio = i / (steps - 1);
      const r = Math.round(parseInt(cor1.substring(0,2), 16) * (1-ratio) + parseInt(cor2.substring(0,2), 16) * ratio);
      const g = Math.round(parseInt(cor1.substring(2,4), 16) * (1-ratio) + parseInt(cor2.substring(2,4), 16) * ratio);
      const b = Math.round(parseInt(cor1.substring(4,6), 16) * (1-ratio) + parseInt(cor2.substring(4,6), 16) * ratio);
      gradiente += `■`;
    }
    return msg.reply(`🎨 *GRADIENTE*\n\n${gradiente}\n\n#${cor1} → #${cor2}\n📊 ${steps} passos`);
  }
};
