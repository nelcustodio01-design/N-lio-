import settings from '#settings';
import DB from '#db';
export default {
  command: ['frame', 'moldura', 'borda'],
  category: 'criativo',
  description: 'Adicionar moldura a foto',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query) return msg.reply('⚠️ Usa: .frame <descricao>\n\n📌 Exemplo: .frame um gato astronauta');
    await msg.reply(`🎨 A criar: _frame_\n\n📝 Descricao: _${query}_\n⏳ Aguarde...`);
  },
};
