import settings from '#settings';
import DB from '#db';

export default {
  command: ['certificado', 'certificate', 'diploma'],
  category: 'criativo',
  description: 'Gerar certificado',
  async run({ msg, args, usedPrefix, command, text }) {
    const nome = args.join(' ');
    if (!nome) return msg.reply(`🏆 *CERTIFICADO*\n\nUso: *${usedPrefix}${command} <nome da pessoa>*\n\nExemplo: *${usedPrefix}${command} Nel Custódio*`);
    return msg.reply(`🏆 *CERTIFICADO DE MERITO*\n\n━━━━━━━━━━━━━━━━━━━━━━━\n\n  Este certificado é concedido a:\n\n  🌟 *${nome}* 🌟\n\n  Por excelência e dedicação\n  ao uso do Nel-Aviso Bot\n\n  📅 Data: ${new Date().toLocaleDateString('pt-PT')}\n  🏅 Nel Custódio © 2024\n\n━━━━━━━━━━━━━━━━━━━━━━━`);
  }
};
