import settings from '#settings';
import DB from '#db';

export default {
  command: ['fonte', 'font', 'tipografia'],
  category: 'criativo',
  description: 'Ver fontes e tipografias',
  async run({ msg, args, usedPrefix, command, text }) {
    const texto = args.join(' ') || 'Nel Bot';
    const fontes = {
      '𝔊𝔬𝔱𝔦𝔠𝔞': 'Gótica medieval',
      '𝓢𝓬𝓻𝓲𝓹𝓽': 'Cursiva elegante',
      '𝕻𝖎𝖝𝖊𝖑': 'Pixel/retro',
      'Ⓒⓘⓡⓒⓤⓛⓐⓡ': 'Circular',
      '🅂🅀🅄🄰🅁🄴🄳': 'Quadrada',
      '𝑰𝒕á𝒍𝒊𝒄𝒐': 'Itálico elegante',
      '𝐁𝐨𝐥𝐝': 'Negrito clássico',
    };
    let resultado = `🔤 *TIPOGRAFIAS*\n\n`;
    for (const [fonte, desc] of Object.entries(fontes)) {
      resultado += `• *${desc}:* ${fonte}\n`;
    }
    resultado += `\n_Texto original: "${texto}"_`;
    return msg.reply(resultado);
  }
};
