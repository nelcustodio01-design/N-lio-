import settings from '#settings';
import DB from '#db';

export default {
  command: ['memegen', 'gerarmeme', 'criarmeme'],
  category: 'criativo',
  description: 'Gerar meme automatico',
  async run({ msg, args, usedPrefix, command, text }) {
    const texto = args.join(' ');
    if (!texto) return msg.reply(`😂 *GERADOR DE MEME*\n\nUso: *${usedPrefix}${command} <texto do meme>*\n\nExemplo: *${usedPrefix}${command} Quando o bot cai no meio do grupo*`);
    await msg.reply({
      image: { url: `https://api.memegen.link/images/custom/_/${encodeURIComponent(texto)}.png?background_color=333333&text_color=FFFFFF&font_size=32` },
      caption: `😂 *MEME GERADO*\n\n📝 _${texto}_`
    });
  }
};
