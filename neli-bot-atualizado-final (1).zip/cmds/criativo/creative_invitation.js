import settings from '#settings';
import DB from '#db';

export default {
  command: ['convite', 'invitation', 'convidar'],
  category: 'criativo',
  description: 'Gerar convite personalizado',
  async run({ msg, args, usedPrefix, command, text }) {
    const texto = args.join(' ');
    if (!texto) return msg.reply(`💌 *CONVITE*\n\nUso: *${usedPrefix}${command} <texto do convite>*\n\nExemplo: *${usedPrefix}${command} Estás convidado para o meu aniversário! 25 de Dezembro, 19h, Maputo*`);
    return msg.reply(`💌 *CONVITE ESPECIAL*\n\n━━━━━━━━━━━━━━━━━━━━━━━\n\n  🎉 *VOCÊ ESTÁ CONVIDADO!* 🎉\n\n  ${texto}\n\n  💫 Não falte!\n\n━━━━━━━━━━━━━━━━━━━━━━━`);
  }
};
