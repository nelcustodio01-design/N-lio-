import settings from '#settings';
import DB from '#db';
export default {
  command: ['duckduckgo', 'ddg', 'busca'],
  category: 'extras',
  description: 'Pesquisar no DuckDuckGo',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !true) return msg.reply('⚠️ Usa: .duckduckgo <texto>\n\n📌 Exemplo: .duckduckgo ola mundo');
    await msg.reply(`⏳ Processando: _duckduckgo_\n\n$$\nAguarde...`);
  },
};
