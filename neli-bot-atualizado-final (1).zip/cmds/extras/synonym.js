import settings from '#settings';
import DB from '#db';
export default {
  command: ['sinonimo', 'synonym', 'sinonimos'],
  category: 'extras',
  description: 'Encontrar sinonimos de uma palavra',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !true) return msg.reply('⚠️ Usa: .sinonimo <texto>\n\n📌 Exemplo: .sinonimo ola mundo');
    await msg.reply(`⏳ Processando: _sinonimo_\n\n$$\nAguarde...`);
  },
};
