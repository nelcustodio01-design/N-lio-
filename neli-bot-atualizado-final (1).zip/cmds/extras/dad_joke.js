import settings from '#settings';
import DB from '#db';
export default {
  command: ['dad', 'dadjoke', 'piadapai'],
  category: 'extras',
  description: 'Piada de pai',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .dad <texto>\n\n📌 Exemplo: .dad ola mundo');
    await msg.reply(`⏳ Processando: _dad_\n\n$$\nAguarde...`);
  },
};
