import settings from '#settings';
import DB from '#db';
export default {
  command: ['github', 'gh', 'githubsearch'],
  category: 'extras',
  description: 'Pesquisar repositorios no GitHub',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !true) return msg.reply('⚠️ Usa: .github <texto>\n\n📌 Exemplo: .github ola mundo');
    await msg.reply(`⏳ Processando: _github_\n\n$$\nAguarde...`);
  },
};
