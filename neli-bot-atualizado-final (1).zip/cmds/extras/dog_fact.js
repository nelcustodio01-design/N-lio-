import settings from '#settings';
import DB from '#db';
export default {
  command: ['cao', 'dogfact', 'factcao'],
  category: 'extras',
  description: 'Curiosidade sobre caes',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .cao <texto>\n\n📌 Exemplo: .cao ola mundo');
    await msg.reply(`⏳ Processando: _cao_\n\n$$\nAguarde...`);
  },
};
