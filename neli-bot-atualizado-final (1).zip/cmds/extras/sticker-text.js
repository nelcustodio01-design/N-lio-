import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const TMP = path.join(__dirname,'..','..','tmp');
export default {
  command:['stickertext','stxt','textosticker'],
  category:'extras',
  description:'Criar sticker com texto personalizado. ✍️',
  run: async ({ msg, sock, text, usedPrefix, command }) => {
    if (!text) return msg.reply(`✍️ *STICKER DE TEXTO*\n\n✎ Uso:\n▸ *${usedPrefix+command} Moçambique 🇲🇿*`);
    await msg.react('🕒');
    try {
      const url = `https://api.siputzx.my.id/api/maker/textsticker?text=${encodeURIComponent(text)}`;
      const res  = await fetch(url,{headers:{'User-Agent':'Mozilla/5.0'}});
      if (res.ok) {
        const buf = Buffer.from(await res.arrayBuffer());
        if (buf.length>500) {
          await sock.sendMessage(msg.chat,{sticker:buf},{quoted:msg});
          await msg.react('✅'); return;
        }
      }
      // Fallback: usar API brat
      const url2 = `https://skyzxu-brat.hf.space/brat?text=${encodeURIComponent(text)}`;
      const res2  = await fetch(url2,{headers:{'User-Agent':'Mozilla/5.0'}});
      if (!res2.ok) throw new Error('Não foi possível criar o sticker');
      const buf2 = Buffer.from(await res2.arrayBuffer());
      const { writeExif } = (await import('../../core/exif.js')).default;
      const webp = await writeExif({mimetype:'image/webp',data:buf2},{packname:'Nel-Aviso-Bot-Moz',author:'Nel Custódio'});
      await sock.sendMessage(msg.chat,{sticker:webp},{quoted:msg});
      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      return msg.reply(`❧ Erro: ${e.message}`);
    }
  },
};
