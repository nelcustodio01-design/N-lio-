import settings from '#settings';
import DB from '#db';
export default {
  command: ['timezone', 'fuso', 'fusohorario'],
  category: 'extras',
  description: 'Ver fuso horario de uma cidade',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .timezone <texto>\n\n📌 Exemplo: .timezone ola mundo');
    await msg.reply(`⏳ Processando: _timezone_\n\n$$\nAguarde...`);
  },
};
