import settings from '#settings';
import DB from '#db';
export default {
  command: ['qrread', 'scanqr', 'lerqr'],
  category: 'extras',
  description: 'Ler codigo QR de uma imagem',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !true) return msg.reply('⚠️ Usa: .qrread <texto>\n\n📌 Exemplo: .qrread ola mundo');
    await msg.reply(`⏳ Processando: _qrread_\n\n$$\nAguarde...`);
  },
};
