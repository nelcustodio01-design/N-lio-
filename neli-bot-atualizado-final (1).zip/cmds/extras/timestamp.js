import settings from '#settings';
import DB from '#db';
export default {
  command: ['timestamp', 'unixtime', 'epoche'],
  category: 'extras',
  description: 'Converter Unix timestamp',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .timestamp <texto>\n\n📌 Exemplo: .timestamp ola mundo');
    await msg.reply(`⏳ Processando: _timestamp_\n\n$$\nAguarde...`);
  },
};
