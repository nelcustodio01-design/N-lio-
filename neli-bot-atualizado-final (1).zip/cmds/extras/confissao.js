// Sistema de Confissão Anónima — exclusivo Nel-Aviso-Bot-Moz 🇲🇿
const pending = new Map(); // userId → { text, chatId }

export default {
  command: ['confissao', 'confessar', 'anonimo', 'anon'],
  category: 'extras',
  description: 'Enviar confissão anónima para o grupo. 🤫',
  run: async ({ msg, sock, text, args, usedPrefix, command }) => {
    try {
      // Verificar se é DM do bot (para confirmar a confissão)
      const isPrivate = !msg.chat.endsWith('@g.us');

      if (isPrivate) {
        // No privado: enviar confissão para o grupo guardado
        const pend = pending.get(msg.sender);
        if (!pend) {
          return msg.reply(
            `🤫 *CONFISSÃO ANÓNIMA*\n\n` +
            `Para enviar uma confissão anónima:\n` +
            `1. Vai ao grupo\n` +
            `2. Usa *.confissao <mensagem>*\n` +
            `3. O bot vai pedir confirmação no privado`
          );
        }
        const { text: confText, chatId } = pend;
        pending.delete(msg.sender);
        await sock.sendMessage(chatId, {
          text: `🤫 *CONFISSÃO ANÓNIMA*\n\n"${confText}"\n\n_— Anónimo_`
        });
        return msg.reply('✅ *Confissão enviada anonimamente!* Ninguém sabe que foste tu. 🤫');
      }

      // No grupo: guardar confissão e pedir confirmação
      if (!text?.trim()) {
        return msg.reply(
          `🤫 *CONFISSÃO ANÓNIMA*\n\n` +
          `✎ Uso: *${usedPrefix + command} <a tua confissão>*\n\n` +
          `✎ Exemplo:\n*${usedPrefix + command} Tenho medo de falar em público*\n\n` +
          `▸ Após enviar o comando, o bot vai-te enviar uma confirmação no privado.\n` +
          `▸ A tua identidade fica *completamente anónima* no grupo. 🔒`
        );
      }

      // Guardar e deletar a mensagem do utilizador (esconder rastro)
      pending.set(msg.sender, { text: text.trim(), chatId: msg.chat });
      try { await sock.sendMessage(msg.chat, { delete: msg.key }); } catch {}

      // Avisar no privado
      await sock.sendMessage(msg.sender, {
        text:
          `🤫 *CONFIRMAR CONFISSÃO*\n\n` +
          `A tua confissão:\n"${text.trim()}"\n\n` +
          `Responde com *.confissao* (sem texto) para *confirmar e enviar anonimamente*.\n` +
          `Ou ignora para cancelar.\n\n` +
          `🔒 A tua identidade nunca será revelada.`
      });
    } catch (e) {
      return msg.reply(`❧ Erro: ${e.message}`);
    }
  }
};
