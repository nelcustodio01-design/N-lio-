// ═══════════════════════════════════════════════════════════════
//  TDS — Text-to-Speech (Voz Masculina) 🔊
// ═══════════════════════════════════════════════════════════════
import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import generateMaleSpeech from '../../core/maleTts.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const TMP = path.join(__dirname, '..', '..', 'tmp');

export default {
   command: ['tds', 'dts', 'falar-masc', 'gravar'],
   category: 'voz',
  description: 'Converter texto em voz masculina (TDS). 🔊',

  run: async ({ msg, sock, args, text, usedPrefix, command }) => {
    const input = text || (msg.quoted?.text) || '';
    if (!input) {
      return msg.reply(
        `🔊 *COMANDO TDS (VOZ MASCULINA)* 🔊\n\n` +
        `▸ Transforma texto em voz masculina de alta qualidade!\n\n` +
        `✎ *Exemplos:*\n` +
        `▸ *${usedPrefix + command} Viva Moçambique! 🇲🇿*\n` +
        `▸ Ou responde a uma mensagem com *${usedPrefix + command}*`
      );
    }

    await msg.react('🎙️');

    try {
       // Prioridade: Edge TTS com voz masculina definida explicitamente.
       let audioBuffer = await generateMaleSpeech(input);

      if (!audioBuffer) {
         audioBuffer = await tryStreamElements(input);
       }

       if (!audioBuffer) {
         audioBuffer = await tryGoogleTTS(input);
      }

      if (!audioBuffer || !audioBuffer.length) {
        await msg.react('❌');
        return msg.reply('❧ Não foi possível gerar a voz masculina. Tenta novamente!');
      }

      // Converter para MP3/Opus via ffmpeg para garantir compatibilidade WhatsApp
      const mp3Buffer = await convertToMp3(audioBuffer);

      await sock.sendMessage(msg.chat, {
        audio:    mp3Buffer,
        mimetype: 'audio/mpeg',
        ptt:      true, // Enviar como mensagem de voz
        fileName: 'tds.mp3',
      }, { quoted: msg });

      await msg.react('✅');

    } catch (e) {
      await msg.react('❌');
      return msg.reply(`❧ Erro no TDS: *${e.message}*`);
    }
  },
};

async function tryStreamElements(text) {
  try {
    // Vozes masculinas em PT
    const voices = ['Ricardo', 'Cristiano', 'Heleno'];
    for (const voice of voices) {
      const url = `https://api.streamelements.com/kappa/v2/speech?voice=${voice}&text=${encodeURIComponent(text.slice(0, 500))}`;
      const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
      if (res.ok) {
        const buf = Buffer.from(await res.arrayBuffer());
        if (buf.length > 1000) return buf;
      }
    }
    return null;
  } catch { return null; }
}

async function tryGoogleTTS(text) {
  try {
    const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(text)}&tl=pt-BR&client=tw-ob`;
    const res = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0',
        'Referer': 'https://translate.google.com',
      },
    });
    if (!res.ok) return null;
    return Buffer.from(await res.arrayBuffer());
  } catch { return null; }
}

function convertToMp3(inputBuffer) {
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(TMP)) fs.mkdirSync(TMP, { recursive: true });
    const tmpIn  = path.join(TMP, `tds_in_${Date.now()}`);
    const tmpOut = path.join(TMP, `tds_out_${Date.now()}.mp3`);
    fs.writeFileSync(tmpIn, inputBuffer);

    const ff = spawn('ffmpeg', [
      '-i', tmpIn,
      '-acodec', 'libmp3lame',
      '-ab', '128k',
      '-ar', '44100',
      '-f', 'mp3',
      tmpOut,
    ]);

    ff.on('close', code => {
      try { fs.unlinkSync(tmpIn); } catch {}
      if (code === 0 && fs.existsSync(tmpOut)) {
        const buf = fs.readFileSync(tmpOut);
        try { fs.unlinkSync(tmpOut); } catch {}
        resolve(buf);
      } else {
        resolve(inputBuffer);
      }
    });
    ff.on('error', () => resolve(inputBuffer));
  });
}
