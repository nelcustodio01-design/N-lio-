// ═══════════════════════════════════════════════════════════════
//  NUMEROLOGIA — Análise do número da vida 🔢
// ═══════════════════════════════════════════════════════════════
export default {
  command: ['numerologia','numvida','numerovida','numerology'],
  category: 'extras',
  description: 'Calcular o número da vida e o seu significado. 🔢',
  run: async ({ msg, args, usedPrefix, command }) => {
    // Aceitar data DD/MM/AAAA ou nome
    const input = args.join(' ').trim();
    if (!input) return msg.reply(
`🔢 *NUMEROLOGIA*

✎ *Uso:*
▸ *${usedPrefix+command} 15/03/1995* — por data de nascimento
▸ *${usedPrefix+command} Nel Custódio* — por nome

_Descobre o teu número da vida!_`
    );
    const significados = {
      1: { title:'O Líder',       desc:'Independente, pioneiro e determinado. Nasceste para liderar e inovar. A tua força de vontade é incrível.' },
      2: { title:'O Diplomata',   desc:'Sensível, cooperativo e intuitivo. Tens um dom natural para a paz e harmonia nas relações.' },
      3: { title:'O Criativo',    desc:'Expressivo, alegre e comunicativo. A arte, a música e a escrita fluem naturalmente em ti.' },
      4: { title:'O Construtor',  desc:'Disciplinado, prático e trabalhador. Constróis fundações sólidas e és de confiança absoluta.' },
      5: { title:'O Aventureiro', desc:'Livre, curioso e adaptável. Amas a mudança e a liberdade — o mundo é o teu lar.' },
      6: { title:'O Cuidador',    desc:'Responsável, amoroso e protector. A família e a comunidade são o centro da tua vida.' },
      7: { title:'O Sábio',       desc:'Analítico, espiritual e introspectivo. Buscas a verdade e o conhecimento profundo.' },
      8: { title:'O Realizador',  desc:'Ambicioso, poderoso e material. Tens dom para os negócios e a liderança financeira.' },
      9: { title:'O Humanitário', desc:'Compassivo, idealista e generoso. A tua missão é servir o mundo e deixar um legado.' },
      11:{ title:'O Visionário',  desc:'Número mestre! Intuição poderosa e inspiração espiritual. Nasceste para iluminar o mundo.' },
      22:{ title:'O Arquitecto',  desc:'Número mestre! O maior construtor — podes realizar sonhos que outros nem imaginam.' },
      33:{ title:'O Mestre',      desc:'Número mestre! Amor incondicional e cura. A tua presença transforma vidas.' },
    };
    let numero;
    const dateMatch = input.match(/(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{4})/);
    if (dateMatch) {
      const [,d,m,y] = dateMatch;
      const sum = [...`${d}${m}${y}`].reduce((a,c)=>a+parseInt(c),0);
      let n = sum;
      while (n>9 && n!==11 && n!==22 && n!==33) {
        n = [...String(n)].reduce((a,c)=>a+parseInt(c),0);
      }
      numero = n;
    } else {
      // Por nome
      const map = {a:1,b:2,c:3,d:4,e:5,f:6,g:7,h:8,i:9,j:1,k:2,l:3,m:4,n:5,o:6,p:7,q:8,r:9,s:1,t:2,u:3,v:4,w:5,x:6,y:7,z:8};
      const sum = input.toLowerCase().replace(/[^a-z]/g,'').split('').reduce((a,c)=>a+(map[c]||0),0);
      let n = sum;
      while (n>9 && n!==11 && n!==22 && n!==33) n=[...String(n)].reduce((a,c)=>a+parseInt(c),0);
      numero = n;
    }
    const sig = significados[numero] || significados[9];
    const sorte = [1,4,7,13,21,33,42].map(n=>((numero*n)%99)+1).join(', ');
    return msg.reply(
`🔢 *NUMEROLOGIA*

▸ Input: *${input}*
━━━━━━━━━━━━━━━━━━━

🌟 *Número da Vida: ${numero}*
👑 *Arquétipo: ${sig.title}*

📖 *Significado:*
${sig.desc}

🎯 *Números da Sorte:* ${sorte}

${numero===11||numero===22||numero===33?'⚡ *NÚMERO MESTRE! Destino especial aguarda-te!*\n\n':''}
_🔢 A numerologia revela o caminho, tu escolhes o passo._
_Nel-Aviso-Bot-Moz 🇲🇿_`
    );
  },
};
