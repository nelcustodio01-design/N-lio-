import settings from '#settings';
import DB from '#db';
export default {
  command: ['fortuna', 'fortune', 'sorte'],
  category: 'extras',
  description: 'Frase de sorte do dia',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .fortuna <texto>\n\n📌 Exemplo: .fortuna ola mundo');
    await msg.reply(`⏳ Processando: _fortuna_\n\n$$\nAguarde...`);
  },
};
