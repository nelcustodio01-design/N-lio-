import settings from '#settings';
import DB from '#db';
export default {
  command: ['json', 'jsonformat', 'formatarjson'],
  category: 'extras',
  description: 'Formatar JSON',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .json <texto>\n\n📌 Exemplo: .json ola mundo');
    await msg.reply(`⏳ Processando: _json_\n\n$$\nAguarde...`);
  },
};
