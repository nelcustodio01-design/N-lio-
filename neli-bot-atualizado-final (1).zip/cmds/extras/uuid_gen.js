import settings from '#settings';
import DB from '#db';
export default {
  command: ['uuid', 'uuidgen', 'idgerado'],
  category: 'extras',
  description: 'Gerar UUID aleatorio',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .uuid <texto>\n\n📌 Exemplo: .uuid ola mundo');
    await msg.reply(`⏳ Processando: _uuid_\n\n$$\nAguarde...`);
  },
};
