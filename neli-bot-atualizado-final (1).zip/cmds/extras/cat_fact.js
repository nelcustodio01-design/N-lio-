import settings from '#settings';
import DB from '#db';
export default {
  command: ['gato', 'catfact', 'factgato'],
  category: 'extras',
  description: 'Curiosidade sobre gatos',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .gato <texto>\n\n📌 Exemplo: .gato ola mundo');
    await msg.reply(`⏳ Processando: _gato_\n\n$$\nAguarde...`);
  },
};
