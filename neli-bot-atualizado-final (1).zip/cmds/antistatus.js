import db from '#db';
export async function before({ msg, sock, groupMetadata, participants, isAdmins, isBotAdmins }) {
  if (!msg.isGroup) return;
  if (msg.isBot) return;
  const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
  if (!groupMetadata) return;
  const botSettings = db.getSettings(botId);
  const isSelf = botSettings.self ?? 0;
  if (isSelf) return;
  const chat = db.getChat(msg.chat);
  const primaryBotId = chat?.primaryBot;
  const isPrimary = !primaryBotId || primaryBotId === botId;
  const isEstado = msg.quoted?.groupStatusMentionMessage || msg.quoted?.type === 'groupStatusMentionMessage' || msg.message?.groupStatusMentionMessage || (msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.groupStatusMentionMessage);
  if (!isEstado || !chat?.antistatus || isAdmins || !isBotAdmins || !isPrimary) return;
  try {
    let deleteObj = null;
    let participantToUse = null;
    if (msg.quoted && (msg.quoted.groupStatusMentionMessage || msg.quoted.type === 'groupStatusMentionMessage')) {
      const quotedKey = msg.quoted.key;
      participantToUse = quotedKey.participantAlt || (quotedKey.participant ? quotedKey.participant.split(':')[0] + '@s.whatsapp.net' : msg.sender);
      deleteObj = { remoteJid: msg.chat, fromMe: false, id: quotedKey.id, participant: participantToUse };
    } else if (msg.message?.groupStatusMentionMessage) {
      participantToUse = msg.key.participantAlt || (msg.key.participant ? msg.key.participant.split(':')[0] + '@s.whatsapp.net' : msg.sender);
      deleteObj = { remoteJid: msg.chat, fromMe: false, id: msg.key.id, participant: participantToUse };
    } else if (msg.message?.extendedTextMessage?.contextInfo) {
      const contextInfo = msg.message.extendedTextMessage.contextInfo;
      if (contextInfo.quotedMessage?.groupStatusMentionMessage || contextInfo.stanzaId) {
        participantToUse = (contextInfo.participant ? contextInfo.participant.split(':')[0] + '@s.whatsapp.net' : null) || msg.sender;
        deleteObj = { remoteJid: msg.chat, fromMe: false, id: contextInfo.stanzaId, participant: participantToUse };
      }
    }
    if (deleteObj) {
      await sock.sendMessage(msg.chat, { delete: deleteObj }).catch(err => console.error('Erro ao borrar status:', err));
      const currentParticipant = msg.key.participantAlt || (msg.key.participant ? msg.key.participant.split(':')[0] + '@s.whatsapp.net' : msg.sender);
      const currentDeleteObj = { remoteJid: msg.chat, fromMe: false, id: msg.key.id, participant: currentParticipant };
      if (currentDeleteObj.id !== deleteObj.id) {
        await sock.sendMessage(msg.chat, { delete: currentDeleteObj }).catch(err => console.error('Erro ao borrar comando actual:', err));
      }
    }
    const targetId = msg.sender;
    db.setCreate('chat_users', [msg.chat, targetId], 'warnings', []);
    let user = db.getChatUser(msg.chat, targetId);
    let warnings = user.warnings;
    if (typeof warnings === 'string') {
      try { warnings = JSON.parse(warnings); } catch { warnings = []; }
    }
    if (!Array.isArray(warnings)) warnings = [];
    const now = new Date();
    const timestamp = now.toLocaleString('pt-MZ', { timeZone: 'Africa/Maputo', day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    warnings.unshift({ reason: 'Anti-Status detectado', timestamp, by: botId });
    db.setChatUser(msg.chat, targetId, 'warnings', warnings);
    const total = warnings.length;
    const warnLimit = chat.warnLimit || 3;
    const expulsar = chat.expulsar === 1;
    const warningList = warnings.map((w, i) => {
      const index = total - i;
      return `\`#${index}\` » ${w.reason}\n> » Data: ${w.timestamp}`;
    }).join('\n');
    let message = `✐ Foi adicionada uma advertência automática a @${targetId.split('@')[0]} por *Anti-Status*.\n✿ Advertências totais \`(${total})\`:\n\n${warningList}`;
    if (total >= warnLimit && expulsar) {
      try {
        await sock.groupParticipantsUpdate(msg.chat, [targetId], 'remove');
        db.setChatUser(msg.chat, targetId, 'warnings', []);
        message += `\n\n> ❖ O usuário atingiu o limite de advertências e foi expulso do grupo.`;
      } catch {
        message += `\n\n> ❖ O usuário atingiu o limite, mas não foi possível expulsar automaticamente.`;
      }
    } else if (total >= warnLimit && !expulsar) {
      message += `\n\n> ❖ O usuário atingiu o limite de advertências.`;
    }
    await sock.reply(msg.chat, message, msg, { mentions: [targetId] });
  } catch (error) {
    console.error('Error general en Anti-Estado:', error);
  }
}