import settings from '#settings';
import DB from '#db';
export default {
  command: ['asian', 'asian18', 'asia'],
  category: 'nsfw',
  description: 'Conteudo asiatico 18+',
  nsfw: true,
  async run({ msg, sock, args, text, isGroup, chatId }) {
    await msg.reply(`🔞 A buscar: _asian_\n\n⏳ Aguarde...`);
  },
};
