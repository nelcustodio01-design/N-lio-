/**
 * 👑 SOVEREIGN COMMAND SUITE - OMEGA EDITION
 * Comandos de Autoridade Suprema para o Sovereign Core.
 */

export default {
    name: "sovereign",
    alias: ["omega", "authority", "core"],
    desc: "Aceder ao painel de autoridade suprema.",
    category: "main",
    react: "👑",
    isOwner: true,
    run: async ({ sock, msg, args, command, usedPrefix }) => {
        const subCommand = args[0]?.toLowerCase();

        switch (subCommand) {
            case 'stats':
            case 'neural':
                const { getBiometricStatus } = await import('../../core/human_protection.js');
                const { getSentinelStatus } = await import('../../core/guardian.js');
                const bio = getBiometricStatus();
                const sentinel = getSentinelStatus();
                
                let statsText = `🧬 *[ NEURAL & BIOMETRIC STATUS ]*\n\n`;
                statsText += `◈ *Fadiga:* ${bio.fatigue}\n`;
                statsText += `◈ *Foco:* ${bio.focus}\n`;
                statsText += `◈ *Modo:* ${bio.mode}\n\n`;
                statsText += `🛡️ *[ SENTINEL PRIME ]*\n`;
                statsText += `◈ *Nível de Ameaça:* ${sentinel.threatLevel}%\n`;
                statsText += `◈ *Deep Sleep:* ${sentinel.deepSleep ? 'ATIVADO' : 'INATIVO'}\n`;
                statsText += `◈ *Protocolo:* ${sentinel.mode}`;
                
                return msg.reply(statsText);

            case 'mutate':
                const { default: ghost } = await import('../../core/system/ghost_protocol.js');
                const oldToken = msg.ghostToken || 'NONE';
                const newToken = ghost.getExecutionToken();
                return msg.reply(`🔄 *[ GHOST MUTATION ]*\n\n◈ Identidade rotacionada com sucesso.\n◈ *Novo Token:* ${newToken.substring(0, 12)}...`);

            case 'stealth':
                global.STEALTH_MODE = global.STEALTH_MODE === 'MAXIMUM' ? 'NORMAL' : 'MAXIMUM';
                return msg.reply(`🤫 *[ STEALTH CONFIG ]*\n\n◈ Modo Stealth alterado para: *${global.STEALTH_MODE}*`);

            case 'pulse':
                const start = Date.now();
                await sock.query({ tag: 'iq', attrs: { to: '@s.whatsapp.net', type: 'get', xmlns: 'w:p' }, content: [{ tag: 'ping', attrs: {} }] });
                const lat = Date.now() - start;
                return msg.reply(`⚡ *[ QUANTUM PULSE ]*\n\n◈ Latência de Rede: *${lat}ms*\n◈ Integridade do Núcleo: *100%*`);

            default:
                return msg.reply(`👑 *[ SOVEREIGN COMMANDS ]*\n\nUse:\n◈ *${usedPrefix + command} neural* - Ver estado da IA\n◈ *${usedPrefix + command} mutate* - Forçar mutação de identidade\n◈ *${usedPrefix + command} stealth* - Alternar modo invisível\n◈ *${usedPrefix + command} pulse* - Testar latência quântica`);
        }
    }
};
