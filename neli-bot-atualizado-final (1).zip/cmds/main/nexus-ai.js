/**
 * 🎨 NEXUS-AI — Gerador de imagens ultra-realistas
 * Corrigido: removido VIP, fix API, múltiplos fallbacks
 */
import fetch from 'node-fetch';

export default {
  command: ['nexus-ai', 'gerar-imagem', 'artia'],
  category: 'ia',
  description: 'Gerador de imagens ultra-realistas com IA 🎨',
  run: async ({ msg, sock, text, usedPrefix, command }) => {
    if (!text) return msg.reply(
      `🎨 *NEXUS-AI: GERADOR DE IMAGENS*\n\n` +
      `Descreve a imagem que queres criar!\n\n` +
      `Exemplo: *${usedPrefix}${command} um astronauta em Maputo, estilo cyberpunk*`
    );

    await msg.react('🎨');
    const { key } = await sock.sendMessage(msg.chat, { text: `🎨 Gerando imagem...\n▸ _${text}_` }, { quoted: msg });

    let imageUrl = null;

    // 1. Pollinations AI (gratuito)
    try {
      imageUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(text)}?width=1024&height=1024&nologo=true&seed=${Date.now()}`;
      const t = await fetch(imageUrl, { method: 'HEAD', timeout: 12000 });
      if (!t.ok) imageUrl = null;
    } catch { imageUrl = null; }

    // 2. Vreden DALL-E 3
    if (!imageUrl) {
      try {
        const res = await fetch(`https://api.vreden.web.id/api/ai/dalle3?query=${encodeURIComponent(text)}`, { timeout: 15000 });
        const json = await res.json();
        if (json?.result) imageUrl = typeof json.result === 'string' ? json.result : (json.result.url || json.result.image);
      } catch {}
    }

    // 3. Delirius
    if (!imageUrl) {
      try {
        const res = await fetch(`https://api.delirius.store/ia/dalle?text=${encodeURIComponent(text)}`, { timeout: 15000 });
        const json = await res.json();
        if (json?.status && json?.data) imageUrl = typeof json.data === 'string' ? json.data : (json.data.url || json.data.image);
      } catch {}
    }

    if (!imageUrl) {
      return sock.sendMessage(msg.chat, { text: '❌ Não foi possível gerar a imagem. Tenta novamente.', edit: key }, { quoted: msg });
    }

    await sock.sendMessage(msg.chat, {
      image: { url: imageUrl },
      caption: `🎨 *Nexus-AI:* "_${text}_"\n\n> ⚡ _Nexus Singularity V14_`
    }, { quoted: msg });
    await msg.react('✅');
  }
};
