import settings from '../../settings.js';

export default {
  command: ['criador', 'owner', 'dono', 'dev'],
  category: 'main',
  description: 'Informações sobre o criador do bot.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    try {
      const owner = settings.ownerNumbers?.[0] || '';
      const contact = owner ? `▸ Número: *${owner}*\n▸ Contacto: wa.me/${owner}\n\n` : '';
    return msg.reply(
      `❧ *Informações do Criador* 👑\n\n` +
      `▸ Nome: *${settings.ownerName || 'Nel'}*\n` +
      contact +
      `▸ País: *Moçambique* 🇲🇿\n` +
      `▸ Projecto: *Nel-Aviso-Bot-Moz*\n` +
      `▸ Versão: *${settings.botVersion || '1.0'}*\n\n` +
      `🔥 Assistente automático da Nel Net Express 🇲🇿\n` +
      `▸ Este bot é único e feito em Moçambique!`
    );
    } catch (error) {
      console.error('[Criador] Erro:', error);
      return msg.reply('Não consegui carregar as informações do responsável.');
    }
  },
};
