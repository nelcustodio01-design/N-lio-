/**
 * 🎙️ VOICE-NEXUS — Texto para voz neural profissional
 * Corrigido: removido VIP, removido conflito 'tts', APIs robustas
 */
import fetch from 'node-fetch';
import fs from 'fs';

export default {
  command: ['voice-nexus', 'nexusvoz', 'nelvoz'],
  category: 'voz',
  description: 'Transforma texto em voz neural profissional 🎙️',
  run: async ({ msg, sock, text, usedPrefix, command }) => {
    if (!text) return msg.reply(
      `🎙️ *VOICE-NEXUS: VOZ NEURAL*\n\n` +
      `Escreve o texto para eu narrar!\n\n` +
      `Exemplo: *${usedPrefix}${command} Bem-vindo ao Nel-Aviso-Bot!*`
    );

    await msg.react('🎙️');

    try {
      if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp', { recursive: true });
      const tmpFile = `./tmp/vnexus_${Date.now()}.mp3`;
      let audioBuffer = null;

      // API 1: Vreden TTS
      try {
        const res = await fetch(`https://api.vreden.web.id/api/tts?text=${encodeURIComponent(text)}&lang=pt`, { timeout: 12000 });
        if (res.ok) {
          const buf = Buffer.from(await res.arrayBuffer());
          if (buf.length > 500) audioBuffer = buf;
        }
      } catch {}

      // API 2: Google TTS
      if (!audioBuffer) {
        try {
          const res = await fetch(
            `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(text)}&tl=pt-BR&client=tw-ob`,
            { headers: { 'User-Agent': 'Mozilla/5.0' }, timeout: 12000 }
          );
          if (res.ok) {
            const buf = Buffer.from(await res.arrayBuffer());
            if (buf.length > 500) audioBuffer = buf;
          }
        } catch {}
      }

      // API 3: StreamElements
      if (!audioBuffer) {
        try {
          const res = await fetch(
            `https://api.streamelements.com/kappa/v2/speech?voice=Vitoria&text=${encodeURIComponent(text)}`,
            { timeout: 12000 }
          );
          if (res.ok) {
            const buf = Buffer.from(await res.arrayBuffer());
            if (buf.length > 500) audioBuffer = buf;
          }
        } catch {}
      }

      if (!audioBuffer) {
        return msg.reply('❌ Não foi possível sintetizar a voz. Tenta novamente.');
      }

      fs.writeFileSync(tmpFile, audioBuffer);
      await sock.sendMessage(msg.chat, {
        audio: { url: tmpFile },
        mimetype: 'audio/mpeg',
        ptt: true
      }, { quoted: msg });
      await msg.react('✅');
      setTimeout(() => { try { if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile); } catch {} }, 10000);
    } catch (e) {
      await msg.react('❌');
      await msg.reply(`❌ Erro ao gerar voz: ${e.message}`);
    }
  }
};
