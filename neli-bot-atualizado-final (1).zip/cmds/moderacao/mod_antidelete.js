import DB from '#db';

export default {
  command: ['antidelete', 'antideletar', 'nodeletar'],
  category: 'moderacao',
  description: 'Reenviar texto ou legenda de mensagens apagadas no grupo.',
  groupOnly: true,
  isAdmin: true,
  run: async ({ msg, args, usedPrefix, command }) => {
    const action = (args[0] || 'status').toLowerCase();
    if (!['on', 'off', 'status'].includes(action)) {
      return msg.reply(`Uso: *${usedPrefix + command} on|off|status*`);
    }
    if (action === 'status') {
      return msg.reply(`Anti-delete: *${DB.getChat(msg.chat)?.antidelete ? 'ativado' : 'desativado'}*.\nO bot só pode recuperar o texto ou legenda que recebeu enquanto estava online.`);
    }
    DB.setChat(msg.chat, 'antidelete', action === 'on' ? 1 : 0);
    return msg.reply(`Anti-delete ${action === 'on' ? 'ativado' : 'desativado'} para este grupo.`);
  },
};
