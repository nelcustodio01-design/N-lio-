import DB from '#db';

export default {
  command: ['antiraid', 'protecao', 'escudo'],
  category: 'moderacao',
  description: 'Ativa o escudo inteligente contra ataques e invasores.',
  groupOnly: true,
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, args, usedPrefix, command }) => {
    const action = args[0]?.toLowerCase();
    const chat = DB.getChat(msg.chat);
    
    if (!action || !['on', 'off'].includes(action)) {
      return msg.reply(`🛡️ *SISTEMA ANTI-RAID*\n\n▸ Estado: *${chat?.antiraid ? '✅ ATIVO' : '❌ INATIVO'}*\n▸ Quando ativo, avisa os administradores se houver cinco ou mais entradas em 15 segundos.\n▸ Não expulsa membros automaticamente.\n\nAtivar: *${usedPrefix + command} on*\nDesativar: *${usedPrefix + command} off*`);
    }
    
    if (action === 'on') {
      DB.setChat(msg.chat, 'antiraid', 1);
      await msg.reply('🛡️ *Anti-Raid ativado.* Os administradores serão avisados sobre um pico de entradas.');
    } else {
      DB.setChat(msg.chat, 'antiraid', 0);
      await msg.reply('🔓 *Anti-Raid desativado.*');
    }
  }
};
