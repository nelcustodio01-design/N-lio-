import axios from 'axios';
import uploadImage from '../../core/system/uploadImage.js';

export default {
  command: ['analisar', 'vision', 'ver'],
  category: 'ia',
  description: 'Analisa imagens usando o motor de visão Nexus Singularity.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const q = msg.quoted ? msg.quoted : msg;
    if (!/image/.test(q.mimetype)) return msg.reply(`👁️ **NEXUS VISION**\n\nPor favor, responda a uma *imagem* com o comando *${usedPrefix + command}* para análise.`);

    await msg.react('👁️');
    await msg.reply('👁️ *Nexus Vision:* Escaneando imagem com sensores neurais...');

    try {
      const media = await q.download();
      const imgUrl = await uploadImage(media);
      
      // Usando uma API de visão real (Gemini ou similar via proxy)
      const url = `https://api.vreden.web.id/api/ai/gemini-vision?url=${encodeURIComponent(imgUrl)}&query=descreva+esta+imagem+em+detalhes+em+portugues`;
      const response = await axios.get(url);
      
      const analysis = response.data?.result || "Não consegui processar os dados visuais desta imagem.";

      const report = `
👁️ **ANÁLISE NEXUS VISION**
━━━━━━━━━━━━━━━━━━━━━━

${analysis}

> 📡 *Processado via Visão Computacional Singularity*
      `;

      return msg.reply(report);
    } catch (e) {
      console.error('Vision Error:', e);
      msg.reply('❌ Falha ao aceder ao motor de visão neural.');
    }
  }
};
