import axios from 'axios';

export default {
  command: ['art', 'desenhar', 'dalle', 'gerar'],
  category: 'ia',
  description: 'Gera imagens ultra-realistas usando o motor Nexus Art.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const prompt = args.join(' ');
    if (!prompt) return msg.reply(`🎨 **NEXUS ART STUDIO**\n\nUso: *${usedPrefix + command} [descrição da imagem]*\nExemplo: *${usedPrefix + command} Um leão tecnológico em Moçambique, estilo cyberpunk, 4k.*`);

    await msg.react('🎨');
    await msg.reply('🎨 *Nexus Art:* Materializando a sua imaginação no campo digital...');

    try {
      // Usando uma API de geração de imagem real (DALL-E 3 ou similar via proxy)
      const url = `https://api.vreden.web.id/api/ai/dalle3?query=${encodeURIComponent(prompt)}`;
      const response = await axios.get(url);
      
      const imgUrl = response.data?.result || response.data?.url;

      if (!imgUrl) throw new Error('No image URL');

      await sock.sendMessage(msg.chat, { 
        image: { url: imgUrl }, 
        caption: `🎨 **NEXUS ART GENERATION**\n\n> *Prompt:* ${prompt}\n\n🚀 *Criado via Nexus Singularity V14*` 
      }, { quoted: msg });

      await msg.react('✅');
    } catch (e) {
      console.error('Art Error:', e);
      msg.reply('❌ O motor de arte neural está temporariamente offline. Tente um prompt mais simples.');
    }
  }
};
