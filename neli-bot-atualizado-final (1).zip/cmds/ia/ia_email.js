import settings from '#settings';
import DB from '#db';
export default {
  command: ['email', 'escreveremail', 'mail'],
  category: 'ia',
  description: 'Escrever email profissional com IA',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query) return msg.reply('⚠️ Usa: .email <texto>\n\n📌 Exemplo: .email como funciona o WhatsApp?');
    await msg.reply(`🤖 A pensar...\n\n🧠 IA: _email_\n📝 Query: _${query}_\n⏳ Aguarde...`);
  },
};
