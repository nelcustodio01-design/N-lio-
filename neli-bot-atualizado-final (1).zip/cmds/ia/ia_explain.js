import settings from '#settings';
import DB from '#db';
export default {
  command: ['explicar', 'explain', 'comocomo'],
  category: 'ia',
  description: 'Explicar conceito complexo',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query) return msg.reply('⚠️ Usa: .explicar <texto>\n\n📌 Exemplo: .explicar como funciona o WhatsApp?');
    await msg.reply(`🤖 A pensar...\n\n🧠 IA: _explicar_\n📝 Query: _${query}_\n⏳ Aguarde...`);
  },
};
