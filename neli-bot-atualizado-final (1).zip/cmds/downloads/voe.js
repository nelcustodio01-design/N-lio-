import settings from '#settings';
import DB from '#db';
export default {
  command: ['voe', 'voedl', 'vo'],
  category: 'downloads',
  description: 'Baixar videos do VOE',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query) return msg.reply('⚠️ Usa: .voe <link ou nome>\n\n📌 Exemplo: .voe https://exemplo.com/video');
    await msg.reply(`🔄 A buscar em Voe...\n\n🔍 Query: _${query}_\n⏳ Aguarde...`);
    // API externa para voe
    try {
      // Implementacao real: chamar API de voe
      await msg.reply(`⏳ Processando: _${query}_\n\n💡 Para usar este comando, configure a API correspondente no .env`);
    } catch (e) {
      await msg.reply(`❌ Erro: ${e.message}`);
    }
  },
};
