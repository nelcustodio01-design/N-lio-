import DB from '#db';

function validTime(value) {
  return typeof value === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(value);
}

export default {
  command: ['horario', 'horariogrupo'],
  category: 'grupos',
  description: 'Programar a abertura e o fecho diário do grupo.',
  groupOnly: true,
  isAdmin: true,
  botAdmin: true,
  async run({ msg, args, usedPrefix, command }) {
    try {
      const action = (args[0] || '').toLowerCase();
      const schedule = DB.getChat(msg.chat)?.groupSchedule || null;
      if (['off', 'desligar', 'limpar'].includes(action)) {
        DB.setChat(msg.chat, 'groupSchedule', null);
        DB.setChat(msg.chat, 'groupScheduleLastRun', {});
        return msg.reply('A abertura e o fecho programados foram desactivados.');
      }
      if (!args.length || ['ver', 'status', 'mostrar'].includes(action)) {
        return msg.reply(schedule
          ? `*Horário do grupo (Africa/Maputo)*\nAbre: ${schedule.open}\nFecha: ${schedule.close}\nUse *${usedPrefix}${command} off* para desactivar.`
          : `Não há horário programado. Configure com *${usedPrefix}${command} HH:MM HH:MM* (abertura e fecho).`);
      }
      const [open, close] = args;
      if (!validTime(open) || !validTime(close) || open === close) {
        return msg.reply(`Use horários diferentes no formato HH:MM, por exemplo: *${usedPrefix}${command} 08:00 21:30*.`);
      }
      DB.setChat(msg.chat, 'groupSchedule', { open, close, timezone: 'Africa/Maputo' });
      DB.setChat(msg.chat, 'groupScheduleLastRun', {});
      return msg.reply(`Horário guardado. O grupo abre às *${open}* e fecha às *${close}* (hora de Maputo), todos os dias.`);
    } catch (error) {
      console.error('[Horário do grupo] Erro:', error);
      return msg.reply('Não consegui guardar o horário deste grupo.');
    }
  },
};
