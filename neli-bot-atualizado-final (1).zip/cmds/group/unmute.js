export default {
  command: ['unmute', 'desmutar', 'dessilenciar'],
  category: 'moderacao',
  description: 'Remover silêncio de um membro do grupo.',
  groupOnly: true,
  isAdmin: true,
  botAdmin: true,
  async run({ msg, usedPrefix, command, DB }) {
    try {
      if (!msg.mentionedJid?.[0] && !msg.quoted) {
      return msg.reply(`❧ Por favor, marque ou responda à mensagem da pessoa que deseja remover do silêncio.\n\n✎ Exemplo: *${usedPrefix + command} @usuário*`);
      }
      const target = msg.mentionedJid?.[0] || msg.quoted.sender;
      const chat = DB.getChat(msg.chat);
      const muted = Array.isArray(chat.mutedMembers) ? chat.mutedMembers : [];
      DB.setChat(msg.chat, 'mutedMembers', muted.filter(jid => jid !== target));
      return msg.reply(`@${target.split('@')[0]} pode voltar a enviar mensagens.`, { mentions: [target] });
    } catch (error) {
      console.error('[Unmute] Erro:', error);
      return msg.reply('Não consegui remover o silêncio deste membro.');
    }
  },
};
