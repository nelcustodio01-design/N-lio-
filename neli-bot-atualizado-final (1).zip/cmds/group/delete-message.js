export default {
  command: ['delmsg', 'apagarmensagem', 'eliminarmensagem'],
  category: 'grupos',
  description: 'Apagar uma mensagem do grupo citando-a.',
  groupOnly: true,
  isAdmin: true,
  botAdmin: true,
  async run({ msg, sock, usedPrefix, command }) {
    try {
      const quoted = msg.quoted;
      if (!quoted?.key?.id) {
        return msg.reply(`Responda à mensagem que pretende apagar e envie *${usedPrefix}${command}*.`);
      }
      await sock.sendMessage(msg.chat, { delete: quoted.key });
      return msg.reply('Mensagem apagada.');
    } catch (error) {
      console.error('[Apagar mensagem do grupo] Erro:', error.message);
      return msg.reply('Não consegui apagar essa mensagem. Confirme se o bot é administrador e se a mensagem ainda pode ser apagada.');
    }
  },
};
