import DB from '#db';

export default {
  command: ['antispam', 'antiflood'],
  category: 'moderacao',
  description: 'Configurar a remoção de spam repetido ou excesso de mensagens.',
  groupOnly: true,
  isAdmin: true,
  botAdmin: true,
  async run({ msg, args, usedPrefix, command }) {
    try {
      const key = command === 'antiflood' ? 'antiflood' : 'antispam';
      const limitKey = `${key}Limit`;
      const setting = DB.getChat(msg.chat);
      const action = String(args[0] || '').toLowerCase();
      const enabled = Boolean(setting?.[key]);
      const limit = Number(setting?.[limitKey]) || 5;

      if (!action || !['on', 'off', 'status', 'limit'].includes(action)) {
        return msg.reply(
          `*${key === 'antiflood' ? 'Anti-flood' : 'Anti-spam'}*\n` +
          `Estado: ${enabled ? 'ligado' : 'desligado'}\n` +
          `Limite: ${limit} mensagens em 10 segundos\n\n` +
          `Use *${usedPrefix}${command} on|off*, *${usedPrefix}${command} status* ou *${usedPrefix}${command} limit 5* (3–15).`,
        );
      }
      if (action === 'status') {
        return msg.reply(`${key}: ${enabled ? 'ligado' : 'desligado'}; limite ${limit} mensagens/10s. O bot precisa ser administrador para apagar mensagens.`);
      }
      if (action === 'on' || action === 'off') {
        DB.setChat(msg.chat, key, action === 'on' ? 1 : 0);
        if (!setting?.[limitKey]) DB.setChat(msg.chat, limitKey, 5);
        return msg.reply(`${key} ${action === 'on' ? 'activado' : 'desactivado'}. ${action === 'on' ? 'Mensagens em excesso serão apagadas se o bot for administrador.' : ''}`);
      }
      const nextLimit = Number.parseInt(args[1], 10);
      if (!Number.isInteger(nextLimit) || nextLimit < 3 || nextLimit > 15) {
        return msg.reply(`O limite deve ser um número entre 3 e 15. Exemplo: *${usedPrefix}${command} limit 5*.`);
      }
      DB.setChat(msg.chat, limitKey, nextLimit);
      DB.setChat(msg.chat, key, 1);
      return msg.reply(`${key} ligado com limite de ${nextLimit} mensagens em 10 segundos.`);
    } catch (error) {
      console.error('[Anti-spam/flood] Erro:', error);
      return msg.reply('Não consegui actualizar esta configuração de moderação.');
    }
  },
};
