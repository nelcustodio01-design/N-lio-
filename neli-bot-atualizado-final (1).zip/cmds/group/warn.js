import db from '#db';
export default {
  command: ['warn'],
  category: 'grupos',
  description: 'Dar uma advertência a um membro do grupo.',
  groupOnly: true,
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command, participants }) => {
    let chat = db.getChat(msg.chat);
    if (chat.warnLimit === undefined || chat.warnLimit === null) db.setChat(msg.chat, 'warnLimit', 3);
    if (chat.expulsar === undefined || chat.expulsar === null) db.setChat(msg.chat, 'expulsar', 0);
    chat = db.getChat(msg.chat);
    const targetId = msg.mentionedJid?.[0] || msg.quoted?.sender || null;
    const reason = msg.mentionedJid?.length > 0 ? args.slice(1).join(' ') || 'Sem razão.' : args.slice(0).join(' ') || 'Sem razão.';
    try {
      if (!targetId) {
        return msg.reply('《✧》 Deve mencionar ou responder ao usuário que deseja advertir.');
      }
      db.setCreate('chat_users', [msg.chat, targetId], 'warnings', []);
      let user = db.getChatUser(msg.chat, targetId);
      let warnings = user.warnings;
      if (typeof warnings === 'string') {
        try { warnings = JSON.parse(warnings); } catch { warnings = []; }
      }
      const now = new Date();
      const timestamp = now.toLocaleString('pt-MZ', { timeZone: 'Africa/Maputo', day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
      warnings.unshift({ reason, timestamp, by: msg.sender });
      db.setChatUser(msg.chat, targetId, 'warnings', warnings);
      const total = warnings.length;
      const userGlobal = db.getUser(targetId);
      const name = userGlobal?.name || 'Usuário';
      const warningList = warnings.map((w, i) => {
        const index = total - i;
        return `\`#${index}\` » ${w.reason}\n> » Data: ${w.timestamp}`;
      }).join('\n');
      let message = `✐ Foi adicionada uma advertência a @${targetId.split('@')[0]}.\n✿ Advertências totais \`(${total})\`:\n\n${warningList}`;
      const warnLimit = Number(chat.warnLimit) || 3;
      const expulsar = chat.expulsar === 1;
      const warnedParticipant = participants?.find(participant => participant.id === targetId);
      if (total >= warnLimit && expulsar && !warnedParticipant?.admin) {
        try {
          await sock.groupParticipantsUpdate(msg.chat, [targetId], 'remove');
          db.setChatUser(msg.chat, targetId, 'warnings', []);
          message += `\n\n> ❖ O usuário atingiu o limite de advertências e foi expulso do grupo.`;
        } catch {
          message += `\n\n> ❖ O usuário atingiu o limite, mas não foi possível expulsar automaticamente.`;
        }
      } else if (total >= warnLimit && !expulsar) {
        message += `\n\n> ❖ O usuário atingiu o limite de advertências.`;
      }
      await sock.reply(msg.chat, message, msg, { mentions: [targetId] });
    } catch (e) {
      return msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};
