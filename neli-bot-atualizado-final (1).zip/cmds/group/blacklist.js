import DB from '#db';

function targetJid(msg, args) {
  if (msg.mentionedJid?.[0]) return msg.mentionedJid[0];
  if (msg.quoted?.sender) return msg.quoted.sender;
  let number = String(args[0] || '').replace(/\D/g, '');
  if (number.length === 9 && number.startsWith('8')) number = `258${number}`;
  return number.length >= 8 && number.length <= 15 ? `${number}@s.whatsapp.net` : null;
}

export default {
  command: ['ban', 'unban', 'blacklist'],
  category: 'grupos',
  description: 'Bloquear localmente a entrada de um membro neste grupo.',
  groupOnly: true,
  isAdmin: true,
  botAdmin: true,
  async run({ msg, sock, args, command }) {
    try {
      const chat = DB.getChat(msg.chat);
      const entries = Array.isArray(chat.blacklistedMembers) ? chat.blacklistedMembers : [];
      const operation = command === 'blacklist' ? String(args[0] || 'list').toLowerCase() : command;
      const targetArgs = command === 'blacklist' ? args.slice(1) : args;
      if (['list', 'listar'].includes(operation)) {
        return msg.reply(entries.length
          ? `*Lista negra deste grupo*\n${entries.map(jid => `• ${jid.split('@')[0]}`).join('\n')}`
          : 'A lista negra deste grupo está vazia.');
      }

      const target = targetJid(msg, targetArgs);
      if (!target) return msg.reply('Mencione o membro ou indique o número internacional.');
      const isBanning = ['ban', 'add', 'adicionar'].includes(operation);
      if (!isBanning && !['unban', 'del', 'remove', 'remover'].includes(operation)) {
        return msg.reply('Use .ban @membro, .unban @membro, .blacklist add @membro, .blacklist del @membro ou .blacklist list.');
      }
      const next = new Set(entries);
      if (isBanning) next.add(target);
      else next.delete(target);
      DB.setChat(msg.chat, 'blacklistedMembers', [...next]);

      if (isBanning) {
        try {
          await sock.groupParticipantsUpdate(msg.chat, [target], 'remove');
          return msg.reply(`@${target.split('@')[0]} foi removido e adicionado à lista negra deste grupo.`, { mentions: [target] });
        } catch (error) {
          console.error('[Ban] Não consegui remover o membro:', error.message);
          return msg.reply(`@${target.split('@')[0]} foi adicionado à lista negra, mas não consegui removê-lo agora. Verifique se o bot continua administrador.`, { mentions: [target] });
        }
      }
      return msg.reply(`@${target.split('@')[0]} foi removido da lista negra deste grupo.`, { mentions: [target] });
    } catch (error) {
      console.error('[Lista negra] Erro:', error);
      return msg.reply('Não consegui actualizar a lista negra deste grupo.');
    }
  },
};
