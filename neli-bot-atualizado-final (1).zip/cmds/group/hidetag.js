export default {
  command: ['hidetag', 'tag'],
  category: 'grupos',
  description: 'Enviar uma mensagem mencionando todos os usuários do grupo.',
  groupOnly: true,
  isAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command, text, groupMetadata, participants }) => {
    const groupParticipants = participants || [];
    const mentions = groupParticipants.map(p => p.id).filter(Boolean);
    const userText = (args.join(' ') || '').trim();
    const src = msg.quoted || msg;
    const originalText = (src.caption || src.text || src.body || '').trim();
    try {
      const messageText = userText || originalText;
      if (!messageText) return msg.reply('《✧》 Escreve o texto que queres enviar com menção a todos. Este comando só publica texto.');
      return sock.sendMessage(msg.chat, { text: messageText, mentions }, { quoted: null });
    } catch (e) {
      return msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  }
};
