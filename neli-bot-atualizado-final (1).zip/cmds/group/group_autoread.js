import DB from '#db';
export default {
  command: ['autoread', 'leituraauto', 'autoleitura'],
  category: 'group',
  description: 'Ativar ou desativar a leitura automática das mensagens do grupo.',
  groupOnly: true,
  isAdmin: true,
  async run({ msg, args, usedPrefix, command }) {
    const action = (args[0] || 'status').toLowerCase();
    if (!['on', 'off', 'status'].includes(action)) {
      return msg.reply(`Uso: *${usedPrefix + command} on|off|status*`);
    }
    if (action === 'status') {
      const enabled = Boolean(DB.getChat(msg.chat)?.autoread);
      return msg.reply(`Leitura automática: *${enabled ? 'ativada' : 'desativada'}*.\nA preferência global de privacidade do bot continua a ser respeitada.`);
    }
    DB.setChat(msg.chat, 'autoread', action === 'on' ? 1 : 0);
    return msg.reply(`Leitura automática ${action === 'on' ? 'ativada' : 'desativada'} para este grupo.`);
  },
};
