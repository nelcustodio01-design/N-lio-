import DB from '#db';

export default {
  command: ['regras', 'regrasgrupo'],
  category: 'grupos',
  description: 'Ver e definir as regras do grupo.',
  groupOnly: true,
  async run({ msg, args, isAdmin, isOwner, usedPrefix, command }) {
    try {
      const current = DB.getChat(msg.chat)?.groupRules || '';
      const action = (args[0] || '').toLowerCase();
      if (action === 'definir' && (isAdmin || isOwner)) {
        const text = args.slice(1).join(' ').trim();
        if (!text) return msg.reply(`Uso: *${usedPrefix}${command} definir <texto das regras>*`);
        DB.setChat(msg.chat, 'groupRules', text.slice(0, 3000));
        return msg.reply('As regras do grupo foram actualizadas.');
      }
      if (action === 'limpar' && (isAdmin || isOwner)) {
        DB.setChat(msg.chat, 'groupRules', '');
        return msg.reply('As regras do grupo foram apagadas.');
      }
      if (!current) return msg.reply((isAdmin || isOwner)
        ? `Ainda não há regras definidas. Use *${usedPrefix}${command} definir <texto>* para criar.`
        : 'Este grupo ainda não tem regras publicadas.');
      return msg.reply(`*Regras do grupo*\n\n${current}`);
    } catch (error) {
      console.error('[Regras] Erro:', error);
      return msg.reply('Não consegui carregar ou actualizar as regras do grupo.');
    }
  },
};
