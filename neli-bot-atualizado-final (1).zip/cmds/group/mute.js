export default {
  command: ['mute', 'mutar', 'silenciar'],
  category: 'moderacao',
  description: 'Impedir que um membro envie mensagens sem o remover do grupo.',
  groupOnly: true,
  isAdmin: true,
  botAdmin: true,
  async run({ msg, args, usedPrefix, command, participants, DB }) {
    try {
      const target = msg.mentionedJid?.[0] || msg.quoted?.sender;
      if (!target) return msg.reply(`Mencione o membro ou responda à mensagem dele.\nExemplo: *${usedPrefix}${command} @membro*`);
      const participant = participants?.find(member => member.id === target || member.lid === target);
      if (!participant) return msg.reply('Esse membro não foi encontrado no grupo.');
      if (participant.admin === 'admin' || participant.admin === 'superadmin') {
        return msg.reply('Não posso silenciar um administrador do grupo.');
      }
      const chat = DB.getChat(msg.chat);
      const muted = new Set(Array.isArray(chat.mutedMembers) ? chat.mutedMembers : []);
      muted.add(target);
      DB.setChat(msg.chat, 'mutedMembers', [...muted]);
      return msg.reply(
        `@${target.split('@')[0]} foi silenciado pelo bot. As mensagens serão apagadas enquanto a regra estiver activa. ` +
        `Use *${usedPrefix}unmute @membro* para permitir mensagens novamente.`,
        { mentions: [target] },
      );
    } catch (error) {
      console.error('[Mute] Erro:', error);
      return msg.reply('Não consegui silenciar o membro. Verifique se o bot continua administrador do grupo.');
    }
  },
};
