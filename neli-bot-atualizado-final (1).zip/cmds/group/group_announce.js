export default {
  command: ['anuncio', 'announce', 'broadcast'],
  category: 'group',
  description: 'Enviar um anúncio neste grupo.',
  groupOnly: true,
  isAdmin: true,
  async run({ msg, sock, args }) {
    const announcement = args.join(' ').trim();
    if (!announcement) return msg.reply('Escreva o texto do anúncio. Exemplo: *anuncio Reunião às 18h*');
    await sock.sendMessage(msg.chat, { text: `📢 *ANÚNCIO*\n\n${announcement}` }, { quoted: msg });
  },
};
