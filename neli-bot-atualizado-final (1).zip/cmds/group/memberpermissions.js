import DB from '#db';
import { aliases, commands } from '../../core/loader.js';
import { normalizeMozPhone } from '../../core/salesService.js';

function targetJid(msg, args) {
  if (msg.mentionedJid?.[0]) return msg.mentionedJid[0];
  if (msg.quoted?.sender) return msg.quoted.sender;
  const number = normalizeMozPhone(args.join(' '));
  return number ? `${number}@s.whatsapp.net` : null;
}

function commandName(value) {
  const cleaned = String(value || '').trim().replace(/^[.!/#$]+/, '').toLowerCase();
  return aliases.get(cleaned) || (commands.has(cleaned) ? cleaned : null);
}

export default {
  command: ['autorizar', 'desautorizar', 'autorizados', 'liberarcomando', 'bloquearcomando', 'modopermissao', 'modoautorizacao'],
  category: 'grupos',
  description: 'Gerir a autorização de comandos para membros do grupo.',
  groupOnly: true,
  isAdmin: true,
  async run({ msg, args, command, usedPrefix }) {
    try {
      const chatId = msg.chat;
      const chat = DB.getChat(chatId);
      const allowed = Array.isArray(chat.authorizedMembers) ? chat.authorizedMembers : [];
      const access = chat.commandAccess && typeof chat.commandAccess === 'object' ? chat.commandAccess : {};
      const action = String(command || '').toLowerCase();

      if (['modopermissao', 'modoautorizacao'].includes(action)) {
        const current = chat.unauthorizedMode === 'ignore' ? 'ignorar' : 'responder';
        const requested = String(args[0] || '').toLowerCase();
        if (!requested || ['status', 'ver'].includes(requested)) {
          return msg.reply(
            `Modo actual para membros sem autorização: *${current}*.\n` +
            `Use *${usedPrefix}${action} responder* ou *${usedPrefix}${action} ignorar*.`,
          );
        }
        if (!['responder', 'ignorar', 'respond', 'ignore'].includes(requested)) {
          return msg.reply(`Escolha *responder* ou *ignorar*: *${usedPrefix}${action} responder|ignorar*`);
        }
        const mode = ['ignorar', 'ignore'].includes(requested) ? 'ignore' : 'respond';
        DB.setChat(chatId, 'unauthorizedMode', mode);
        return msg.reply(`Membros sem autorização serão agora ${mode === 'ignore' ? 'ignorados sem resposta' : 'avisados com uma mensagem curta'}.`);
      }

      if (action === 'autorizados') {
        return msg.reply(allowed.length
          ? `*Membros autorizados neste grupo*\n${allowed.map(jid => `• @${jid.split('@')[0]}`).join('\n')}`
          : 'Ainda não há membros autorizados. Use .autorizar @membro.', {
            mentions: allowed,
          });
      }

      if (action === 'autorizar' || action === 'desautorizar') {
        const target = targetJid(msg, args);
        if (!target) return msg.reply(`Mencione o membro ou indique o número internacional.\nExemplo: ${usedPrefix}${action} @membro`);
        const next = new Set(allowed);
        if (action === 'autorizar') next.add(target);
        else next.delete(target);
        DB.setChat(chatId, 'authorizedMembers', [...next]);
        return msg.reply(
          action === 'autorizar'
            ? `@${target.split('@')[0]} foi autorizado a usar comandos neste grupo.`
            : `A autorização de @${target.split('@')[0]} foi removida.`,
          { mentions: [target] },
        );
      }

      const rawCommand = args[0];
      const canonical = commandName(rawCommand);
      if (!canonical) {
        return msg.reply(`Indique um comando existente. Exemplo: ${usedPrefix}${action} kick`);
      }
      if (['liberarcomando', 'bloquearcomando'].includes(canonical)) {
        return msg.reply('Não pode alterar a autorização dos próprios comandos de gestão.');
      }
      access[canonical] = action === 'liberarcomando' ? 'open' : 'blocked';
      DB.setChat(chatId, 'commandAccess', access);
      return msg.reply(
        action === 'liberarcomando'
          ? `O comando *${canonical}* foi liberado para todos os membros deste grupo.`
          : `O comando *${canonical}* foi bloqueado para membros autorizados e não autorizados. Administradores do grupo e o dono do bot continuam com acesso.`,
      );
    } catch (error) {
      console.error('[Permissões de grupo] Erro:', error);
      return msg.reply('Não consegui actualizar as permissões deste grupo.');
    }
  },
};
