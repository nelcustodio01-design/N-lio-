import DB from '#db';

export default {
  command: ['antifake', 'antifalso', 'antinumfake'],
  category: 'moderacao',
  description: 'Bloquear novas entradas com prefixos internacionais definidos pelos administradores.',
  groupOnly: true,
  isAdmin: true,
  botAdmin: true,
  async run({ msg, args, usedPrefix, command }) {
    try {
      const setting = DB.getChat(msg.chat);
      const action = String(args[0] || '').toLowerCase();
      const codes = Array.isArray(setting.antifakeCodes) ? setting.antifakeCodes : [];
      if (!['on', 'off', 'add', 'remove', 'list', 'status'].includes(action)) {
        return msg.reply(
          `*Anti-fake*\nEstado: ${setting.antifake ? 'ligado' : 'desligado'}\n` +
          `Prefixos bloqueados: ${codes.length ? codes.map(code => `+${code}`).join(', ') : 'nenhum'}\n\n` +
          `Use *${usedPrefix}${command} add <código-país>*, *remove <código-país>*, *on*, *off* ou *list*.\n` +
          'Só os prefixos que os administradores adicionarem serão bloqueados. O bot precisa ser administrador.',
        );
      }
      if (action === 'status' || action === 'list') {
        return msg.reply(`Anti-fake: ${setting.antifake ? 'ligado' : 'desligado'}\nPrefixos: ${codes.length ? codes.map(code => `+${code}`).join(', ') : 'nenhum configurado'}`);
      }
      if (action === 'on' || action === 'off') {
        DB.setChat(msg.chat, 'antifake', action === 'on' ? 1 : 0);
        return msg.reply(action === 'on'
          ? (codes.length
            ? `Anti-fake ligado. Novas entradas com ${codes.map(code => `+${code}`).join(', ')} serão removidas se o bot for administrador.`
            : 'Anti-fake ligado, mas ainda sem prefixos. Adicione um código com .antifake add <código-país>.')
          : 'Anti-fake desligado.');
      }
      const code = String(args[1] || '').replace(/\D/g, '');
      if (!/^\d{1,4}$/.test(code)) return msg.reply(`Indique um código de país de 1 a 4 dígitos, por exemplo: *${usedPrefix}${command} add 44*.`);
      const next = new Set(codes.map(String));
      if (action === 'add') next.add(code);
      else next.delete(code);
      DB.setChat(msg.chat, 'antifakeCodes', [...next]);
      return msg.reply(action === 'add'
        ? `Prefixo +${code} adicionado. ${setting.antifake ? 'Entradas correspondentes serão removidas.' : 'Ligue a função com .antifake on.'}`
        : `Prefixo +${code} removido.`);
    } catch (error) {
      console.error('[Anti-fake] Erro:', error);
      return msg.reply('Não consegui actualizar a configuração de anti-fake.');
    }
  },
};
