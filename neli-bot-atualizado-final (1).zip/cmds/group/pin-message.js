const PIN_DURATIONS = new Map([
  ['24h', 24 * 60 * 60],
  ['1d', 24 * 60 * 60],
  ['7d', 7 * 24 * 60 * 60],
  ['30d', 30 * 24 * 60 * 60],
]);

export default {
  command: ['fixar', 'pinar', 'desafixar'],
  category: 'grupos',
  description: 'Fixar ou desafixar uma mensagem citada no grupo.',
  groupOnly: true,
  isAdmin: true,
  botAdmin: true,
  async run({ msg, sock, args, usedPrefix, command }) {
    try {
      const quoted = msg.quoted;
      if (!quoted?.key?.id) {
        return msg.reply(`Responda à mensagem que pretende fixar e envie *${usedPrefix}${command}*. Use 24h, 7d ou 30d para escolher a duração.`);
      }

      const requested = String(args[0] || '').toLowerCase();
      const unpin = command === 'desafixar' || ['off', 'remover', 'desafixar', 'unpin'].includes(requested);
      if (unpin) {
        await sock.sendMessage(msg.chat, { pin: quoted.key, type: 2 });
        return msg.reply('A mensagem citada foi desafixada.');
      }

      const duration = PIN_DURATIONS.get(requested) || 24 * 60 * 60;
      if (requested && !PIN_DURATIONS.has(requested)) {
        return msg.reply(`Duração inválida. Escolha *24h*, *7d* ou *30d*.`);
      }
      await sock.sendMessage(msg.chat, { pin: quoted.key, type: 1, time: duration });
      return msg.reply(`Mensagem fixada por *${requested || '24h'}*.`);
    } catch (error) {
      console.error('[Fixar mensagem do grupo] Erro:', error.message);
      return msg.reply('Não consegui fixar essa mensagem. Confirme se o bot é administrador e se a versão do WhatsApp permite fixá-la.');
    }
  },
};
