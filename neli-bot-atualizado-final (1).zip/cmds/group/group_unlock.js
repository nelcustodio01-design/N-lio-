export default {
  command: ['unlock', 'desbloquear', 'unlockgroup'],
  category: 'group',
  description: 'Desbloquear o grupo',
  groupOnly: true,
  isAdmin: true,
  botAdmin: true,
  async run({ msg, sock }) {
    try {
      await sock.groupSettingUpdate(msg.chat, 'not_announcement');
      return msg.reply('🔓 O grupo está aberto para todos os membros enviarem mensagens.');
    } catch (error) {
      return msg.reply(`Não consegui abrir o grupo: ${error.message}`);
    }
  },
};
