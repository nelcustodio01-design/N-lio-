import DB from '#db';
export default {
  command: ['backup', 'backupgrupo', 'salvargrupo'],
  category: 'group',
  description: 'Fazer backup de dados do grupo',
  groupOnly: true,
  isAdmin: true,
  async run({ msg }) {
    const backup = DB.createGroupBackup(msg.chat);
    const date = new Date(backup.createdAt).toLocaleString('pt-MZ', { timeZone: 'Africa/Maputo' });
    return msg.reply(`Backup das configurações do grupo criado.\nID: *${backup.id}*\nData: ${date}\n\nO backup não inclui mensagens nem remove dados dos membros.`);
  },
};
