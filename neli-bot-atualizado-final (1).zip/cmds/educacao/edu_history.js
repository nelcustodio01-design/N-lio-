import settings from '#settings';
import DB from '#db';

export default {
  command: ['historia', 'history', 'factos'],
  category: 'educacao',
  description: 'Factos historicos',
  async run({ msg, args, usedPrefix, command, text }) {
    const factos = [
      'Moçambique tornou-se independente de Portugal em 25 de Junho de 1975.',
      'Samora Machel foi o primeiro presidente de Moçambique (1975-1986).',
      'A Guerra de Independência de Moçambique durou 10 anos (1964-1974).',
      'Maputo foi fundada como Lourenço Marques em 1544.',
      'O Rio Zambeze é o maior rio de África Austral com 2.574 km.',
      'Moçambique tem 11 províncias e 2.477 km de costa.',
      'A FRELIMO foi fundada em 1962 em Dar es Salaam.',
      'O Estreito de Moçambique separa Moçambique de Madagáscar.',
    ];
    const facto = factos[Math.floor(Math.random() * factos.length)];
    return msg.reply(`📜 *FACTO HISTÓRICO*\n\n${facto}\n\n_Use novamente para outro facto._`);
  }
};
