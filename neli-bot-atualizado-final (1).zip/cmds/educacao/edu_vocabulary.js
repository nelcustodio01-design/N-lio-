export default {
  command: ['vocabulario', 'vocabulary', 'palavras'],
  category: 'educacao',
  description: 'Aprender vocabulario novo todos os dias',
  async run({ msg, args, usedPrefix, command }) {
    const vocabulario = [
      { pt: 'Eloquência', definicao: 'Facilidade em expressar-se de forma convincente', exemplo: 'O seu discurso foi cheio de eloquência.' },
      { pt: 'Perspicácia', definicao: 'Capacidade de perceber coisas com rapidez', exemplo: 'A sua perspicácia salvou o projeto.' },
      { pt: 'Resiliência', definicao: 'Capacidade de recuperar de dificuldades', exemplo: 'A resiliência é essencial na vida.' },
      { pt: 'Inefável', definicao: 'Que não se pode descrever com palavras', exemplo: 'A beleza era inefável.' },
      { pt: 'Serendipidade', definicao: 'Descoberta feliz por acaso', exemplo: 'Foi uma serendipidade encontrá-lo.' },
      { pt: 'Procrastinação', definicao: 'Ato de adiar tarefas importantes', exemplo: 'A procrastinação é o inimigo do sucesso.' },
      { pt: 'Empatia', definicao: 'Capacidade de sentir o que o outro sente', exemplo: 'A empatia fortalece relações.' },
      { pt: 'Pragmático', definicao: 'Que prioriza resultados práticos', exemplo: 'Ele tem uma abordagem pragmática.' },
      { pt: 'Ubíquo', definicao: 'Que está em toda parte ao mesmo tempo', exemplo: 'A tecnologia é ubíqua na vida moderna.' },
      { pt: 'Efímero', definicao: 'Que dura pouco tempo', exemplo: 'A beleza da flor é efêmera.' },
    ];

    const hoje = new Date().getDay();
    const palavra = vocabulario[hoje % vocabulario.length];

    return msg.reply(
      `📚 *PALAVRA DO DIA*\n\n` +
      `🔤 *${palavra.pt}*\n\n` +
      `📖 Definição: _${palavra.definicao}_\n\n` +
      `💬 Exemplo: "${palavra.exemplo}"\n\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `_Nova palavra a cada dia!_\n` +
      `Use *${usedPrefix}${command}* amanhã para a próxima.`
    );
  }
};
