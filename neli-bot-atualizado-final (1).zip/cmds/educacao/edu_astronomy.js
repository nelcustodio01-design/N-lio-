import settings from '#settings';
import DB from '#db';

export default {
  command: ['astronomia', 'astronomy', 'estrelas'],
  category: 'educacao',
  description: 'Curiosidades do universo',
  async run({ msg, args, usedPrefix, command, text }) {
    const factos = [
      'A Via Láctea tem cerca de 200-400 bilhões de estrelas.',
      'Um dia em Vénus é mais longo que um ano em Vénus.',
      'A Lua afasta-se da Terra 3.8 cm por ano.',
      'Existem mais estrelas no universo do que grãos de areia na Terra.',
      'A luz do Sol demora 8 minutos e 20 segundos para chegar à Terra.',
      'Júpiter é tão grande que 1.300 Terras caberiam dentro dele.',
      'A temperatura no espaço é -270°C.',
      'Uma estrela de neutrões gira até 716 vezes por segundo.',
    ];
    const facto = factos[Math.floor(Math.random() * factos.length)];
    return msg.reply(`🌌 *CURIOSIDADE ASTRONÓMICA*\n\n${facto}\n\n_Use novamente para outra curiosidade._`);
  }
};
