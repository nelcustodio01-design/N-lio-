import settings from '#settings';
import DB from '#db';

export default {
  command: ['quimica', 'chemistry', 'elementos'],
  category: 'educacao',
  description: 'Elementos quimicos',
  async run({ msg, args, usedPrefix, command, text }) {
    const elementos = {
      h: { nome: 'Hidrogênio', numero: 1, massa: 1.008, tipo: 'Não-metal' },
      he: { nome: 'Hélio', numero: 2, massa: 4.003, tipo: 'Gás nobre' },
      c: { nome: 'Carbono', numero: 6, massa: 12.011, tipo: 'Não-metal' },
      n: { nome: 'Nitrogênio', numero: 7, massa: 14.007, tipo: 'Não-metal' },
      o: { nome: 'Oxigênio', numero: 8, massa: 15.999, tipo: 'Não-metal' },
      fe: { nome: 'Ferro', numero: 26, massa: 55.845, tipo: 'Metal de transição' },
      au: { nome: 'Ouro', numero: 79, massa: 196.967, tipo: 'Metal de transição' },
      ag: { nome: 'Prata', numero: 47, massa: 107.868, tipo: 'Metal de transição' },
    };
    const simb = args[0]?.toLowerCase();
    if (!simb) {
      const lista = Object.keys(elementos).map(e => `• *${e.toUpperCase()}* - ${elementos[e].nome}`).join('\n');
      return msg.reply(`⚗️ *TABELA PERIÓDICA*\n\nUso: *${usedPrefix}${command} <símbolo>*\n\nElementos: ${lista}`);
    }
    const el = elementos[simb];
    if (!el) return msg.reply(`❌ Elemento não encontrado.`);
    return msg.reply(`⚗️ *ELEMENTO: ${el.nome}*\n\n🔬 Símbolo: *${simb.toUpperCase()}*\n📊 Número: *${el.numero}*\n⚖️ Massa: *${el.massa} u*\n🏷️ Tipo: *${el.tipo}*`);
  }
};
