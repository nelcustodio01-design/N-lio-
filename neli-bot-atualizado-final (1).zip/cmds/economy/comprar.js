import db from '#db';

export default {
  command: ['comprar', 'buy'],
  category: 'economy',
  description: 'Comprar itens na loja do bot.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const chat = db.getChat(msg.chat);
    if (!chat.economy) return msg.reply(`ꕥ O sistema de *Economia* está desativado neste grupo.`);

    const itemInput = args.join(' ').toLowerCase();
    if (!itemInput) return msg.reply(`🛒 **LOJA NEXUS**\n\nUso: *${usedPrefix + command} [nome do item]*\nExemplo: *${usedPrefix + command} espada*\n\n> Digite *${usedPrefix}shop* para ver os itens.`);

    const user = db.getChatUser(msg.chat, msg.sender);
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const settings = db.getSettings(botId);
    const currency = settings?.currency || 'MT';

    // Itens da Loja (Centralizados para evitar erros)
    const storeItems = [
        { id: 'espada', name: 'Espada', price: 8000, type: 'weapons' },
        { id: 'hacha', name: 'Hacha', price: 7500, type: 'weapons' },
        { id: 'arco', name: 'Arco', price: 7000, type: 'weapons' },
        { id: 'pico', name: 'Pico', price: 6500, type: 'tools' },
        { id: 'vara', name: 'Vara de pescar', price: 6000, type: 'tools' },
        { id: 'totem', name: 'Totem', price: 4000, type: 'inventory' },
        { id: 'pocion', name: 'Pocion', price: 1500, type: 'inventory' }
    ];

    const item = storeItems.find(i => i.id === itemInput || i.name.toLowerCase() === itemInput);
    if (!item) return msg.reply(`❌ Item "${itemInput}" não encontrado na loja.`);

    // Verificar Saldo
    if (user.coins < item.price) {
        return msg.reply(`❌ Saldo insuficiente!\n\n> Preço: *${item.price} ${currency}*\n> Seu Saldo: *${user.coins} ${currency}*`);
    }

    // Processar Compra
    try {
        let currentInv = user[item.type] || {};
        if (typeof currentInv === 'string') currentInv = JSON.parse(currentInv);

        if (item.type === 'inventory') {
            currentInv[item.id] = (currentInv[item.id] || 0) + 1;
        } else {
            if (currentInv[item.id]) return msg.reply(`🛡️ Você já possui este item: *${item.name}*`);
            currentInv[item.id] = { durability: 100, maxDurability: 100 };
        }

        // Salvar na Base de Dados
        db.setChatUser(msg.chat, msg.sender, item.type, JSON.stringify(currentInv));
        db.setChatUser(msg.chat, msg.sender, 'coins', user.coins - item.price);

        await msg.react('🛍️');
        return msg.reply(`✅ **COMPRA CONCLUÍDA!**\n\nVocê adquiriu: *${item.name}*\nCusto: *${item.price} ${currency}*\n\n> Use *${usedPrefix}inv* para ver seu inventário.`);
    } catch (e) {
        console.error('Purchase Error:', e);
        msg.reply('❌ Erro crítico ao processar a compra no núcleo financeiro.');
    }
  }
};
