import settings from '#settings';
import DB from '#db';
export default {
  command: ['fabricar', 'craft', 'criaritem'],
  category: 'economy',
  description: 'Fabricar itens',
  async run({ msg, sock, args, text, sender }) {
    await msg.reply(`💰 A processar: _fabricar_\n\n✅ Feito!`);
  },
};
