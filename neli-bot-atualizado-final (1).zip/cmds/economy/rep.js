import db from '#db';

// Cooldown: 1 rep por utilizador por dia
const COOLDOWN = 24 * 60 * 60 * 1000;
const repCooldowns = new Map(); // `${sender}:${alvo}` → timestamp

export default {
  command: ['rep', 'reputacao', 'reputação', '+rep', 'elogiar'],
  category: 'economy',
  description: 'Dar ponto de reputação a um membro. +1 rep/dia. ⭐',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    try {
      const sub = args[0]?.toLowerCase();

      // Ver top reputação
      if (sub === 'top' || sub === 'ranking') {
        const todos = db.getUser();
        if (!Array.isArray(todos) || todos.length === 0) return msg.reply('❧ Nenhum utilizador registado ainda.');
        const sorted = todos
          .filter(u => u.metadatos2 && !isNaN(parseInt(u.metadatos2)))
          .sort((a, b) => parseInt(b.metadatos2 || 0) - parseInt(a.metadatos2 || 0))
          .slice(0, 10);
        if (sorted.length === 0) return msg.reply('❧ Ninguém tem rep ainda. Usa *.rep @alguem* para dar!');
        let txt = `⭐ *TOP REPUTAÇÃO*\n\n`;
        sorted.forEach((u, i) => {
          const estrelas = '⭐'.repeat(Math.min(parseInt(u.metadatos2 || 0), 5));
          txt += `${i + 1}. *${u.name || u.id.split('@')[0]}* — ${u.metadatos2} rep ${estrelas}\n`;
        });
        return msg.reply(txt);
      }

      // Ver rep de alguém
      const alvo = msg.mentionedJid?.[0] || msg.quoted?.sender;
      if (sub === 'ver' || sub === 'ver' || (!alvo && sub !== '+rep')) {
        const quem = alvo || msg.sender;
        const u = db.getUser(quem);
        const rep = parseInt(u?.metadatos2 || '0');
        const estrelas = rep === 0 ? 'Nenhuma' : '⭐'.repeat(Math.min(rep, 10));
        return msg.reply(`⭐ *Reputação de @${quem.split('@')[0]}*\n\n🏆 Rep: *${rep}*\n${estrelas}`);
      }

      if (!alvo) {
        return msg.reply(
          `⭐ *SISTEMA DE REPUTAÇÃO*\n\n` +
          `▸ *${usedPrefix + command} @membro* — Dar +1 rep\n` +
          `▸ *${usedPrefix + command} top* — Ver ranking\n` +
          `▸ *${usedPrefix + command} ver @membro* — Ver rep de alguém\n\n` +
          `💡 Podes dar rep uma vez por dia a cada pessoa.`
        );
      }

      if (alvo === msg.sender) return msg.reply('❧ Não podes dar rep a ti mesmo! 😄');

      const key = `${msg.sender}:${alvo}`;
      const ultimo = repCooldowns.get(key) || 0;
      const restante = COOLDOWN - (Date.now() - ultimo);
      if (restante > 0) {
        const h = Math.floor(restante / 3600000);
        const min = Math.floor((restante % 3600000) / 60000);
        return msg.reply(`⏰ Já deste rep a esta pessoa hoje!\nPodes dar novamente em *${h}h ${min}min*.`);
      }

      // Dar rep
      const userAlvo = db.getUser(alvo);
      const repAtual = parseInt(userAlvo?.metadatos2 || '0');
      db.setUser(alvo, 'metadatos2', String(repAtual + 1));
      repCooldowns.set(key, Date.now());

      const nomeAlvo = userAlvo?.name || alvo.split('@')[0];
      await sock.sendMessage(msg.chat, {
        text:
          `⭐ *REP DADO!*\n\n` +
          `@${msg.sender.split('@')[0]} deu +1 rep a @${alvo.split('@')[0]}!\n\n` +
          `🏆 *${nomeAlvo}* agora tem *${repAtual + 1} rep*\n\n` +
          `_Podes dar rep novamente amanhã!_`,
        mentions: [msg.sender, alvo]
      }, { quoted: msg });
    } catch (e) {
      return msg.reply(`❧ Erro: ${e.message}`);
    }
  }
};
