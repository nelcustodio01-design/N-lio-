import settings from '#settings';
import DB from '#db';
export default {
  command: ['lotaria', 'lottery', 'lotofacil'],
  category: 'jogos',
  description: 'Jogar na lotaria',
  async run({ msg, sock, args, text, sender }) {
    await msg.reply(`🎮 A iniciar: _lotaria_\n\n⏳ Aguarde...`);
  },
};
