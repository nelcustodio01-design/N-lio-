import settings from '#settings';
import DB from '#db';
export default {
  command: ['capital', 'capitalquiz', 'capitais'],
  category: 'jogos',
  description: 'Adivinhar capital do pais',
  async run({ msg, sock, args, text, sender }) {
    await msg.reply(`🎮 A iniciar: _capital_\n\n⏳ Aguarde...`);
  },
};
