import settings from '#settings';
import DB from '#db';
export default {
  command: ['pixelate', 'stickerpixel', 'pixelsticker'],
  category: 'stickers',
  description: 'Sticker com efeito pixelado',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .pixelate <texto/URL>\n\n📌 Exemplo: .pixelate ola mundo');
    await msg.reply(`⏳ A criar sticker...\n\n🎨 Efeito: _pixelate_\n$\nAguarde...`);
  },
};
