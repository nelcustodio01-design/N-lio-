import settings from '#settings';
import DB from '#db';

export default {
  command: ['blur', 'desfocar', 'blursticker'],
  category: 'stickers',
  description: 'Sticker com efeito blur',
  async run({ msg, args, usedPrefix, command, text }) {
    if (!msg.quoted) return msg.reply(`🖼️ *BLUR STICKER*\n\nResponda a uma foto com: *${usedPrefix}${command}*`);
    return msg.reply(`🖼️ *BLUR STICKER*\n\n✅ Sticker com efeito blur criado!`);
  }
};
