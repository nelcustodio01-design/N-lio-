import settings from '#settings';
import DB from '#db';
export default {
  command: ['kang', 'roubarsticker', 'kangsticker'],
  category: 'stickers',
  description: 'Roubar sticker para o teu pack',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .kang <texto/URL>\n\n📌 Exemplo: .kang ola mundo');
    await msg.reply(`⏳ A criar sticker...\n\n🎨 Efeito: _kang_\n$\nAguarde...`);
  },
};
