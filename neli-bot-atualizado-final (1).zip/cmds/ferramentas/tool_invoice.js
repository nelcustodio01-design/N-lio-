import settings from '#settings';
import DB from '#db';
export default {
  command: ['factura', 'invoice', 'receibo'],
  category: 'ferramentas',
  description: 'Gerar factura simples',
  async run({ msg, args }) {
    const items = args.join(' ') || 'Serviço NEXUS OMEGA';
    return msg.reply(`🧾 *FACTURA / ORÇAMENTO*\n\nDescrição: ${items}\nData: ${new Date().toLocaleDateString('pt-PT')}\n\nValor: a confirmar\n\nDocumento informativo — confirme os dados antes de emitir.`);
  },
};
