import settings from '#settings';
import DB from '#db';
export default {
  command: ['yoga', 'poses', 'asana'],
  category: 'ferramentas',
  description: 'Poses de yoga',
  async run({ msg }) {
    return msg.reply('🧘 Sequência suave: respiração profunda, postura da criança, gato-vaca, cobra suave e savasana — 30 segundos cada. Para se houver dor ou tontura.');
  },
};
