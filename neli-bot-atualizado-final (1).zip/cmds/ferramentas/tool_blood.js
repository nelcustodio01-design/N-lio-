import settings from '#settings';
import DB from '#db';
export default {
  command: ['sangue', 'blood', 'tiposanguineo'],
  category: 'ferramentas',
  description: 'Informacoes sobre tipo sanguineo',
  async run({ msg, args }) {
    const type = (args[0] || '').toUpperCase();
    const info = { 'O+': 'Muito comum. Pode receber O+ e O-.', 'O-': 'Doador universal de glóbulos vermelhos.', 'AB+': 'Recetor universal de glóbulos vermelhos.', 'AB-': 'Tipo raro; confirme compatibilidade antes de transfusões.' };
    return msg.reply(info[type] ? `🩸 *${type}*: ${info[type]}` : '🩸 Indica um tipo como O+, O-, A+, B+ ou AB+. Informação geral; confirme sempre com um serviço de saúde.');
  },
};
