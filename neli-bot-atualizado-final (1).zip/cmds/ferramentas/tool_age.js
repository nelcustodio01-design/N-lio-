import settings from '#settings';
import DB from '#db';
export default {
  command: ['idade', 'age', 'calcularidade'],
  category: 'ferramentas',
  description: 'Calcular idade exacta',
  async run({ msg, args, usedPrefix, command }) {
    const birth = new Date(args[0]);
    if (Number.isNaN(birth.getTime())) return msg.reply(`📅 Uso: ${usedPrefix}${command} AAAA-MM-DD`);
    const now = new Date();
    let years = now.getFullYear() - birth.getFullYear();
    const beforeBirthday = now < new Date(now.getFullYear(), birth.getMonth(), birth.getDate());
    if (beforeBirthday) years--;
    return msg.reply(`🎂 Idade: *${years} anos*`);
  },
};
