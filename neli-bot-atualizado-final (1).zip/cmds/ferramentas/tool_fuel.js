import settings from '#settings';
import DB from '#db';
export default {
  command: ['combustivel', 'fuel', 'consumo'],
  category: 'ferramentas',
  description: 'Calcular consumo de combustivel',
  async run({ msg, args, usedPrefix, command }) {
    const distance = Number(args[0]); const consumption = Number(args[1]); const price = Number(args[2] || 0);
    if (!(distance > 0 && consumption > 0)) return msg.reply(`⛽ Uso: ${usedPrefix}${command} km litros_por_100km [preço_por_litro]`);
    const litres = distance * consumption / 100;
    return msg.reply(`⛽ Combustível: *${litres.toFixed(2)} L*${price ? `\n💰 Custo: *${(litres * price).toFixed(2)} MT*` : ''}`);
  },
};
