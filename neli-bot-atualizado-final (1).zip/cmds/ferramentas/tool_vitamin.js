import settings from '#settings';
import DB from '#db';
export default {
  command: ['vitamina', 'vitamin', 'nutriente'],
  category: 'ferramentas',
  description: 'Informacoes sobre vitaminas',
  async run({ msg, args }) {
    const key = args.join(' ').toLowerCase();
    const info = { a: 'Visão e imunidade; presente em cenoura, batata-doce e folhas verdes.', b12: 'Sistema nervoso e formação do sangue; fontes animais ou suplementação orientada.', c: 'Colagénio e imunidade; presente em citrinos e frutas.' };
    const match = Object.keys(info).find(name => key.includes(name));
    return msg.reply(match ? `💊 Vitamina ${match.toUpperCase()}: ${info[match]}` : '💊 Consulta: A, B12 ou C. Uma alimentação variada é a melhor base; não uses suplementos sem orientação.');
  },
};
