import settings from '#settings';
import DB from '#db';

export default {
  command: ['emprestimo', 'loan', 'credito'],
  category: 'ferramentas',
  description: 'Calcular emprestimo',
  async run({ msg, args, usedPrefix, command, text }) {
    if (args.length < 3) return msg.reply(`💳 *CALCULADORA DE EMPRÉSTIMO*\n\nUso: *${usedPrefix}${command} <valor> <juros%> <meses>*\n\nExemplo: *${usedPrefix}${command} 100000 12 24*\n\n• Valor: 100.000 MT\n• Juros: 12% ao ano\n• Prazo: 24 meses`);
    const valor = parseFloat(args[0]);
    const jurosAnual = parseFloat(args[1]) / 100;
    const meses = parseInt(args[2]);
    const jurosMensal = jurosAnual / 12;
    const parcela = valor * (jurosMensal * Math.pow(1 + jurosMensal, meses)) / (Math.pow(1 + jurosMensal, meses) - 1);
    const total = parcela * meses;
    return msg.reply(`💳 *EMPRÉSTIMO*\n\n💰 Valor: *${valor.toLocaleString()} MT*\n📊 Juros: *${(jurosAnual*100).toFixed(1)}% ao ano*\n📅 Prazo: *${meses} meses*\n\n💵 Parcela mensal: *${parcela.toFixed(2)} MT*\n💰 Total a pagar: *${total.toFixed(2)} MT*\n📈 Total juros: *${(total - valor).toFixed(2)} MT*`);
  }
};
