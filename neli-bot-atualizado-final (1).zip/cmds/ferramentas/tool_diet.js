import settings from '#settings';
import DB from '#db';
export default {
  command: ['dieta', 'diet', 'alimentacao'],
  category: 'ferramentas',
  description: 'Plano alimentar',
  async run({ msg }) {
    return msg.reply('🥗 Plano base: metade do prato com legumes, um quarto com proteína, um quarto com cereais ou tubérculos; junta água e fruta. Para objetivos clínicos, consulta um nutricionista.');
  },
};
