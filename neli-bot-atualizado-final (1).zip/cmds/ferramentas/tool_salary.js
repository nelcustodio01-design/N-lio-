import settings from '#settings';
import DB from '#db';
export default {
  command: ['salario', 'salary', 'ordenado'],
  category: 'ferramentas',
  description: 'Calculadora de salario liquido',
  async run({ msg, args, usedPrefix, command }) {
    const gross = Number(args[0]); const deductions = Number(args[1] || 0);
    if (!(gross >= 0 && deductions >= 0)) return msg.reply(`💼 Uso: ${usedPrefix}${command} salário_bruto [descontos]`);
    return msg.reply(`💼 Bruto: *${gross.toFixed(2)} MT*\nDescontos: *${deductions.toFixed(2)} MT*\nLíquido estimado: *${(gross - deductions).toFixed(2)} MT*`);
  },
};
