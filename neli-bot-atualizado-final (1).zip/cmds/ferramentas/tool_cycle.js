import settings from '#settings';
import DB from '#db';
export default {
  command: ['ciclo', 'menstrual', 'periodo'],
  category: 'ferramentas',
  description: 'Calculadora de ciclo menstrual',
  async run({ msg, args, usedPrefix, command }) {
    const start = new Date(args[0]); const length = Number(args[1] || 28);
    if (Number.isNaN(start.getTime()) || !(length >= 21 && length <= 40)) return msg.reply(`🌸 Uso: ${usedPrefix}${command} AAAA-MM-DD [ciclo_em_dias]`);
    const next = new Date(start.getTime() + length * 86400000);
    const fertile = new Date(start.getTime() + (length - 14) * 86400000);
    return msg.reply(`🌸 Próximo período: *${next.toLocaleDateString('pt-PT')}*\n🌱 Ovulação estimada: *${fertile.toLocaleDateString('pt-PT')}*\n\nEstimativa educativa, não substitui aconselhamento médico.`);
  },
};
